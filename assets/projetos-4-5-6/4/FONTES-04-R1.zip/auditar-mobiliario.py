"""Folgas simplificadas em quartos e escritório; sem certificação de ergonomia."""
import json
from pathlib import Path
from detalhes_mobiliario import bed,wardrobe,wardrobe_list,office,tv

data=json.loads((Path(__file__).resolve().parent/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
rooms={r['id']:r for level in ('terreo','superior') for r in data[level]}
for key in ('q1','q2','q3'):
    r=rooms[key];b=bed(r);w=wardrobe(r);wall_left=r['x']+.075;wall_right=r['x']+r['w']-.075
    if w[2]<=b[0]:left=b[0]-w[2];right=wall_right-b[2]
    elif w[0]>=b[2]:left=b[0]-wall_left;right=w[0]-b[2]
    else:raise AssertionError(key+': armário sobre cama')
    assert min(left,right)>=.60-1e-8,f'{key}: folga lateral abaixo de 0,60 m'
    print(f'{key}: margens laterais esquemáticas de {left:.3f} e {right:.3f} m; armário suposto de correr.')
r=rooms['q5'];b=bed(r);ww=wardrobe_list(r)
left=b[0]-(r['x']+.075);right=min(w[0]-b[2] for w in ww)
assert min(left,right)>=.60-1e-8
print(f'q5: margens laterais esquemáticas de {left:.3f} e {right:.3f} m junto às duas seções de armário.')
r=rooms['closet'];ww=wardrobe_list(r);gap=ww[1][0]-ww[0][2]
assert gap>=.90-1e-8
print(f'Closet master: intervalo de {gap:.3f} m entre as duas frentes de armário, fechados.')
r=rooms['escritorio'];f=office(r);rear=r['y']+r['h']-.075-f['cadeira'][3]
assert rear>=.75-1e-8,f'Escritório: folga atrás da cadeira {rear:.3f} m'
print(f'Escritório: distância entre a cadeira desenhada e a parede {rear:.3f} m; não verifica deslocamento da cadeira nem uso simultâneo.')
r=rooms['estar'];x0,y0,x1,y1=tv(r);cx=(x0+x1)/2;cy=(y0+y1)/2
assert abs(cx-(r['x']+1.45))<.15 and cy>r['y']+3.0,'TV fora do eixo frontal do sofá'
print(f'Estar: TV alinhada ao sofá voltado para +Y; distância entre centros {cy-(r["y"]+1.50):.3f} m. Inspeção do sentido do móvel também necessária.')
print('NÃO COMPROVA acesso ao armário, abertura de portas reais, circulação com pessoas, mesa em uso, ergonomia ou normas.')
