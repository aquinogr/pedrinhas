"""Geometria preliminar das louças no lavabo externo; não é projeto executivo."""
def detalhes_lavabo(r):
    x,y,w,h=(r[k] for k in ('x','y','w','h'))
    return {
        'cuba':(x+.075,y+.60,x+.475,y+1.05),
        'bacia':(x+w-.505,y+1.15,x+w-.105,y+1.80),
        'faixa_frontal_bacia':(x+w-.505,y+.55,x+w-.105,y+1.15),
    }
