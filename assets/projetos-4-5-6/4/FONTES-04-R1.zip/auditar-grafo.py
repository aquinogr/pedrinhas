"""Audita conexão lógica e presença dos vãos registrados; não testa folgas físicas."""
from pathlib import Path
from collections import deque
import importlib.util,json

root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('planta04',root/'gerar-estudo.py')
plan=importlib.util.module_from_spec(spec);spec.loader.exec_module(plan)
from elementos_04 import CUTS
cuts=json.loads((root/CUTS).read_text(encoding='utf-8'))
graph={}
def add(a,b):graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a)
for level in ('terreo','superior'):
    for a,b in plan.G['04'][level]:
        label=f'{a} ↔ {b}'
        matches=[c for c in cuts if c['nivel']==level and c['nome']==label]
        assert len(matches)==1,f'{level} {label}: {len(matches)} vãos reconhecidos'
        add(level+':'+a,level+':'+b)
add('exterior','terreo:estar')
add('terreo:gourmet','lazer')
add('lazer','terreo:lavabo')
add('terreo:escada','superior:escada-superior')
def reachable(source,target,forbidden=()):
    q=deque([source]);previous={source:None};forbidden=set(forbidden)-{source,target}
    while q:
        u=q.popleft()
        if u==target:
            path=[]
            while u is not None:path.append(u);u=previous[u]
            return list(reversed(path))
        for v in graph.get(u,()):
            if v not in previous and v not in forbidden:previous[v]=u;q.append(v)
    raise AssertionError(f'Sem percurso lógico {source} → {target}')
bedrooms=['terreo:q1','terreo:q2','terreo:q3','superior:master','superior:q5']
for q,b in [('terreo:q1','terreo:b1'),('terreo:q2','terreo:b2'),('terreo:q3','terreo:b3'),('superior:master','superior:banho-master'),('superior:q5','superior:banho-5')]:
    path=reachable(q,b,bedrooms);print('Banho:',q,'→',b,';', ' → '.join(path))
for a,b in [('exterior','terreo:escada'),('terreo:escada','superior:hall-superior'),('terreo:estar','lazer'),('lazer','terreo:lavabo')]:
    print('Conexão:', ' → '.join(reachable(a,b,bedrooms)))
for b in ('terreo:b1','terreo:b2','terreo:b3'):
    print('Banho acessível também fora do quarto (reversível por vestíbulo):', ' → '.join(reachable('terreo:circulacao',b,bedrooms)))
print('NÃO COMPROVA passagem útil, giros, abertura das portas, obstáculos, instalações ou segurança; bordas lazer↔lavabo e escada entre pavimentos são hipóteses sem modelagem integral.')
