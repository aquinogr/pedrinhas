"""Confronta faixa lateral secundária com obstáculos e folhas do IGZ real."""
from pathlib import Path
import json,runpy
from shapely.geometry import box
from core.scene import Scene
from formats.igz import load_into
from elementos_04 import NATIVE,PAVING
r=Path(__file__).resolve().parent;scene=Scene();load_into(scene,r/NATIVE)
lane=box(11.20,4.15,11.80,33.4)
minimum=99;leaf_count=0
for g in scene.groups:
    if not g.mesh.vertices:continue
    pts=[(v.position.x(),v.position.y(),v.position.z()) for v in g.mesh.vertices]
    lo=[min(p[i] for p in pts) for i in range(3)];hi=[max(p[i] for p in pts) for i in range(3)]
    if lo[2]>=2.1 or hi[2]<=0:continue
    if 'Vidro' not in g.name:continue
    foot=box(lo[0],lo[1],hi[0],hi[1])
    assert foot.intersection(lane).area<1e-7,'Folha intercepta faixa: '+g.name
    if lo[0]>=10.3 and hi[0]>10.5:
        minimum=min(minimum,lane.distance(foot));leaf_count+=1
audit=runpy.run_path(str(r/'auditar-giros.py'))
for name,foot in audit['obs']['terreo']:
    assert foot.intersection(lane).area<1e-7,'Obstáculo intercepta faixa: '+name
assert audit['wall_masks']['terreo'].intersection(lane).area<1e-7
for level,name,kind,foot in audit['panels']:
    if level=='terreo':assert foot.intersection(lane).area<1e-7,'Porta aberta intercepta faixa: '+name
for name,b in PAVING:
    if name.startswith('pisante-lateral'):assert lane.buffer(1e-7).covers(box(*b))
assert leaf_count>0 and minimum>=.10
report=dict(revisao='R1-P1',faixa_x=[11.20,11.80],faixa_y=[4.15,33.4],largura_ensaio=.60,altura_ensaio=2.10,folhas_laterais_conferidas=leaf_count,menor_distancia_folha_faixa=round(minimum,3),resultado='Faixa sem interseção com folhas, paredes, móveis e portas abertas representados',limites='Rota secundária em gramado; não é rota acessível pavimentada. Cercamentos futuros, vegetação, ferragens e uso simultâneo real exigem compatibilização.')
(r/'PASSAGEM-LATERAL-04-P1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False))
