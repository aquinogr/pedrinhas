"""Audita escopo de alteração e privacidade antes de qualquer push."""
from pathlib import Path
import re,json,hashlib,subprocess,zipfile
R=Path(__file__).resolve().parent;S=R.parent/'PUBLICACAO-04'
def git(*args):return subprocess.check_output(['git','-C',str(S),*args])
allowed={'index.html','README.md','projetos-4-5-6.html'}
modified=git('diff','--name-only').decode().splitlines()
assert set(modified)<=allowed,modified
baseline=git('show','HEAD:index.html').decode('utf8');current=(S/'index.html').read_text(encoding='utf8')
def cards(s):
    return {int(re.search(r'<b>(\d+) ·',m.group()).group(1)):m.group() for m in re.finditer(r'<a class="hc"[^>]*>.*?</a>',s,re.S)}
old,new=cards(baseline),cards(current)
assert len(old)==9 and len(new)==9
for i in [1,2,3,7,8,9]:assert old[i]==new[i],f'Cartão {i} alterado indevidamente'
for i in [5,6]:assert re.sub(r'href="[^"]+"','href="RESERVADO"',old[i])==re.sub(r'href="[^"]+"','href="RESERVADO"',new[i])
violations=[];entries=[]
for p in (S/'assets/projetos-4-5-6').rglob('*'):
    if not p.is_file():continue
    assert p.stat().st_size<95_000_000,('Arquivo excede limite de segurança do GitHub',p.name)
    assert p.suffix.lower() in {'.glb','.igz','.svg','.png','.jpg','.pdf','.json','.md','.html','.zip'},p.name
    if p.suffix in {'.md','.html','.json'}:
        t=p.read_text(encoding='utf8')
        if re.search(r'https://gemini\.google\.com/app/[a-z0-9]+',t) or 'C:\\Users\\gr_aq' in t or 'C:/Users/gr_aq' in t:violations.append(str(p.relative_to(S)))
    if p.suffix=='.zip':
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            for n in z.namelist():
                assert not any(part in n.lower() for part in ['.venv','node_modules','.env','cache-texturas','generated_image']),n
                if n.endswith(('.html','.md','.json','.py','.cjs')):
                    t=z.read(n).decode('utf8')
                    if re.search(r'https://gemini\.google\.com/app/[a-z0-9]+',t):violations.append(p.name+'/'+n)
    entries.append(dict(arquivo=str(p.relative_to(S)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert not violations,violations
group=(S/'projetos-4-5-6.html').read_text(encoding='utf8');assert 'Casa 5' in group and 'Casa 6' in group and 'em preparação' in group
result=dict(base_commit=git('rev-parse','HEAD').decode().strip(),escopo='Projeto4, página reservada4–6, cartão04 e destinos05/06, README',arquivos_originais_modificados=modified,cartoes_preservados=[1,2,3,7,8,9],privacidade='Sem URLs de conversas privadas, caminhos pessoais ou runtime no pacote',arquivos=entries)
(R/'AUDITORIA-INTEGRACAO-04.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('INTEGRAÇÃO CONFERIDA:',len(entries),'arquivos de entrega; cartões1–3/7–9 preservados; sem dados privados detectados.')
