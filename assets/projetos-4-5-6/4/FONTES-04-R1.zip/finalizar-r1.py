"""Valida o pacote preparado; não publica e não altera outra proposta."""
from pathlib import Path
import hashlib,json,zipfile,shutil
from PIL import Image
r=Path(__file__).resolve().parent;a=r.parent/'SITE-ISOLADO-BASE-f51f2c9/assets/atrio04/r1'
required=['CASA-04-R1-MOBILIADA.igz','CASA-04-R1.glb','CASA-04-R1.blend','REVISAO-04-R1.json','QUADRO-AREAS-04-R1.json','QA-SITE-04-R1.json','MEMORIAL-04-R1.md','REVISAO-FOTOS-R1.md','APRENDIZADOS-R1.md']
required += [str(p.relative_to(r)) for p in (r/'PRANCHAS-R1').glob('*.svg')]+[str(p.relative_to(r)) for p in (r/'RENDERS-R1').glob('*.png')]
required+=['NANOBANANA-R1-LAZER.png','NANOBANANA-R1-FACHADA-02.png']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
for name in required:
    p=r/name;assert p.exists() and p.stat().st_size>0,name
    files.append(dict(arquivo=name,bytes=p.stat().st_size,sha256=sha(p)))
for name in ['CASA-04-R1-MOBILIADA.igz','CASA-04-R1.glb','MEMORIAL-04-R1.md','REVISAO-04-R1.json']:
    assert sha(r/name)==sha(a/name),'Cópia do site desatualizada: '+name
for p in (r/'PRANCHAS-R1').glob('*.svg'):assert sha(p)==sha(a/p.name)
for p in (r/'RENDERS-R1').glob('*.png'):
    target=a/(p.stem+'.jpg');assert target.stat().st_mtime>=p.stat().st_mtime,'Render desatualizado no site'
    with Image.open(p) as im:assert im.width>=1000
with zipfile.ZipFile(r/'CASA-04-R1-MOBILIADA.igz') as z:
    assert z.testzip() is None
    assert 'document.json' in z.namelist() and any(n.startswith('textures/') for n in z.namelist())
qa=json.loads((r/'QA-SITE-04-R1.json').read_text(encoding='utf8'));assert len(qa['resultados'])==3
gui=json.loads((r/'QA-IGZ-R1.json').read_text(encoding='utf8'));assert gui['abertura'] and gui['captura'] and gui['sha256']==sha(r/'CASA-04-R1-MOBILIADA.igz')
review=json.loads((r/'REVISAO-04-R1.json').read_text(encoding='utf8'));assert len(review['itens'])==16
for name in ['04-pranchas-R1.pdf','CASA04-OFFLINE.html','04-quadros-R1.html','FONTES-04-R1.zip']:assert (a/name).is_file()
record=dict(projeto='04 / Casa do Átrio Social',revisao='R1',data='2026-11-13',escopo='Estudo arquitetônico de apresentação para aprovação; não executivo',publicado=False,substituicao_imagens_publicadas=False,fonte_modelo='IngeTrazo IGZ + composição Blender',revisao_geometrica=review['status'],revisao_web=qa['resultados'],arquivos=files,limites=['Enquadramento cadastral/zoneamento e condomínio não confirmados; implantação condicional ao briefing','Executivo, cálculo, instalações e licenciamento não incluídos','Fotografias por IA são candidatas interpretativas, prévias de 1024 × 687 px; não há garantia de coincidência dimensional integral'])
(r/'MANIFESTO-ENTREGA-04-R1.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf8');shutil.copy2(r/'MANIFESTO-ENTREGA-04-R1.json',a/'MANIFESTO-ENTREGA-04-R1.json')
print('Pacote R1 conferido:',len(files),'arquivos fonte, IGZ íntegro, cópias sincronizadas e QA registrado. SEM PUBLICAÇÃO.')
