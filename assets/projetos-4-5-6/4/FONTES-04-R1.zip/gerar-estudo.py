"""Gera desenhos de distribuição para revisão, sem publicar o projeto.

Todos os vãos, móveis e áreas são esquemáticos, sujeitos ao projeto detalhado.
Valida adjacência antes de desenhar uma passagem entre dois retângulos.
"""
from pathlib import Path
import html,json,math
from detalhes_banhos import detalhes_banho,detalhes_banho_master
from detalhes_lavabo import detalhes_lavabo
from aberturas_04 import open_panels
from detalhes_mobiliario import bed as bed_rect,wardrobe_list,office,tv
P=Path(__file__).resolve().parent
OUT=P/'PREVIA-DISTRIBUICAO';OUT.mkdir(exist_ok=True)
G={
'04':{
 'terreo':[('estar','v1'),('q1','v1'),('v1','b1'),('estar','circulacao'),('circulacao','hall'),('hall','cozinha'),('cozinha','escada'),('circulacao','v2'),('v2','q2'),('v2','b2'),('circulacao','v3'),('v3','q3'),('v3','b3'),('circulacao','cozinha'),('cozinha','ligacao'),('ligacao','gourmet'),('circulacao','gourmet')],
 'superior':[('varanda','master'),('varanda','escritorio'),('master','banho-master'),('master','closet'),('master','hall-superior'),('escritorio','hall-superior'),('hall-superior','chegada-escada'),('chegada-escada','escada-superior'),('hall-superior','q5'),('q5','vestibulo-5'),('vestibulo-5','banho-5')]},
'05':{
 'terreo':[('estar','cozinha'),('cozinha','hall'),('cozinha','conexao'),('conexao','quiosque'),('quiosque','passagem-lazer'),('quiosque','apoio'),('passagem-lazer','circulacao'),('circulacao','v1'),('v1','q1'),('v1','b1'),('circulacao','v2'),('v2','q2'),('v2','b2'),('circulacao','v3'),('v3','q3'),('v3','b3'),('circulacao','lavanderia'),('hall','escada')],
 'superior':[('varanda','master'),('varanda','escritorio'),('master','banho-master'),('master','closet'),('master','hall-superior-1'),('escritorio','hall-superior-frente'),('hall-superior-frente','hall-superior-1'),('hall-superior-1','escada-superior'),('hall-superior-1','hall-superior-2'),('hall-superior-2','q5'),('q5','vestibulo-5'),('vestibulo-5','banho-5')]},
'06':{
 'terreo':[('hall-frente','v1'),('v1','q1'),('v1','b1'),('hall-frente','v2'),('v2','q2'),('v2','b2'),('hall-frente','circulacao'),('circulacao','v3'),('v3','q3'),('v3','b3'),('circulacao','hall-escada'),('hall-escada','escada'),('circulacao','alpendre-conexao'),('alpendre-conexao','percurso'),('percurso','cozinha'),('estar','gourmet'),('cozinha','gourmet'),('apoio','deposito')],
 'superior':[('varanda','master'),('varanda','escritorio'),('master','banho-master'),('master','closet'),('master','hall-superior-1'),('escritorio','hall-superior-1'),('hall-superior-1','escada-superior'),('hall-superior-1','q5'),('q5','vestibulo-5'),('vestibulo-5','banho-5')]}}
SLIDING={('varanda','master'),('varanda','escritorio')}
OPEN={('estar','cozinha'),('cozinha','conexao'),('conexao','quiosque'),('quiosque','passagem-lazer'),('passagem-lazer','circulacao'),('circulacao','hall'),('hall','escada'),('circulacao','cozinha'),('cozinha','ligacao'),('ligacao','gourmet'),('circulacao','gourmet'),('hall-superior','escada-superior'),('hall-superior-1','escada-superior'),('hall-superior-frente','hall-superior-1'),('hall-superior-1','hall-superior-2'),('hall-frente','circulacao'),('circulacao','hall-escada'),('hall-escada','escada'),('circulacao','alpendre-conexao'),('alpendre-conexao','percurso'),('estar','gourmet'),('cozinha','gourmet')}
OPEN.update({('hall','cozinha'),('cozinha','escada'),('hall-superior','chegada-escada'),('chegada-escada','escada-superior')})
E=html.escape
def shared(a,b):
    eps=1e-5; candidates=[]
    if abs(a['x']+a['w']-b['x'])<eps or abs(b['x']+b['w']-a['x'])<eps:
        start=max(a['y'],b['y']);end=min(a['y']+a['h'],b['y']+b['h'])
        if end>start:candidates.append(('v',a['x']+a['w'] if abs(a['x']+a['w']-b['x'])<eps else a['x'],start,end))
    if abs(a['y']+a['h']-b['y'])<eps or abs(b['y']+b['h']-a['y'])<eps:
        start=max(a['x'],b['x']);end=min(a['x']+a['w'],b['x']+b['w'])
        if end>start:candidates.append(('h',a['y']+a['h'] if abs(a['y']+a['h']-b['y'])<eps else a['y'],start,end))
    if not candidates:raise ValueError(f"Sem fronteira: {a['id']} / {b['id']}")
    return max(candidates,key=lambda x:x[3]-x[2])
def line(axis,f,a,b,stroke,width,extra=''):
    coords=f'x1="{a}" y1="{f}" x2="{b}" y2="{f}"' if axis=='h' else f'x1="{f}" y1="{a}" x2="{f}" y2="{b}"'
    return f'<line {coords} stroke="{stroke}" stroke-width="{width}" {extra}/>'
def mark(axis,f,center,width,sliding=False):
    a=center-width/2;b=center+width/2
    # O vão é intencionalmente esquemático: folhas e giros serão detalhados.
    return line(axis,f,a,b,'#faf8f2',.19)+line(axis,f,a,b,'#987052' if not sliding else '#448a8b',.028,'stroke-dasharray=".10 .06"')
def txt(x,y,s,size=.19,fill='#33483e',anchor='middle',weight='normal'):
    return f'<text x="{x}" y="{y}" font-family="Arial,sans-serif" font-weight="{weight}" font-size="{size}" fill="{fill}" text-anchor="{anchor}">{E(s)}</text>'
def rect(x,y,w,h,fill,stroke='none',sw=.025,rx=0):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def color(r):
    k=r['id']
    if (k.startswith('q') and len(k)>1 and k[1].isdigit()) or k=='master':return '#f1e5d4'
    if k.startswith(('b','banho','lavabo')):return '#dcece9'
    if 'gourmet' in k or k in ('quiosque','varanda','varanda-entrada'):return '#ead3ba'
    if 'escada' in k:return '#dfcfb5'
    if k in ('apoio','lavanderia','deposito','cozinha'):return '#eae6d7'
    return '#f5eee2'
def bed(r):
    x0,y0,x1,y1=bed_rect(r);x=(x0+x1)/2;y=(y0+y1)/2
    return rect(x-.78,y-.96,1.56,1.92,'#fffdf7','#8c8b7d',.025,.08)+rect(x-.65,y-.82,1.30,.30,'#e4e6dc',rx=.04)+rect(x-.72,y+.02,1.44,.78,'#aab8a1',rx=.04)
def table(r,n=8):
    x=r['x']+r['w']/2;y=r['y']+r['h']/2
    # Na opção 06, a mesa do gourmet se integra ao estar pelo vão amplo.
    if r['id']=='gourmet' and r['h']<3.3:x=r['x']+2.9;y=r['y']+.35
    w=2.5 if n==8 else 2.8
    s=rect(x-w/2,y-.5,w,1,'#b98f70','#786354',.025,.03)
    for j in range(4):
        xx=x-w/2+.32+(w-.64)*j/3
        for side in [-1,1]:s+=rect(xx-.225,y+side*.78-.25,.45,.50,'#fff9ed','#8a8979',.025,.04)
    if n==10:
        for side in [-1,1]:s+=rect(x+side*(w/2+.28)-.25,y-.225,.50,.45,'#fff9ed','#8a8979',.025,.04)
    return s
def draw(key,level):
    data=json.loads((P/f'CONCEPCAO-{key}.json').read_text(encoding='utf-8'));rooms=data[level];lookup={r['id']:r for r in rooms};res=[]
    height=42 if level=='terreo' else 26.5
    res.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-2.4 -3.8 16.8 {height}" role="img" aria-label="Estudo de distribuição">')
    res.append(rect(-2.4,-3.8,16.8,height,'#faf8f2'))
    res.append(txt(6,-2.9,data['nome']+' · '+('TÉRREO' if level=='terreo' else 'SUPERIOR'),.30,weight='bold'))
    res.append(txt(6,-2.28,'ESTUDO DE DISTRIBUIÇÃO · VÃOS E MOBILIÁRIO ESQUEMÁTICOS',.17,fill='#8c6550'))
    res.append(txt(6,-.48,'RUA · VISTA PARA O RIO',.18,weight='bold'))
    res.append(rect(0,0,12,35,'#e1ecd8','#748471',.04))
    if level=='terreo':
        q=data['piscina'];res.append(rect(q['x']-.12,q['y']-.12,q['w']+.24,q['h']+.24,'#f4eee2','#aaa897',.025))
        res.append(rect(q['x'],q['y'],q['w'],q['h'],'#a5d9d8','#4b9a9a',.04))
        res.append(txt(q['x']+q['w']/2,q['y']+q['h']/2,'Piscina',.23,weight='bold'))
        res.append(txt(q['x']+q['w']/2,q['y']+q['h']/2+.32,'2,50 × 5,00 m',.15))
        for i in range(3):
            x=1.65+2.5*i
            res.append(rect(x+.34,.4,1.8,3.8,'#d8dcd4','#839080',.035,.22))
            res.append(rect(x+.52,1.4,1.44,1.1,'#a8c2bf',rx=.12))
    for r in rooms:
        x,y,w,h=(r[n] for n in ('x','y','w','h'))
        if r['id'] in ('quiosque','varanda','varanda-entrada','alpendre-conexao'):
            res.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{color(r)}" stroke="#859587" stroke-width=".045" stroke-dasharray=".15 .08"/>')
        else:res.append(rect(x,y,w,h,color(r),'#52685a',.065))
        if (r['id'].startswith('q') and len(r['id'])>1 and r['id'][1].isdigit()) or r['id']=='master':res.append(bed(r))
        elif r['id']=='quiosque':res.append(table(r))
        elif r['id']=='gourmet':res.append(table(r,8 if key=='06' else 10))
        elif r['id']=='cozinha' and key=='05':res.append(table(r,8))
        elif r['id'] in ('escada','escada-superior'):
            for j in range(9):
                res.append(line('h',y+1.40+j*.28,x+.075,x+1.175,'#9a8065',.025))
                res.append(line('h',y+1.40+j*.28,x+1.425,x+2.525,'#9a8065',.025))
            res.append(f'<path d="M{x+.625} {y+h+.35} V{y+.65} H{x+1.975} V{y+h+.35}" fill="none" stroke="#648b85" stroke-width=".05"/>')
            res.append(txt(x+w/2,y+.65,'PATAMAR',.15))
        elif r['id']=='lavabo':
            # Peças esquemáticas partilham fonte com o ensaio do lavabo.
            d=detalhes_lavabo(r)
            for name in ('cuba','bacia'):
                x0,y0,x1,y1=d[name];res.append(rect(x0,y0,x1-x0,y1-y0,'#fff','#8ab3b2',.025,.03))
        elif key=='04' and ((level=='terreo' and r['id'] in ('b1','b2','b3')) or (level=='superior' and r['id'] in ('banho-5','banho-master'))):
            d=detalhes_banho_master(r) if r['id']=='banho-master' else detalhes_banho(r)
            for name,fill in [('box','#eaf9f7'),('bacia','#fff'),('cuba','#fff')]:
                x0,y0,x1,y1=d[name];res.append(rect(x0,y0,x1-x0,y1-y0,fill,'#8ab3b2',.025,.03))
        elif r['id'].startswith('b') or r['id'].startswith('banho'):
            if w>1 and h>1:res.append(rect(x+.12,y+.12,.72,.72,'#f8ffff','#8ab3b2',.025));res.append(f'<ellipse cx="{x+w-.37}" cy="{y+h-.42}" rx=".17" ry=".23" fill="#fff" stroke="#9ab3b0" stroke-width=".025"/>')
        if r['id']=='estar':
            res.append(rect(x+.30,y+1.10,min(2.30,w-.60),.80,'#b5c5b2','#778878',.025,.10))
            res.append(rect(x+.45,y+2.25,min(1.10,w-.90),.50,'#d8c8ab','#a79e88',.02,.04))
            if key=='04':
                x0,y0,x1,y1=tv(r);res.append(rect(x0,y0,x1-x0,y1-y0,'#424b45'))
        if key=='04':
            for x0,y0,x1,y1 in wardrobe_list(r):res.append(rect(x0,y0,x1-x0,y1-y0,'#cab59a','#8b7a68',.025))
        if key=='04' and level=='superior' and r['id']=='escritorio':
            for name,(x0,y0,x1,y1) in office(r).items():res.append(rect(x0,y0,x1-x0,y1-y0,'#bda58b' if name=='mesa' else '#d1dbcc','#8b7a68',.025))
        if r['id']=='cozinha':
            bx=x+.17 if key=='05' else x+w-.72
            res.append(rect(bx,y+.55,.55,max(.6,h-1.10),'#b9c2b1','#808c7e',.025))
            res.append(rect(bx+.07,y+1.05,.38,.45,'#d8e8e3','#808c7e',.02,.05))
        words=r['uso'].replace(' — dimensão a validar','').split();maxlen=max(7,int(w/.11));lines=[];cur=''
        for word in words:
            if cur and len(cur)+len(word)+1>maxlen:lines.append(cur);cur=word
            else:cur=(cur+' '+word).strip()
        if cur:lines.append(cur)
        label_y=y+.31
        if h<.8:lines=[]
        for i,s in enumerate(lines[:3]):res.append(txt(x+w/2,label_y+i*.21,s,.17 if w<2.3 else .19,weight='bold'))
        if w>1.25 and h>1.0:res.append(txt(x+w/2,y+h-.16,f'{w:.2f} × {h:.2f} m'.replace('.',','),.145,fill='#7f7667'))
    # Rectângulos contíguos recebem vãos, com folga de 5 cm em cada extremidade.
    warnings=[]
    for a,b in G[key][level]:
        axis,f,start,end=shared(lookup[a],lookup[b]);span=end-start
        desired=1.8 if (a,b) in SLIDING else 1.0 if (a,b) in OPEN else .8
        if (a,b)==('estar','gourmet'):desired=4.2
        if (a,b)==('cozinha','gourmet'):desired=2.2
        if (a,b)==('estar','cozinha'):desired=2.8
        width=min(desired,span-.10)
        if width<.75:warnings.append(f'{a} → {b}: vão de apenas {width:.2f} m')
        if width<=0:raise ValueError(f'Fronteira estreita: {a} {b}')
        center=(start+end)/2
        if key=='04' and level=='terreo' and (a,b) in (('v1','b1'),('v2','b2'),('v3','b3')):
            center=detalhes_banho(lookup[b])['porta_centro_y']
        if key=='04' and level=='superior' and (a,b)==('vestibulo-5','banho-5'):
            center=detalhes_banho(lookup[b])['porta_centro_y']
        if key=='04' and (a,b)==('cozinha','escada'):center=8.30
        if key=='04' and (a,b)==('chegada-escada','escada-superior'):center=9.75
        res.append(mark(axis,f,center,width,(a,b) in SLIDING))
        if key=='04':
            for kind,x0,y0,x1,y1 in open_panels(f'{a} ↔ {b}',axis,f,center-width/2+.03,center+width/2-.03):
                res.append(rect(x0,y0,x1-x0,y1-y0,'#5a9da2' if kind=='vidro correr' else '#987052'))
    if warnings:raise ValueError('; '.join(warnings))
    # Entradas e saída ao lazer são posições indicativas em paredes externas.
    def edge(name,edge,center,width=1.0,door_label=None):
        r=lookup[name];x,y,w,h=(r[n] for n in ('x','y','w','h'))
        axis,f=('h',y) if edge=='top' else ('h',y+h) if edge=='bottom' else ('v',x+w) if edge=='right' else ('v',x)
        res.append(mark(axis,f,center,width))
        if door_label:
            for kind,x0,y0,x1,y1 in open_panels(door_label,axis,f,center-width/2+.03,center+width/2-.03):
                res.append(rect(x0,y0,x1-x0,y1-y0,'#5a9da2' if kind=='vidro correr' else '#987052'))
    if level=='terreo':
        if key=='04':
            spec=data['diretrizes_em_revisao']
            edge('estar','top',spec['entrada_estar_x'],1.0,'entrada estar')
            edge('gourmet','bottom',5.8,1.8,'saída lazer gourmet')
            edge('lavabo','top',spec['lavabo_externo']['centro_x'],spec['lavabo_externo']['vao_nominal'],'porta lavabo lavabo')
            edge('lavanderia','left',34,.8,'serviço lavanderia');edge('apoio','right',32.1,.8,'apoio apoio');edge('deposito','right',34,.8,'depósito deposito')
        if key=='05':edge('estar','top',4.2);edge('lavabo','right',19.9,.8)
        if key=='06':edge('hall-frente','top',6.0,1.0);edge('gourmet','bottom',8.85,1.8);edge('lavabo','top',4.6,.8);edge('apoio','left',33.4,.8);edge('lavanderia','top',2.65,.8)
    # Luz natural esquemática: traços azuis em fachadas laterais de dormitórios e banhos.
    for r in rooms:
        if not ((r['id'].startswith('q') and len(r['id'])>1 and r['id'][1].isdigit()) or r['id'].startswith(('b','banho')) or r['id']=='master'):continue
        end=min(r['h']-.3,1.5)
        if key=='04' and level=='terreo' and r['id'] in ('b1','b2','b3'):
            end=.30+data['diretrizes_em_revisao']['janelas_banhos_terreo']['largura_nominal']
        if r['x']<=1.651:wx=r['x'];sign=-1
        elif r['x']+r['w']>=10.349:wx=r['x']+r['w'];sign=1
        else:continue
        res.append(line('v',wx,r['y']+.30,r['y']+end,'#5a9da2',.07))
        if key=='04':
            bath=(r['id'].startswith(('b','banho')))
            angle=45 if level=='terreo' and r['id'] in ('b1','b2','b3') else 30
            leafheight=.60 if bath else 1.30
            projection=(leafheight-.06)*math.sin(math.radians(angle))
            res.append(line('v',wx+sign*projection,r['y']+.30,r['y']+end,'#5a9da2',.025,'stroke-dasharray=".08 .05"'))
    if key=='04' and level=='terreo':
        # Posições correspondentes aos vãos externos da maquete volumétrica.
        res.append(line('h',5.15,2.15,3.55,'#5a9da2',.07))
        res.append(line('h',5.15-.62,2.15,3.55,'#5a9da2',.025,'stroke-dasharray=".08 .05"'))
        res.append(line('v',10.35,15.50,16.70,'#5a9da2',.07))
        res.append(line('v',10.35+.47,15.50,16.70,'#5a9da2',.025,'stroke-dasharray=".08 .05"'))
    if level=='terreo':
        res.extend([line('v',-1,0,35,'#506254',.025),line('h',36,0,12,'#506254',.025),txt(-1.25,17.5,'35 m',.18),txt(6,36.5,'12,00 m',.20),txt(6,37.1,'Medidas entre eixos · programa em revisão · não é projeto executivo',.16,fill='#98624e')])
    else:
        res.append(txt(6,21.6,'Pavimento ampliado; lote prossegue até 35 m nos fundos.',.16,fill='#98624e'))
    res.extend(['<path d="M.95 3.0 L.28 3.30" stroke="#43584a" stroke-width=".06"/><path d="M.28 3.30 L.58 3.31 L.40 3.09 Z" fill="#43584a"/>',txt(.35,3.8,'N',.20,weight='bold'),'</svg>'])
    out=OUT/f'{key}-{level}.svg';out.write_text('\n'.join(res),encoding='utf-8');print(out.name,len(rooms),'ambientes,',len(G[key][level]),'vãos')
if __name__=='__main__':
    for key in ('04',):
        for level in ('terreo','superior'):draw(key,level)
