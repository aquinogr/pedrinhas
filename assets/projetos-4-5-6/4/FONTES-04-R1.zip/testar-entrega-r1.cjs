const {chromium}=require('../../RECOMECO/.qa-tools/node_modules/playwright-core');
const path=require('path'),fs=require('fs');
const site=path.resolve(__dirname,'../SITE-ISOLADO-BASE-f51f2c9'),assets=path.join(site,'assets/atrio04/r1'),base='http://127.0.0.1:8876/';
(async()=>{const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results=[];
try{
  const print=await browser.newPage();
  const names=['04-terreo-R1.svg','04-superior-R1.svg','04-cobertura-R1.svg','04-corte-escada-R1.svg'];
  await print.setContent('<!doctype html><style>@page{size:A3 portrait;margin:0}html,body{margin:0}article{width:297mm;height:420mm;break-after:page;display:flex;align-items:center}article:last-child{break-after:auto}img{width:297mm;height:420mm;object-fit:contain}</style>'+names.map(n=>`<article><img src="${base}assets/atrio04/r1/${n}"></article>`).join(''));
  await print.waitForFunction(()=>[...document.images].every(i=>i.complete&&i.naturalWidth>0));await print.pdf({path:path.join(assets,'04-pranchas-R1.pdf'),preferCSSPageSize:true,printBackground:true});await print.close();
  for(const [name,width,height] of [['desktop',1440,1000],['celular',390,844]]){
    const page=await browser.newPage({viewport:{width,height}}),errors=[],http=[];
    page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)http.push(r.status()+' '+r.url())});
    await page.goto(base+'entrega-04.html',{waitUntil:'networkidle',timeout:120000});await page.waitForFunction(()=>window.__atrioStats?.().loaded,null,{timeout:120000});
    for(const m of ['roof','ground','upper','full']){
      await page.locator(`[data-mode="${m}"]`).click();const stats=await page.evaluate(()=>window.__atrioStats());
      if(stats.mode!==m||!stats.roofs||(m==='full'?stats.visibleRoofs!==stats.roofs:stats.visibleRoofs!==0))throw Error('Falha de modo '+JSON.stringify(stats));
    }
    for(const id of ['front','pool','stair','top','reset'])await page.locator('#'+id).click();
    const imageCheck=await page.evaluate(async()=>{for(const i of document.querySelectorAll('img[src]')){i.loading='eager';if(!i.complete)await new Promise(r=>{i.onload=r;i.onerror=r})}return [...document.querySelectorAll('img[src]')].filter(i=>!i.naturalWidth).map(i=>i.src)});
    const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);
    await page.locator('.plan a[data-enlarge]').first().click();await page.waitForFunction(()=>document.getElementById('lightbox').open&&document.getElementById('expanded').complete);await page.locator('#close-image').click();
    await page.screenshot({path:path.join(__dirname,`ENTREGA-R1-${name}.png`)});
    if(name==='desktop'){
      await page.locator('#model').screenshot({path:path.join(__dirname,'ENTREGA-R1-3D-CONJUNTO.png')});
      for(const mode of ['ground','upper']){await page.locator(`[data-mode="${mode}"]`).click();await page.locator('#top').click();await page.locator('#model').screenshot({path:path.join(__dirname,`ENTREGA-R1-3D-${mode}.png`)})}
      await page.locator('#stair').click();await page.locator('#model').screenshot({path:path.join(__dirname,'ENTREGA-R1-3D-ESCADA.png')});
      const links=await page.locator('a[download]').evaluateAll(as=>as.map(a=>a.href));for(const link of links){const response=await page.request.get(link);if(!response.ok())throw Error('Download ausente '+link)}
    }
    if(overflow||imageCheck.length||errors.length||http.length)throw Error(JSON.stringify({name,overflow,imageCheck,errors,http}));
    results.push({viewport:name,largura:width,sem_overflow:true,imagens:'carregadas',javascript:'sem erros',http:'sem falhas',modos3d:4,cameras:5});await page.close();
  }
  const offline=await browser.newPage({viewport:{width:1280,height:900}}),network=[],errors=[];
  offline.on('request',r=>{if(/^https?:/.test(r.url()))network.push(r.url())});offline.on('pageerror',e=>errors.push(e.message));await offline.context().setOffline(true);
  await offline.goto('file:///'+path.join(assets,'CASA04-OFFLINE.html').replaceAll('\\','/'),{waitUntil:'load',timeout:120000});await offline.waitForFunction(()=>window.__atrioStats?.().loaded,null,{timeout:120000});
  await offline.locator('[data-mode="ground"]').click();await offline.locator('#top').click();await offline.screenshot({path:path.join(__dirname,'ENTREGA-R1-OFFLINE.png'),timeout:120000});
  if(network.length||errors.length)throw Error(JSON.stringify({network,errors}));results.push({offline:'3D e plantas sem requisições de rede',javascript:'sem erros'});await offline.close();
  const board=await browser.newPage({viewport:{width:891,height:1260}});await board.setContent('<style>html,body{margin:0}img{display:block;width:891px;height:1260px}</style><img src="'+base+'assets/atrio04/r1/04-terreo-R1.svg">');await board.waitForFunction(()=>document.images[0].complete&&document.images[0].naturalWidth>0);await board.screenshot({path:path.join(__dirname,'ENTREGA-R1-PRANCHA-TERREO.png')});await board.close();
  fs.writeFileSync(path.join(__dirname,'QA-SITE-04-R1.json'),JSON.stringify({data:'2026-11-13',resultados:results},null,2));console.log(JSON.stringify(results,null,2));
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
