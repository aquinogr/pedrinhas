"""Ensaio dos três banhos térreos e banho 5; não é verificação normativa."""
from pathlib import Path
import json
from shapely.geometry import box, LineString
from detalhes_banhos import detalhes_banho

root=Path(__file__).resolve().parent
data=json.loads((root/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
rooms={r['id']:r for level in ('terreo','superior') for r in data[level]}
for key in ('b1','b2','b3','banho-5'):
    r=rooms[key];x,y,w,h=(r[k] for k in ('x','y','w','h'));t=.15
    d=detalhes_banho(r)
    fixture={k:box(*d[k]) for k in ('box','bacia','cuba')}
    front=box(*d['faixa_frontal_bacia'])
    interior=box(x+t/2,y+t/2,x+w-t/2,y+h-t/2)
    for name,a in fixture.items():
        assert interior.buffer(1e-8).covers(a),f'{key}: {name} fora do espaço interno'
        for name2,b in fixture.items():
            if name<name2:assert a.intersection(b).area<1e-8,f'{key}: {name} colide com {name2}'
    for name in ('box','cuba'):
        assert front.intersection(fixture[name]).area<1e-8,f'{key}: faixa frontal da bacia obstruída por {name}'
    cy=d['porta_centro_y']; half=d['porta_largura_nominal']/2
    left=box(x-t/2,y-t/2,x+t/2,y+h+t/2)
    right=box(x+w-t/2,y-t/2,x+w+t/2,y+h+t/2)
    vertical=x if d['espelhado'] else x+w
    opened_wall=[box(vertical-t/2,y-t/2,vertical+t/2,cy-half),box(vertical-t/2,cy+half,vertical+t/2,y+h+t/2)]
    walls=[box(x-t/2,y-t/2,x+w+t/2,y+t/2),box(x-t/2,y+h-t/2,x+w+t/2,y+h+t/2),left if not d['espelhado'] else right]+opened_wall
    # Aproximação de uma folha dobrável com projeção de 0,40 m, aberta;
    # o movimento completo, espessura de marcos e o mecanismo não são testados.
    if d['espelhado']:
        panel=box(x-.40,cy-half-.02,x,cy-half+.02)
        line=LineString([(x-.85,cy),(x+w-1.25,cy)])
    else:
        panel=box(x+w,cy-half-.02,x+w+.40,cy-half+.02)
        line=LineString([(x+w+.85,cy),(x+1.25,cy)])
    path=line.buffer(.30,cap_style=1,join_style=2)
    for label,obj in list(fixture.items())+[('painel dobrado',panel)]+[(f'parede {i}',wall) for i,wall in enumerate(walls)]:
        assert path.intersection(obj).area<1e-8,f'{key}: ensaio de passagem colide com {label}'
    print(f'{key}: ensaio de faixa 0,60 m do vestíbulo até interior sem colisão; área frontal da bacia 0,60 × 0,40 m sem colidir com box/cuba.')
print('Limites: pressupõe paredes de 0,15 m, geometria simplificada e porta dobrável hipotética totalmente aberta; não verifica marcos, abertura/fechamento, ergonomia, simultaneidade, box em uso, janela, ventilação, instalações ou conformidade legal.')
