"""Mobiliário de estudo com acervo CC0; NÃO é modelo arquitetônico final.

As posições de camas, mesa e cadeiras reproduzem as posições esquemáticas do SVG.
Acabamentos, folgas, colisões, instalações e acessos devem ser conferidos.
"""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Matrix

root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from detalhes_mobiliario import bed,wardrobe_list,office,tv
from detalhes_banhos import detalhes_banho,detalhes_banho_master
from detalhes_lavabo import detalhes_lavabo
from elementos_04 import ARCH_GLB,WEB_GLB,BLEND
assets=root.parent/'SITE-ISOLADO-BASE-f51f2c9'/'assets'/'revisadas'/'modelos'
source=root/ARCH_GLB
destination=root/WEB_GLB
blend=root/BLEND
if destination.exists() or blend.exists():raise SystemExit('Saída existente; preservar.')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(source))
def architectural_material(name,color,roughness=.75,alpha=1,metallic=0,noise=False):
    mat=bpy.data.materials.new(name);mat.use_nodes=True;mat.diffuse_color=(*color,alpha)
    bsdf=mat.node_tree.nodes.get('Principled BSDF');bsdf.inputs['Base Color'].default_value=(*color,1);bsdf.inputs['Roughness'].default_value=roughness;bsdf.inputs['Metallic'].default_value=metallic;bsdf.inputs['Alpha'].default_value=alpha
    if alpha<1:mat.surface_render_method='DITHERED'
    if noise:
        nodes=mat.node_tree.nodes;links=mat.node_tree.links;n=nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=80;n.inputs['Detail'].default_value=2
        bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.015;links.new(n.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],bsdf.inputs['Normal'])
    return mat
wallmat=architectural_material('Reboco marfim claro',(.79,.76,.67),noise=True)
roofmat=architectural_material('Cobertura impermeabilizada clara',(.74,.72,.65),.90,noise=True)
floormat=architectural_material('Piso acetinado areia',(.58,.53,.43),.58,noise=True)
grassmat=architectural_material('Jardim natural',(.20,.29,.12),.95,noise=True)
glassmat=architectural_material('Vidro esquadrias',(.24,.43,.46),.10,.42,.10)
metalmat=architectural_material('Alumínio grafite',(.14,.17,.16),.32,1,.55)
watermat=architectural_material('Água piscina',(.06,.34,.41),.07,.64,.08,True)
poolmat=architectural_material('Revestimento piscina',(.23,.51,.54),.38)
for ob in bpy.data.objects:
    if ob.type!='MESH':continue
    n=ob.name
    mat=glassmat if n.startswith('Vidro') or n.startswith('Porta aberta') and 'varanda' in n else metalmat if n.startswith(('Marco','Calha','Condutor','Corrimão','Prolongamento')) else watermat if n.startswith('Piscina — água') else poolmat if n.startswith('Piscina') else grassmat if n.startswith('Terreno') else roofmat if n.startswith(('Cobertura','Caimento')) else floormat if n.startswith(('Piso','Faixa','Patamar','Lance')) else wallmat if n.startswith(('Parede','Guarda','Pilar','Viga','Separação')) else None
    if mat:ob.data.materials.clear();ob.data.materials.append(mat)
# Troca as louças genéricas pelas representações arredondadas abaixo.
for obj in list(bpy.data.objects):
    if obj.name.startswith('Louça esquemática'):bpy.data.objects.remove(obj,do_unlink=True)
model=json.loads((root/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
prototypes={}
def prototype(name):
    if name in prototypes:return prototypes[name]
    before=set(bpy.data.objects)
    if name in ('carSegmentA','suv2'):
        bpy.ops.wm.obj_import(filepath=str(root/'ACERVO-SCOPIA-CONVERTIDO'/(name+'.obj')))
    else:
        bpy.ops.import_scene.gltf(filepath=str(assets/(name+'.gltf')))
    objects=[o for o in bpy.data.objects if o not in before and o.type=='MESH']
    bpy.context.view_layer.update()
    vertices=[o.matrix_world @ Vector(v) for o in objects for v in o.bound_box]
    lo=Vector([min(v[i] for v in vertices) for i in range(3)])
    hi=Vector([max(v[i] for v in vertices) for i in range(3)])
    for o in objects:o.hide_render=True;o.hide_viewport=True
    prototypes[name]=(objects,lo,hi)
    return prototypes[name]
def place(name,label,position,dimensions,angle=0):
    objects,lo,hi=prototype(name);size=hi-lo
    if name in ('carSegmentA','suv2'):
        factor=min(dimensions[0]/size.x,dimensions[1]/size.y,dimensions[2]/size.z)
        S=Matrix.Diagonal(Vector((factor,factor,factor,1)))
    else:
        S=Matrix.Diagonal(Vector((dimensions[0]/size.x,dimensions[1]/size.y,dimensions[2]/size.z,1)))
    shift=Matrix.Translation(Vector((-(lo.x+hi.x)/2,-(lo.y+hi.y)/2,-lo.z)))
    T=Matrix.Translation(Vector(position)) @ Matrix.Rotation(angle,4,'Z') @ S @ shift
    for original in objects:
        ob=original.copy();ob.data=original.data;ob.name=label;ob.hide_render=False;ob.hide_viewport=False
        bpy.context.scene.collection.objects.link(ob);ob.parent=None;ob.matrix_world=T @ original.matrix_world
        ob['complemento_igz']='veiculos' if name in ('carSegmentA','suv2') else 'superior' if position[2]>3 else 'terreo'
def material(name,color):
    mat=bpy.data.materials.new(name);mat.diffuse_color=(*color,1);return mat
linen=material('Tecido claro de estudo',(.85,.85,.78));wood=material('Madeira de estudo',(.34,.22,.13));ceramic=material('Louça branca esquemática',(.92,.93,.91));shower=material('Piso de box esquemático',(.69,.72,.70));screen=material('Tela da TV',(.018,.024,.022))
def cube(name,x,y,z,w,h,depth,mat):
    bpy.ops.mesh.primitive_cube_add(size=1,location=(x,y,z+depth/2));o=bpy.context.object;o.name=name;o.dimensions=(w,h,depth)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mat)
    o['complemento_igz']='superior' if z>=3.15 else 'terreo'
def room(level,rid):return next(r for r in model[level] if r['id']==rid)
for level,rid in [('terreo','q1'),('terreo','q2'),('terreo','q3'),('superior','master'),('superior','q5')]:
    r=room(level,rid);z=0 if level=='terreo' else 3.15;x0,y0,x1,y1=bed(r);x=(x0+x1)/2;y=(y0+y1)/2
    place('old_bed_frame','Cama CC0 '+rid,(x,y,z),(1.56,1.92,1.00))
    cube('Colchão esquemático '+rid,x,y,z+.25,1.45,1.80,.20,linen)
    cube('Travesseiro esquemático '+rid,x,y-.57,z+.46,1.0,.32,.12,linen)
r=room('terreo','estar');place('sofa_02','Sofá CC0',(r['x']+1.45,r['y']+1.50,0),(2.30,.80,.85))
tx0,ty0,tx1,ty1=tv(r);cube('TV de estudo',(tx0+tx1)/2,(ty0+ty1)/2,1.0,tx1-tx0,ty1-ty0,.72,screen)
for level,rid in [('terreo','q1'),('terreo','q2'),('terreo','q3'),('superior','q5'),('superior','closet')]:
    z=0 if level=='terreo' else 3.15
    for x0,y0,x1,y1 in wardrobe_list(room(level,rid)):
        cube('Armário de portas de correr '+rid,(x0+x1)/2,(y0+y1)/2,z,x1-x0,y1-y0,2.15,wood)
desk=office(room('superior','escritorio'));x0,y0,x1,y1=desk['mesa']
place('wooden_table_02','Mesa do escritório CC0',((x0+x1)/2,(y0+y1)/2,3.15),(x1-x0,y1-y0,.76))
x0,y0,x1,y1=desk['cadeira'];place('modern_arm_chair_01','Cadeira do escritório CC0',((x0+x1)/2,(y0+y1)/2,3.15),(x1-x0,y1-y0,.90),math.pi)
def dining(r,count):
    x=r['x']+r['w']/2;y=r['y']+r['h']/2;w=2.8 if count==10 else 2.5
    place('wooden_table_02','Mesa CC0 '+r['id'],(x,y,0),(w,1.0,.76))
    for j in range(4):
        xx=x-w/2+.32+(w-.64)*j/3
        for sign in (-1,1):place('dining_chair_02',f'Cadeira CC0 {r["id"]}',(xx,y+sign*.78,0),(.45,.50,.90),0 if sign<0 else math.pi)
    if count==10:
        for sign in (-1,1):place('dining_chair_02','Cadeira CC0 ponta',(x+sign*(w/2+.28),y,0),(.45,.50,.90),sign*math.pi/2)
dining(room('terreo','gourmet'),10);dining(room('terreo','quiosque'),8)
cube('Cooktop de estudo',9.905,14.80,.91,.48,.58,.025,wood)
cube('Cuba inox cozinha',9.905,16.10,.91,.42,.60,.025,ceramic)
# Peças de volumes simplificados, dentro dos envelopes usados na auditoria 2D.
for level,rid in [('terreo','b1'),('terreo','b2'),('terreo','b3'),('terreo','lavabo'),('superior','banho-master'),('superior','banho-5')]:
    r=room(level,rid);z=0 if level=='terreo' else 3.15
    details=detalhes_lavabo(r) if rid=='lavabo' else detalhes_banho_master(r) if rid=='banho-master' else detalhes_banho(r)
    for part in ('box','bacia','cuba'):
        if part not in details:continue
        x0,y0,x1,y1=details[part];x=(x0+x1)/2;y=(y0+y1)/2;w=x1-x0;h=y1-y0
        if part=='box':cube('Box de banho — base esquemática '+rid,x,y,z+.01,w,h,.04,shower)
        elif part=='cuba':
            cube('Lavatório — volume esquemático '+rid,x,y,z+.70,w,h,.15,ceramic)
            cube('Coluna de lavatório '+rid,x,y,z,w*.34,h*.34,.70,ceramic)
        else:
            bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,location=(x,y,z+.28));o=bpy.context.object;o.name='Bacia — volume esquemático '+rid;o.dimensions=(w,h,.40)
            bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ceramic)
for index,x in enumerate((2.89,5.39,7.89)):
    place('carSegmentA' if index==1 else 'suv2',f'Veículo Scopia CC-BY {index+1}',(x,2.15,-.08),(1.75,4.10,1.55))
# Exclui protótipos ocultos da exportação, preservando as cópias vinculadas.
for objects,_,_ in prototypes.values():
    for obj in objects:bpy.data.objects.remove(obj,do_unlink=True)
# A apresentação mantém os originais; o IGZ recebe cópias leves dos acessórios.
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.wm.save_as_mainfile(filepath=str(blend))
bpy.ops.export_scene.gltf(filepath=str(destination),export_format='GLB',export_cameras=False,export_lights=False)
# Complementos por pavimento: importáveis no IGZ, com texturas incorporadas.
for kind in ('terreo','superior','veiculos'):
    bpy.ops.object.select_all(action='DESELECT')
    copies=[]
    for obj in list(bpy.data.objects):
        if obj.get('complemento_igz')!=kind or obj.name.startswith(('Box de banho','Lavatório','Coluna de lavatório','Bacia')):continue
        copy=obj.copy();copy.data=obj.data.copy();bpy.context.scene.collection.objects.link(copy);copies.append(copy)
        copy.select_set(True);bpy.context.view_layer.objects.active=copy
        if len(copy.data.polygons)>1000:
            modifier=copy.modifiers.new('Simplificação apenas no IGZ','DECIMATE');modifier.ratio=.20
            bpy.ops.object.modifier_apply(modifier=modifier.name)
        copy.select_set(False)
    for copy in copies:copy.select_set(True)
    bpy.ops.export_scene.gltf(filepath=str(root/f'COMPLEMENTO-04-R1-{kind}.glb'),export_format='GLB',use_selection=True,export_cameras=False,export_lights=False)
    for copy in copies:bpy.data.objects.remove(copy,do_unlink=True)
bpy.ops.object.select_all(action='DESELECT')
print('MAQUETE DE ESTUDO MOBILIADA:',destination)
print('Móveis CC0 Poly Haven e veículos Scopia CC BY 3.0, escalados. Não comprova conforto, manobras, estrutura ou segurança.')
