"""Integra só a casa 4 numa cópia atual do GitHub; não faz commit/push."""
from pathlib import Path
import re,json,shutil,zipfile,base64,hashlib,subprocess,html
from PIL import Image
from quantitativos04 import calculate
R=Path(__file__).resolve().parent;SITE=R.parent/'PUBLICACAO-04';A=SITE/'assets/projetos-4-5-6/4';A.mkdir(parents=True,exist_ok=True)
assert (SITE/'.git').is_dir() and (SITE/'projetos-7-8-9.html').exists()
_,areas,_=calculate()
def number(n):return f'{n:.2f}'.replace('.',',')
def write(p,s):p.write_text(s,encoding='utf8',newline='\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['CASA-04-R1-MOBILIADA.igz','CASA-04-R1.glb','REVISAO-04-R1.json','QUADRO-AREAS-04-R1.json','PASSAGEM-LATERAL-04-P1.json']:
    assert (R/n).is_file(),n;shutil.copy2(R/n,A/n)
for p in (R/'PRANCHAS-R1').glob('*.svg'):shutil.copy2(p,A/p.name)
pdf=R.parent/'SITE-ISOLADO-BASE-f51f2c9/assets/atrio04/r1/04-pranchas-R1.pdf'
if not (A/pdf.name).exists():shutil.copy2(pdf,A/pdf.name)
for p in (R/'RENDERS-R1').glob('*.png'):
    with Image.open(p) as im:im.convert('RGB').save(A/(p.stem+'.jpg'),quality=93,optimize=True)
photos=json.loads((R/'FOTOS-R1.json').read_text(encoding='utf8'))
for e in photos:shutil.copy2(R/e['arquivo'],A/e['arquivo'])
photo_selection=R/'FOTOS-PUBLICACAO-04.json'
selected=json.loads(photo_selection.read_text(encoding='utf8')) if photo_selection.exists() else []
if photo_selection.exists():shutil.copy2(photo_selection,A/photo_selection.name)
if (R/'REVISAO-FOTOS-PUBLICACAO.md').exists():shutil.copy2(R/'REVISAO-FOTOS-PUBLICACAO.md',A/'REVISAO-FOTOS-PUBLICACAO.md')
for e in selected:
    assert (R/e['arquivo']).is_file();shutil.copy2(R/e['arquivo'],A/e['alias'])
F=A/'fotos';F.mkdir(exist_ok=True)
for i,photo,model in [('01','NANOBANANA-R1-LAZER.png','04-lazer-R1.png'),('02','NANOBANANA-R1-FACHADA-02.png','04-fachada-R1.png')]:
    chosen=next((R/e['arquivo'] for e in selected if e['alias']==photo),R/photo)
    with Image.open(chosen) as im:
        im.convert('RGB').save(F/(i+'.jpg'),quality=94,optimize=True);im.thumbnail((480,320));im.convert('RGB').save(F/(i+'-thumb.jpg'),quality=88,optimize=True)
    with Image.open(R/'RENDERS-R1'/model) as im:im.convert('RGB').save(F/(i+'-modelo3d.jpg'),quality=93,optimize=True)
shutil.copy2(R/'MEMORIAL-PUBLICO-04.md',A/'MEMORIAL-04-R1.md')
credits=R.parent.parent/'MODELOS REVISADOS/CREDITOS-ACERVO-3D.md';shutil.copy2(credits,A/credits.name)
review_photos=(R/'REVISAO-FOTOS-R1.md').read_text(encoding='utf8')
review_photos=re.sub(r'https://gemini\.google\.com/app/[^\s)]+','[sessão privada omitida]',review_photos)
review_photos='> Publicação da apresentação autorizada pelo usuário em 13/11/2026. Registro abaixo preserva o histórico de seleção das imagens, não um novo bloqueio de publicação.\n\n'+review_photos
write(A/'REVISAO-FOTOS-R1.md',review_photos)
ref=(SITE/'projetos-7-8-9.html').read_text(encoding='utf8');style=re.search(r'<style>(.*?)</style>',ref,re.S).group(1)
top=re.search(r'<div class="top">.*?</nav></div></div>',ref,re.S).group(0)
top=top.replace('href="projetos-4-5-6.html"','href="projetos-4-5-6.html" aria-current="page"').replace('href="projetos-7-8-9.html" aria-current="page"','href="projetos-7-8-9.html"')
group=(R/'publicacao-04.template.html').read_text(encoding='utf8')
for k,v in {'STYLE':style,'TOP':top,'AREA':number(sum(areas['construida_estimada'].values())),'NATURAL':number(areas['solo_natural_percentual']),'GLB_MB':number((A/'CASA-04-R1.glb').stat().st_size/1e6)}.items():group=group.replace('{{'+k+'}}',v)
group=group.replace('Use o botão para comparar com a geometria de referência.','Use o botão para comparar com a geometria de referência. A posição e a quantidade dos pisantes nas fotos são interpretativas; o trajeto conferido está no modelo e nas plantas.')
assert '{{' not in group;write(SITE/'projetos-4-5-6.html',group)
# A apresentação detalhada deriva do HTML R1; a integração não altera 1–3 ou7–9.
detail=(R.parent/'SITE-ISOLADO-BASE-f51f2c9/entrega-04.html').read_text(encoding='utf8')
detail=detail.replace('assets/atrio04/r1/','assets/projetos-4-5-6/4/')
detail=detail.replace('entrega-04.html','projeto-4.html')
detail=re.sub(r'<header class="wrap masthead">.*?</header>',top,detail,flags=re.S)
detail=re.sub(r'<div class="project-tabs".*?</div>','<p class="hint"><a href="projetos-4-5-6.html?projeto=4">← Projetos 4 · 5 · 6</a> / Casa 4 · detalhamento</p>',detail,flags=re.S)
detail=detail.replace('</style></head>','\n'+style+'\n.top .in{max-width:1360px}.top nav a{color:#fff}main.wrap{max-width:1360px}\n</style></head>')
for old,new in [
 ('apresentação para aprovação','apresentação do estudo'),('Apresentação para aprovação','Apresentação do estudo'),
 ('Entrega local. Publicação no GitHub somente após aprovação.','Estudo preliminar · IngeTrazo + Blender.'),
 ('Interpretação fotográfica por IA, para sua aprovação','Interpretação fotográfica por IA'),
 ('Interpretações fotográficas para sua aprovação.','Interpretações fotográficas do projeto.'),
 ('São candidatas, não imagens aprovadas para substituir as anteriores.','Selecionadas para esta apresentação após comparação visual com os renders de referência.'),
 ('para sua aprovação','da revisão R1-P1'),('para aprovação','para avaliação arquitetônica'),
 ('Entrega local','Apresentação do estudo'),('sem publicação no GitHub','estudo preliminar'),
 ('As imagens antigas foram preservadas no histórico, sem substituição no site publicado.','As imagens e os modelos das demais casas foram preservados. Os pisantes da casa 4 foram afastados das janelas na revisão de publicação.'),
 ('aguardam aprovação','foram selecionadas para apresentação'),
]:detail=detail.replace(old,new)
detail=detail.replace('Na construção,','Na construção,')
# Há diferença de orientação entre vista superior renderizada e prancha vetorial.
detail=detail.replace('Térreo humanizado 3D · coberturas e pavimento superior ocultos.','Térreo humanizado 3D · rua embaixo; nas pranchas SVG, rua em cima.')
detail=detail.replace('Superior humanizado 3D · master, escritório, varanda e quinto quarto.','Superior humanizado 3D · rua embaixo; master, escritório, varanda e quinto quarto.')
detail=detail.replace('Texturas, paisagismo e detalhes permanecem interpretações;','Texturas, paisagismo, posição/quantidade dos pisantes nas fotos e pequenos detalhes permanecem interpretações;')
write(SITE/'projeto-4.html',detail)
# Visualizador leve, reutilizando exatamente os controles já ensaiados na R1.
js=re.findall(r'<script>(.*?)</script>',detail,re.S)[-1];js=js[js.index('const canvas='):];js=js.rsplit('})();',1)[0]
js=js.replace('assets/projetos-4-5-6/4/CASA-04-R1.glb','CASA-04-R1.glb')
viewer='''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Casa 4 · 3D navegável</title><style>*{box-sizing:border-box}body{margin:0;background:#f6f2ea;color:#22302a;font:13px system-ui}.bar{display:flex;flex-wrap:wrap;gap:5px;padding:8px}button{background:#fffdf8;color:#22302a;border:1px solid #b8c3b3;border-radius:4px;padding:7px 10px;font:inherit;cursor:pointer}button[aria-pressed=true]{background:#2e4937;color:#fff}button:focus-visible,a:focus-visible{outline:3px solid #ae7655}#model{display:block;width:100%;height:calc(100dvh - 147px);min-height:250px;touch-action:none}#status{margin:7px 10px;min-height:20px}.info{padding:0 10px 8px;font-size:11px;color:#5f6b62}@media(min-width:700px){#model{height:calc(100dvh - 125px)}}</style><div class="bar"><button data-mode="full" aria-pressed="true">Completo</button><button data-mode="roof" aria-pressed="false">Sem cobertura</button><button data-mode="ground" aria-pressed="false">Térreo aberto</button><button data-mode="upper" aria-pressed="false">Superior aberto</button></div><div class="bar"><button id="reset">Conjunto</button><button id="front">Fachada</button><button id="pool">Piscina</button><button id="stair">Escada</button><button id="top">De cima</button><button id="fullscreen">Tela cheia ⤢</button></div><canvas id="model" tabindex="0" aria-label="Modelo tridimensional navegável da casa 4"></canvas><p id="status" role="status">Carregando modelo…</p><div class="info">Arraste para girar; roda para aproximar; dois dedos para deslocar. Estudo preliminar. <a href="../../../projetos-4-5-6.html?projeto=4" target="_top">Voltar à apresentação</a></div>'''
viewer+=''.join('<script src="../../revisadas/'+n+'"></script>' for n in ['three.min.js','OrbitControls.js','GLTFLoader.js'])+'<script>(()=>{\'use strict\';'+js+'})();</script></html>'
write(A/'modelo-3d.html',viewer)
# Offline: só o projeto 4; recursos visuais e bibliotecas incorporados.
offline=detail
for n in ['three.min.js','OrbitControls.js','GLTFLoader.js']:
    offline=offline.replace('<script src="assets/revisadas/'+n+'"></script>','<script>'+(SITE/'assets/revisadas'/n).read_text(encoding='utf8').replace('</script>',r'<\/script>')+'</script>')
model=base64.b64encode((A/'CASA-04-R1.glb').read_bytes()).decode('ascii')
load="const raw=atob('"+model+"'),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);new THREE.GLTFLoader().parse(bytes.buffer,'',loaded,failed);"
offline=offline.replace("new THREE.GLTFLoader().load('assets/projetos-4-5-6/4/CASA-04-R1.glb',loaded,undefined,failed);",load)
for filename in set(re.findall(r'(?:src|href)="assets/projetos-4-5-6/4/([^"?#]+)"',offline)):
    p=A/filename
    if p.suffix.lower() not in ['.png','.jpg','.svg']:continue
    mime='image/svg+xml' if p.suffix=='.svg' else 'image/png' if p.suffix=='.png' else 'image/jpeg'
    offline=offline.replace('"assets/projetos-4-5-6/4/'+filename+'"','"data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode('ascii')+'"')
offline=offline.replace('assets/projetos-4-5-6/4/','').replace('href="index.html"','href="https://aquinogr.github.io/pedrinhas/"').replace('href="projetos-4-5-6.html"','href="https://aquinogr.github.io/pedrinhas/projetos-4-5-6.html"').replace('href="projetos-7-8-9.html"','href="https://aquinogr.github.io/pedrinhas/projetos-7-8-9.html"')
write(A/'CASA04-OFFLINE.html',offline)
quadros=R.parent/'SITE-ISOLADO-BASE-f51f2c9/assets/atrio04/r1/04-quadros-R1.html'
write(A/quadros.name,quadros.read_text(encoding='utf8').replace('assets/atrio04/r1/',''))
# Só substituir o cartão 04 e os destinos dos cartões reservados 05/06.
p=SITE/'index.html';s=p.read_text(encoding='utf8')
cards=list(re.finditer(r'<a class="hc"[^>]*>.*?</a>',s,re.S))
for n in [4,5,6]:
    found=[m for m in cards if re.search(r'<b>0'+str(n)+r' ·',m.group())];assert len(found)==1,(n,'Cartão ausente ou ambíguo')
    old=found[0].group()
    if n==4:new='<a class="hc" href="projetos-4-5-6.html?projeto=4#fotos"><img src="assets/projetos-4-5-6/4/fotos/01-thumb.jpg" alt="" loading="lazy" width="480" height="320"><span class="hc-t"><b>04 · Casa do Átrio Social</b><small>Cinco quartos · piscina pequena e quiosque</small></span></a>'
    else:new=re.sub(r'href="[^"]+"','href="projetos-4-5-6.html?projeto='+str(n)+'"',old,count=1)
    s=s.replace(old,new,1)
write(p,s)
p=SITE/'README.md';s=p.read_text(encoding='utf8');s=s.replace('- **4, 5 e 6**: em preparação (`projetos-4-5-6.html`).','- **4 — Átrio Social**: `projetos-4-5-6.html?projeto=4`, com detalhamento em `projeto-4.html`, plantas cotadas, fotos interpretativas, 3D e arquivo IngeTrazo.\n- **5 e 6**: espaços reservados na mesma página, ainda em preparação.');write(p,s)
# Fontes do estudo, sem sessões privadas nem programas/ambientes instalados.
oldzip=R.parent/'SITE-ISOLADO-BASE-f51f2c9/assets/atrio04/r1/FONTES-04-R1.zip'
with zipfile.ZipFile(oldzip) as src,zipfile.ZipFile(A/'FONTES-04-R1.zip','w',compression=zipfile.ZIP_DEFLATED) as out:
    for info in src.infolist():
        if info.is_dir():continue
        name=info.filename;p=R/name
        if name=='MEMORIAL-04-R1.md':data=(A/'MEMORIAL-04-R1.md').read_bytes()
        elif name=='REVISAO-FOTOS-R1.md':data=(A/name).read_bytes()
        else:data=p.read_bytes() if p.is_file() else src.read(name)
        if name.endswith(('.md','.html','.py','.json','.cjs')):
            text=data.decode('utf8');text=re.sub(r'https://gemini\.google\.com/app/[^\s)\"\']+','[sessão privada omitida]',text);data=text.encode('utf8')
        out.writestr(name,data)
    for n in ['auditar-lateral-publicacao.py','PASSAGEM-LATERAL-04-P1.json','publicacao-04.template.html','preparar-publicacao-04.py','MEMORIAL-PUBLICO-04.md','FOTOS-PUBLICACAO-04.json','REVISAO-FOTOS-PUBLICACAO.md','QA-PUBLICACAO-04-LOCAL.json','auditar-integracao-publica.py','testar-publicacao-04.cjs']:
        if (R/n).exists():out.write(R/n,n)
manifest=dict(projeto=4,revisao='R1-P1',escopo='Estudo preliminar; publicação da apresentação autorizada',base_commit=subprocess.check_output(['git','-C',str(SITE),'rev-parse','HEAD'],text=True).strip(),arquivos=[dict(arquivo=str(p.relative_to(A)).replace('\\','/'),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(A.rglob('*')) if p.is_file() and p.name!='MANIFESTO-PUBLICACAO-04.json'])
write(A/'MANIFESTO-PUBLICACAO-04.json',json.dumps(manifest,ensure_ascii=False,indent=2))
print('Integração preparada na cópia atual:',SITE,'; nenhum commit ou push foi realizado.')
