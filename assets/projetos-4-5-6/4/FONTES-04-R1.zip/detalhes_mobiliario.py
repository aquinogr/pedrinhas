"""Retângulos de mobiliário em metros, compartilhados por planta, auditoria e 3D."""
def bed(r):
    x=r['x']+r['w']/2;y=r['y']+r['h']*.40
    if r['id']=='q1':x+=.05
    if r['id'] in ('q2','q3'):x-=.275
    return (x-.78,y-.96,x+.78,y+.96)

def wardrobe(r):
    x,y,w,h=(r[k] for k in ('x','y','w','h'))
    if r['id']=='q1':return (x+.075,y+.20,x+.675,y+1.60)
    if r['id'] in ('q2','q3'):return (x+w-.675,y+.20,x+w-.075,y+2.50)
    return None

def wardrobe_list(r):
    simple=wardrobe(r)
    if simple:return [simple]
    x,y,w,h=(r[k] for k in ('x','y','w','h'))
    if r['id']=='q5':return [(x+w-.675,y+.20,x+w-.075,y+1.00),(x+w-.675,y+2.30,x+w-.075,y+3.20)]
    if r['id']=='closet':return [(x+.075,y+.20,x+.675,y+h-.20),(x+w-.675,y+.20,x+w-.075,y+h-.20)]
    return []

def office(r):
    x,y=r['x'],r['y']
    return {'mesa':(x+2.05,y+.40,x+3.45,y+1.00),
            'cadeira':(x+2.50,y+1.45,x+3.00,y+1.95)}

def tv(r):
    # Sofá transversal voltado para +Y: TV na parede de fundo, não na lateral.
    x,y,h=r['x'],r['y'],r['h']
    return (x+.85,y+h-.15,x+2.05,y+h-.075)
