"""Renders rastreáveis da R1. Nenhuma alteração de arquitetura para a fotografia."""
import bpy,sys,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(root/'CASA-04-R1.blend'))
out=root/'RENDERS-R1';out.mkdir(exist_ok=True)
scene=bpy.context.scene
world=bpy.data.worlds.new('Céu Pedrinhas');world.use_nodes=True;scene.world=world
nodes=world.node_tree.nodes;links=world.node_tree.links
sky=nodes.new('ShaderNodeTexSky');sky.sky_type='NISHITA';sky.sun_elevation=math.radians(38);sky.sun_rotation=math.radians(145);sky.altitude=.4;sky.air_density=1.1;sky.dust_density=1.6
links.new(sky.outputs['Color'],nodes['Background'].inputs['Color']);nodes['Background'].inputs['Strength'].default_value=.3
bpy.ops.object.light_add(type='SUN',location=(0,0,20));sun=bpy.context.object;sun.rotation_euler=(.6,-.55,-.7);sun.data.energy=2.1;sun.data.angle=.08
# Plano neutro fora do lote: fundo de estúdio, não proposta para o terreno vizinho.
bpy.ops.mesh.primitive_plane_add(size=200,location=(6,17.5,-1.6));ground=bpy.context.object;ground.name='Fundo de apresentação, fora da proposta'
mat=bpy.data.materials.new('Areia do fundo');mat.diffuse_color=(.50,.45,.35,1);ground.data.materials.append(mat)
scene.render.engine='CYCLES';scene.cycles.samples=40;scene.cycles.use_denoising=True
scene.cycles.max_bounces=6;scene.cycles.transparent_max_bounces=8
scene.render.resolution_x=1600;scene.render.resolution_y=1060;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
def shot(name,loc,target,scale):
    bpy.ops.object.camera_add(location=loc);cam=bpy.context.object;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.type='ORTHO';cam.data.ortho_scale=scale;cam.data.lens=45;scene.camera=cam
    scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
shot('04-fachada-R1',(22,-19,13),(6,8,2),21)
shot('04-lazer-R1',(-15,44,16),(6,26.5,1.5),24)
# Plantas humanizadas em vista superior; paredes se mantêm em altura completa.
for ob in scene.objects:
    if ob.type!='MESH':continue
    lo=min((ob.matrix_world@Vector(v)).z for v in ob.bound_box)
    if lo>=3.0-.001 or ob.name.startswith(('Cobertura','Caimento')):ob.hide_render=True
scene.render.resolution_x=1000;scene.render.resolution_y=1700;scene.cycles.samples=24
shot('04-terreo-3D-R1',(6,17.5,50),(6,17.5,0),38)
for ob in scene.objects:
    if ob.type!='MESH' or ob==ground:continue
    lo=min((ob.matrix_world@Vector(v)).z for v in ob.bound_box)
    hi=max((ob.matrix_world@Vector(v)).z for v in ob.bound_box)
    ob.hide_render=hi<3.10 or lo>=6.0 or ob.name.startswith(('Cobertura','Caimento'))
shot('04-superior-3D-R1',(6,11.75,45),(6,11.75,3.15),18)
print('Quatro renders R1 gerados diretamente do modelo.',flush=True)
