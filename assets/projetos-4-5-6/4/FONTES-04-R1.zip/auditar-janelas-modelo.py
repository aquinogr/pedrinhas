"""Testa envelopes máximos das folhas externas V5 contra limites e veículos parados.

Não testa outras obstruções, abertura efetiva, desempenho ou norma.
"""
from pathlib import Path
from math import radians,sin,cos
import json
from shapely.geometry import box
from elementos_04 import CUTS,windows as window_specs

root=Path(__file__).resolve().parent
cuts=json.loads((root/CUTS).read_text(encoding='utf-8'))
data=json.loads((root/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
cars=json.loads((root/'ENVELOPES-VEICULOS-ESTUDO.json').read_text(encoding='utf-8'))
windows=[c for c in cuts if 'janela' in c['nome'] or 'maxim-ar' in c['nome']]
assert len(windows)>0
for c in windows:
    spec=next(w for w in window_specs(data) if w['nivel']==c['nivel'] and w['nome']==c['nome'])
    h=c['altura']-.06; angle=spec['angulo'];direction=-1 if spec['lado'] in ('esquerda','frente') else 1
    projection=h*sin(radians(angle));zlevel=0 if c['nivel']=='terreo' else 3.15
    ztop=zlevel+c['peitoril']+c['altura']-.03; zbottom=ztop-h*cos(radians(angle))
    a=c['centro']-c['largura']/2+.03;b=c['centro']+c['largura']/2-.03;f=c['fixo']
    if c['eixo']=='v':
        sign=direction;leaf=box(min(f,f+sign*projection),a,max(f,f+sign*projection),b)
    else:
        sign=direction;leaf=box(a,min(f,f+sign*projection),b,max(f,f+sign*projection))
    left,front,right,back=leaf.bounds
    assert left>=-1e-6 and right<=12+1e-6 and front>=-1e-6 and back<=35+1e-6,f'Folha fora do lote: {c["nome"]}'
    for car in cars:
        lo,hi=car['min'],car['max']
        if zbottom<hi[2] and ztop>lo[2]:
            assert leaf.intersection(box(lo[0],lo[1],hi[0],hi[1])).area<1e-8,f'Folha colide com carro {car["id"]}: {c["nome"]}'
    print(f'{c["nivel"]} {c["nome"]}: abre para fora, {angle}°, projeção {projection:.2f} m; sem colisão com divisa ou carros parados no cenário modelado.')
print('NÃO COMPROVA: abertura real de produtos, rufo/beiral/pilares, vegetação, pessoas, manutenção, ventilação, chuva ou conformidade normativa.')
