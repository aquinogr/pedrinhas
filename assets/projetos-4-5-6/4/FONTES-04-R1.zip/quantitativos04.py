"""Áreas estimadas a partir dos polígonos do estudo, sem certificação urbanística."""
from pathlib import Path
import json,math
from shapely.geometry import box
from shapely.ops import unary_union
from elementos_04 import PAVING,PARKING,ROOFS,PILLARS,windows
ROOT=Path(__file__).resolve().parent

def calculate():
    d=json.loads((ROOT/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
    lot=box(0,0,12,35);floors={};useful={};rooms=[]
    for level in ('terreo','superior'):
        shapes=[]
        for r in d[level]:
            rid=r['id'];rect=box(r['x'],r['y'],r['x']+r['w'],r['y']+r['h'])
            if rid=='patio':continue
            if rid in ('quiosque','varanda'):gross=rect
            else:gross=rect.buffer(.075,join_style=2)
            if rid!='escada-superior':shapes.append(gross)
            w=max(0,r['w']-.15);h=max(0,r['h']-.15)
            interior=rect if rid in ('quiosque','varanda') else rect.buffer(-.075,join_style=2)
            columns=[box(x-width/2,y-width/2,x+width/2,y+width/2) for _,x,y,z0,z1,width in PILLARS if (level=='terreo' and z0<3) or (level=='superior' and z1>3.15)]
            area=interior.difference(unary_union(columns)).area
            if rid=='escada-superior':area=0
            rooms.append(dict(nivel=level,id=rid,nome=r['uso'],largura_util=w,profundidade_util=h,area_util=round(area,4)))
        shapes += [box(x-width/2,y-width/2,x+width/2,y+width/2) for _,x,y,z0,z1,width in PILLARS if (level=='terreo' and z0<3) or (level=='superior' and z1>3.15)]
        floors[level]=unary_union(shapes)
        useful[level]=sum(r['area_util'] for r in rooms if r['nivel']==level and r['id'] not in ('escada','escada-superior'))
    # Para solo natural, conservador: inclui também a sombra dos beirais, vagas
    # inteiras, pisos externos e a piscina. Piso drenante não vira solo natural.
    shade=unary_union([box(*rect) for _,rect,_,_,_ in ROOFS])
    hard=unary_union([box(*rect) for _,rect in PAVING]+[box(*r) for r in PARKING])
    p=d['piscina'];water=box(p['x']-.15,p['y']-.15,p['x']+p['w']+.15,p['y']+p['h']+.15)
    columns=unary_union([box(x-width/2,y-width/2,x+width/2,y+width/2) for _,x,y,_,_,width in PILLARS])
    occupied=unary_union([shade,hard,water,columns]).intersection(lot)
    natural=lot.difference(occupied)
    projection=unary_union(list(floors.values()))
    wcheck=[]
    for r in rooms:
        if r['id'] not in ('q1','q2','q3','q5','master','estar','escritorio','b1','b2','b3','banho-master','banho-5','lavabo'):continue
        ws=[w for w in windows(d) if w['ambiente']==r['id'] and w['nivel']==r['nivel']]
        nominal=sum(w['largura']*w['altura'] for w in ws)
        if r['id'] in ('master','escritorio'):nominal+=1.8*2.2
        target=r['area_util']/(8 if r['id'] in ('b1','b2','b3','banho-master','banho-5','lavabo') else 6)
        wcheck.append(dict(ambiente=r['nome'],vao_nominal=round(nominal,3),referencia_briefing=round(target,3),margem=round(nominal-target,3),observacao='Área geométrica; não é ventilação livre nem confirmação do código.'))
    result=dict(terreno=420.0,construida_estimada={k:round(v.area,3) for k,v in floors.items()},util_estimada={k:round(v,3) for k,v in useful.items()},projecao_estimada=round(projection.area,3),ocupacao_estimada_percentual=round(projection.area/420*100,2),solo_natural_conservador=round(natural.area,3),solo_natural_percentual=round(natural.area/420*100,2),margem_solo_natural=round(natural.area-126,3),piscina_agua=p['w']*p['h'],vagas_previstas=3,vagas_referencia_briefing=math.ceil(sum(v.area for v in floors.values())/150),ambientes=rooms,janelas=wcheck)
    return d,result,natural

if __name__=='__main__':
    d,result,natural=calculate()
    (ROOT/'QUADRO-AREAS-04-R1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('ambientes','janelas')},ensure_ascii=False,indent=2))
    assert result['solo_natural_conservador']>=126,'Solo natural abaixo da meta de 30% do briefing'
    assert all(w['margem']>=0 for w in result['janelas']),'Há vãos nominais abaixo da referência do briefing'
