"""Teste parcial de setores de giro contra mobiliário/louças representados.

Não verifica paredes, marcos, portas dobráveis durante o movimento, pessoas,
armários, teto, ventilação ou elementos não modelados. Obstáculos 2D por piso.
"""
from pathlib import Path
from math import atan2,cos,sin,pi
import json
from shapely.geometry import box,Polygon,LineString
from shapely.ops import unary_union
from aberturas_04 import HINGED,open_panels
from detalhes_banhos import detalhes_banho,detalhes_banho_master
from detalhes_lavabo import detalhes_lavabo
from detalhes_mobiliario import bed,wardrobe_list,office,tv
from elementos_04 import CUTS,equipment,PILLARS

root=Path(__file__).resolve().parent
d=json.loads((root/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
cuts=json.loads((root/CUTS).read_text(encoding='utf-8'))
obs={'terreo':[],'superior':[]}
for level in ('terreo','superior'):
    for r in d[level]:
        rid=r['id'];x,y,w,h=(r[k] for k in ('x','y','w','h'))
        if (rid.startswith('q') and len(rid)>1 and rid[1].isdigit()) or rid=='master':
            obs[level].append(('cama '+rid,box(*bed(r))))
        for item in wardrobe_list(r):obs[level].append(('armário '+rid,box(*item)))
        if rid=='estar':
            obs[level].append(('sofá',box(x+.30,y+1.10,x+2.60,y+1.90)))
            obs[level].append(('TV',box(*tv(r))))
        if rid=='escritorio':
            for name,area in office(r).items():obs[level].append(('escritório '+name,box(*area)))
        details=detalhes_banho(r) if rid in ('b1','b2','b3','banho-5') else detalhes_banho_master(r) if rid=='banho-master' else detalhes_lavabo(r) if rid=='lavabo' else None
        if details:
            for piece in ('box','bacia','cuba'):
                if piece in details:obs[level].append((piece+' '+rid,box(*details[piece])))
        if rid in ('gourmet','quiosque'):
            cx=x+w/2;cy=y+h/2;table_width=2.8 if rid=='gourmet' else 2.5
            obs[level].append(('mesa '+rid,box(cx-table_width/2,cy-.5,cx+table_width/2,cy+.5)))
            for j in range(4):
                xx=cx-table_width/2+.32+(table_width-.64)*j/3
                for sign in (-1,1):
                    yy=cy+sign*.78;obs[level].append(('cadeira '+rid,box(xx-.225,yy-.25,xx+.225,yy+.25)))
            if rid=='gourmet':
                for sign in (-1,1):
                    xx=cx+sign*(table_width/2+.28);obs[level].append(('cadeira ponta',box(xx-.25,cy-.225,xx+.25,cy+.225)))

for name,level,rect,height in equipment(d):obs[level].append((name,box(*rect)))
for name,x,y,z0,z1,width in PILLARS:
    for level,z in [('terreo',0),('superior',3.15)]:
        if z0<=z and z1>z:obs[level].append(('pilar '+name,box(x-width/2,y-width/2,x+width/2,y+width/2)))
# Reconstrói as paredes baixas da maquete, recortando apenas vãos que chegam ao
# piso. Janelas são mantidas como paredes neste teste em planta.
wall_masks={}
for level in ('terreo','superior'):
    segments=[]
    for r in d[level]:
        if r['id'] in ('quiosque','varanda','patio'):continue
        x,y,w,h=(r[k] for k in ('x','y','w','h'))
        segments.extend([LineString([(x,y),(x+w,y)]),LineString([(x,y+h),(x+w,y+h)]),LineString([(x,y),(x,y+h)]),LineString([(x+w,y),(x+w,y+h)])])
    walls=unary_union(segments).buffer(.075,cap_style=2,join_style=2)
    for c in cuts:
        if c['nivel']!=level or c['peitoril']>0:continue
        f,center,width=c['fixo'],c['centro'],c['largura'];a=center-width/2;b=center+width/2
        opening=box(a,f-.16,b,f+.16) if c['eixo']=='h' else box(f-.16,a,f+.16,b)
        walls=walls.difference(opening)
    wall_masks[level]=walls

def sector(c):
    axis,f,mid,w=(c[k] for k in ('eixo','fixo','centro','largura'));a=mid-w/2+.03;b=mid+w/2-.03
    end,sign=HINGED[c['nome']];hinge=a if end=='a' else b;length=b-a
    if axis=='v':
        x,y=f,hinge;closed=(0,1 if end=='a' else -1);opened=(sign,0)
    else:
        x,y=hinge,f;closed=(1 if end=='a' else -1,0);opened=(0,sign)
    alpha=atan2(closed[1],closed[0]);beta=atan2(opened[1],opened[0]);delta=(beta-alpha+pi)%(2*pi)-pi
    return Polygon([(x,y)]+[(x+length*cos(alpha+delta*i/48),y+length*sin(alpha+delta*i/48)) for i in range(49)]+[(x,y)]).buffer(.02)

doors=[c for c in cuts if c['nome'] in HINGED]
warnings=[]
for c in doors:
    sweep=sector(c)
    wall_area=sweep.intersection(wall_masks[c['nivel']]).area
    if wall_area>1e-5:warnings.append((c['nivel'],c['nome'],'parede modelada',round(wall_area,4)))
    for name,shape in obs[c['nivel']]:
        area=sweep.intersection(shape).area
        if area>1e-5:warnings.append((c['nivel'],c['nome'],name,round(area,4)))
panels=[]
for c in cuts:
    a=c['centro']-c['largura']/2+.03;b=c['centro']+c['largura']/2-.03
    for kind,x0,y0,x1,y1 in open_panels(c['nome'],c['eixo'],c['fixo'],a,b):
        panels.append((c['nivel'],c['nome'],kind,box(x0,y0,x1,y1)))
for level,label,kind,panel in panels:
    for name,shape in obs[level]:
        area=panel.intersection(shape).area
        if area>1e-5:warnings.append((level,label,'painel aberto contra '+name,round(area,4)))
for c in doors:
    sweep=sector(c)
    for level,name,kind,panel in panels:
        if level==c['nivel'] and name!=c['nome']:
            area=sweep.intersection(panel).area
            if area>1e-5:warnings.append((level,c['nome'],'painel aberto '+name,round(area,4)))
if warnings:
    for w in warnings:print('COLISÃO DE ENSAIO:',*w)
    raise SystemExit(1)
print(f'{len(doors)} setores de portas de giro testados sem sobreposição aos móveis/louças representados ou aos demais painéis na posição aberta.')
print('Pilares, armários e equipamentos representados entram no ensaio. NÃO TESTADOS: batentes e ferragens reais, dobráveis em movimento, equipamentos não modelados, pessoas, instalações e passagem útil real.')
