"""Ensaio simplificado de louças e aproximação no banho master."""
from pathlib import Path
import json
from shapely.geometry import box,LineString
from detalhes_banhos import detalhes_banho_master

data=json.loads((Path(__file__).resolve().parent/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
r=next(r for r in data['superior'] if r['id']=='banho-master')
x,y,w,h=(r[k] for k in ('x','y','w','h')); d=detalhes_banho_master(r); t=.15
fixtures={k:box(*d[k]) for k in ('box','bacia','cuba')}
interior=box(x+t/2,y+t/2,x+w-t/2,y+h-t/2)
for name,shape in fixtures.items():
    assert interior.buffer(1e-8).covers(shape),f'{name} fora do banho'
    for name2,other in fixtures.items():
        if name<name2:assert shape.intersection(other).area<1e-8,f'{name} colide com {name2}'
front=box(*d['faixa_frontal_bacia'])
for name in ('box','cuba'):
    assert front.intersection(fixtures[name]).area<1e-8, f'área frontal da bacia colide com {name}'
cx=d['porta_centro_x']; half=d['porta_largura_nominal']/2
walls=[box(x-t/2,y-t/2,cx-half,y+t/2),box(cx+half,y-t/2,x+w+t/2,y+t/2),
       box(x-t/2,y-t/2,x+t/2,y+h+t/2),box(x+w-t/2,y-t/2,x+w+t/2,y+h+t/2),
       box(x-t/2,y+h-t/2,x+w+t/2,y+h+t/2)]
# Painel dobrável hipotético aberto para o dormitório; o movimento não foi testado.
panel=box(cx-half-.02,y-.40,cx-half+.02,y)
path=LineString([(cx,y-.60),(cx,y+1.10)]).buffer(.30,cap_style=1)
for label,obj in list(fixtures.items())+[('painel',panel)]+[(f'parede {i}',wall) for i,wall in enumerate(walls)]:
    assert path.intersection(obj).area<1e-8, f'passagem colide com {label}'
print('Banho master: faixa esquemática de 0,60 m passa pela porta e chega ao interior; faixa frontal da bacia não colide com box/cuba.')
print('NÃO VERIFICA giro da porta, acesso com cama/armário, box em uso, instalações, ventilação, ergonomia integral ou normas.')
