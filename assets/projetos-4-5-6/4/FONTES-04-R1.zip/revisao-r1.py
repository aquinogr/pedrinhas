"""Revisão geométrica do modelo nativo e ensaios de uso do projeto 04."""
from pathlib import Path
import json,subprocess,sys,math
from shapely.geometry import box
from shapely.ops import unary_union
from core.scene import Scene
from formats.igz import load_into
from elementos_04 import NATIVE,CUTS,windows,PILLARS
from quantitativos04 import calculate
root=Path(__file__).resolve().parent;d,areas,natural=calculate();records=[]
def ok(name,value,scope):records.append(dict(item=name,resultado='Verificado no estudo',valor=value,alcance=scope));print('PASSA',name,':',value)
def require(condition,message):
    if not condition:raise AssertionError(message)
scene=Scene();load_into(scene,root/NATIVE)
bounds=[]
for g in scene.groups:
    if not g.mesh.vertices:continue
    points=[(v.position.x(),v.position.y(),v.position.z()) for v in g.mesh.vertices]
    lo=[min(p[i] for p in points) for i in range(3)];hi=[max(p[i] for p in points) for i in range(3)]
    bounds.append((g.name,box(lo[0],lo[1],hi[0],hi[1]),lo,hi))
ok('Arquivo nativo',len(scene.groups),'Reaberto pela biblioteca IngeTrazo; não prova arquitetura sozinho.')
for level in ('terreo','superior'):
    rs=d[level]
    for i,a in enumerate(rs):
        aa=box(a['x'],a['y'],a['x']+a['w'],a['y']+a['h'])
        for b in rs[i+1:]:
            bb=box(b['x'],b['y'],b['x']+b['w'],b['y']+b['h'])
            require(aa.intersection(bb).area<1e-7,f'Ambientes sobrepostos: {a["id"]}/{b["id"]}')
ok('Compartimentação','Sem sobreposição de áreas entre ambientes','Verificação planar por pavimento.')
envelope=unary_union([box(r['x']-.075,r['y']-.075,r['x']+r['w']+.075,r['y']+r['h']+.075) for r in d['terreo'] if r['id'] not in ('patio','varanda','quiosque')]+[box(x-w/2,y-w/2,x+w/2,y+w/2) for _,x,y,_,_,w in PILLARS])
x0,y0,x1,y1=envelope.bounds
require(x0>=1.5-1e-7 and x1<=10.5+1e-7 and y0>=5-1e-7 and y1<=33.5+1e-7,'Faces construídas invadem os recuos do briefing')
ok('Implantação segundo o briefing',{'frente':round(y0,3),'esquerda':round(x0,3),'direita':round(12-x1,3),'fundos':round(35-y1,3)},'Faces externas de paredes e pilares, sem atribuir aprovação legal ou incluir beirais nesses recuos.')
roofs=unary_union([foot for name,foot,lo,hi in bounds if name.startswith('Cobertura ')])
for level in ('terreo','superior'):
    for r in d[level]:
        if r['id']=='patio':continue
        interior=box(r['x']+.08,r['y']+.08,r['x']+r['w']-.08,r['y']+r['h']-.08)
        require(interior.difference(roofs).area<1e-6,'Falta cobertura sobre '+r['id'])
courtyard=box(7.96,19.00,10.34,20.74)
require(courtyard.intersection(roofs).area<1e-6,'Pátio foi indevidamente coberto')
ok('Coberturas','Ambientes cobertos e pátio aberto','União das projeções das lajes reais do IGZ; não certifica impermeabilização ou estrutura.')
ceilings=[(name,foot,lo[2]) for name,foot,lo,hi in bounds if name.startswith(('Cobertura ','Viga proposta ','Piso ·')) and lo[2]>=2.1]
minimum=99;checks=[]
for flight in ('inferior','superior'):
    # Reconstrução independente dos centros dos 16 pisos, por nomes do IGZ.
    steps=[(name,foot,lo,hi) for name,foot,lo,hi in bounds if name.startswith('Piso de degrau '+flight+' ')]
    require(len(steps)==8,'Quantidade de pisos incorreta')
    for name,foot,lo,hi in steps:
        center=foot.centroid;body=box(center.x-.30,center.y-.10,center.x+.30,center.y+.10)
        hits=[(n,z-hi[2]) for n,f,z in ceilings if f.intersection(body).area>1e-7 and z>hi[2]+.02]
        require(hits,'Sem cobertura/limite acima do degrau')
        name_ceiling,clear=min(hits,key=lambda pair:pair[1]);minimum=min(minimum,clear)
        require(clear>=2.10-1e-5,f'Altura livre insuficiente: {name} sob {name_ceiling}: {clear}')
        checks.append({'piso':name,'altura_livre':round(clear,3),'obstaculo':name_ceiling})
for label,x,y,z in [('patamar',9.05,10.9,1.575),('aproximacao',8.3,15.05,0),('desembarque',9.75,14.35,3.15)]:
    body=box(x-.30,y-.10,x+.30,y+.10);hits=[(n,zz-z) for n,f,zz in ceilings if f.intersection(body).area>1e-7 and zz>z+.02]
    n,clear=min(hits,key=lambda pair:pair[1]);minimum=min(minimum,clear);require(clear>=2.10-1e-5,'Altura livre no '+label);checks.append(dict(piso=label,altura_livre=round(clear,3),obstaculo=n))
ok('Altura livre da escada',round(minimum,3),'Metros mínimos no percurso amostrado, sob lajes e vigas representadas; projetos complementares posteriores podem alterar a folga.')
guards=[(n,hi[2]-lo[2]) for n,_,lo,hi in bounds if n.startswith(('Guarda varanda','Guarda átrio','Guarda de borda'))]
require(len(guards)>=5 and all(h>=1.10-1e-5 for _,h in guards),'Guarda-corpo incompleto ou baixo')
ok('Proteções desenhadas',len(guards),'Panos fechados de 1,10 m; resistência, fixação e atendimento normativo dependem do executivo.')
require(abs(18*.175-3.15)<1e-8 and .63<=2*.175+.28<=.65,'Geometria da escada')
ok('Escada',{'espelhos':18,'espelho':.175,'piso':.28,'blondel':.63,'entre_corrimaos':.92},'Atende aos valores adotados no briefing; os lances não atingem o ideal de 1,10 m entre corrimãos.')
require(areas['solo_natural_conservador']>=126,'Solo natural abaixo de 30%')
require(areas['vagas_referencia_briefing']<=3,'Número de vagas insuficiente para a referência do briefing')
require(all(w['margem']>=0 for w in areas['janelas']),'Vãos nominais abaixo do briefing')
ok('Áreas e vãos nominais',{'solo_natural':areas['solo_natural_conservador'],'percentual':areas['solo_natural_percentual'],'margem_m2':areas['margem_solo_natural'],'vagas':3},'Solo natural exclui inclusive vagas inteiras e beirais; áreas de janela não equivalem à ventilação livre.')
for script in ['auditar-grafo.py','auditar-giros.py','auditar-percursos.py','auditar-banhos-terreos.py','auditar-banho-master.py','auditar-mobiliario.py','auditar-janelas-modelo.py','auditar-acesso-frontal.py']:
    result=subprocess.run([sys.executable,str(root/script)],cwd=root,text=True,encoding='utf-8',errors='replace',capture_output=True)
    require(result.returncode==0,script+'\n'+result.stdout+'\n'+result.stderr)
    ok(script,'Passou nos cenários definidos','Limitações descritas no próprio ensaio; nenhuma certificação normativa.')
report=dict(versao='R1',data='2026-11-13',status='Verificações geométricas do estudo concluídas',itens=records,altura_livre_detalhe=checks,pendencias_externas=['Enquadramento cadastral/zoneamento, anexos vigentes e regulamento do condomínio','Projeto estrutural, fundações, impermeabilização, instalações e responsabilidade técnica','Acessibilidade integral e especificação de esquadrias/ferragens reais'])
(root/'REVISAO-04-R1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('REVISÃO R1 CONCLUÍDA:',len(records),'itens. Não é certificação executiva.')
