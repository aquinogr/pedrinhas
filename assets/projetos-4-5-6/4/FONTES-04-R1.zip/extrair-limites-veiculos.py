"""Captura os envelopes reais dos veículos do arquivo Blender de estudo."""
import bpy,json,sys
from mathutils import Vector
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from elementos_04 import BLEND
bpy.ops.wm.open_mainfile(filepath=str(root/BLEND))
bpy.context.view_layer.update()
result=[]
for i in (1,2,3):
    prefix=f'Veículo Scopia CC-BY {i}'
    objects=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith(prefix)]
    assert objects,'Carro ausente '+prefix
    coords=[o.matrix_world@Vector(v) for o in objects for v in o.bound_box]
    lower=[min(v[k] for v in coords) for k in range(3)];upper=[max(v[k] for v in coords) for k in range(3)]
    result.append({'id':i,'min':lower,'max':upper,'objetos':len(objects)})
out=root/'ENVELOPES-VEICULOS-ESTUDO.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for item in result:print('Veículo',item['id'],'dimensões m',[round(item['max'][k]-item['min'][k],2) for k in range(3)])
