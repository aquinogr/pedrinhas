"""Monta apenas a entrega R1 isolada, sem Git e sem publicação."""
from pathlib import Path
import base64,json,shutil,html,re,zipfile
from PIL import Image
from quantitativos04 import calculate
ROOT=Path(__file__).resolve().parent;SITE=ROOT.parent/'SITE-ISOLADO-BASE-f51f2c9';ASSETS=SITE/'assets/atrio04/r1';ASSETS.mkdir(parents=True,exist_ok=True)
d,a,natural=calculate()
def num(x):return f'{x:,.2f}'.replace(',','_').replace('.',',').replace('_','.')
def copy(name):
    source=ROOT/name;assert source.is_file(),f'Arquivo necessário ausente: {source}'
    target=ASSETS/source.name;shutil.copy2(source,target)
for name in ['CASA-04-R1-MOBILIADA.igz','CASA-04-R1.glb','MEMORIAL-04-R1.md','REVISAO-04-R1.json','REVISAO-FOTOS-R1.md']:copy(name)
(ASSETS/'QUADRO-AREAS-04-R1.json').write_text(json.dumps(a,ensure_ascii=False,indent=2),encoding='utf8')
for p in (ROOT/'PRANCHAS-R1').glob('*.svg'):shutil.copy2(p,ASSETS/p.name)
for p in (ROOT/'RENDERS-R1').glob('*.png'):
    with Image.open(p) as im:im.convert('RGB').save(ASSETS/(p.stem+'.jpg'),quality=93,optimize=True)
pages=[('04-terreo-R1.svg','Térreo'),('04-superior-R1.svg','Superior'),('04-cobertura-R1.svg','Cobertura e implantação'),('04-corte-escada-R1.svg','Escada / corte desenvolvido')]
plans=''.join(f'<article class="plan"><header><h3>{title}</h3><a href="assets/atrio04/r1/{name}" download>SVG ↓</a></header><a data-enlarge href="assets/atrio04/r1/{name}"><img loading="lazy" src="assets/atrio04/r1/{name}" alt="Prancha cotada do estudo R1: {title}"></a></article>' for name,title in pages)
rows=''.join(f'<tr><td>{"Térreo" if r["nivel"]=="terreo" else "Superior"} · {html.escape(r["nome"])}</td><td>{num(r["largura_util"])} × {num(r["profundidade_util"])} m</td><td>{num(r["area_util"])} m²{" (vazio)" if r["id"]=="escada-superior" else ""}</td></tr>' for r in a['ambientes'])
wrows=''.join(f'<tr><td>{html.escape(w["ambiente"])}</td><td>{num(w["vao_nominal"])} m²</td><td>{num(w["referencia_briefing"])} m²</td><td>Área geométrica; ventilação efetiva a especificar.</td></tr>' for w in a['janelas'])
photos=''
photo_manifest=ROOT/'FOTOS-R1.json'
if photo_manifest.exists():
    entries=json.loads(photo_manifest.read_text(encoding='utf8'));figs=[]
    for e in entries:
        p=ROOT/e['arquivo'];assert p.exists()
        dest=ASSETS/p.name;shutil.copy2(p,dest)
        figs.append(f'<figure class="render"><a data-enlarge href="assets/atrio04/r1/{p.name}"><img loading="lazy" src="assets/atrio04/r1/{p.name}" alt="{html.escape(e["titulo"])}"></a><figcaption>{html.escape(e["titulo"])} · {html.escape(e["observacao"])}</figcaption></figure>')
    photos='<h3 style="margin-top:40px">Interpretações fotográficas para sua aprovação.</h3><p class="note">Geradas no Gemini pelo Chrome, usando os renders R1 como referência. São candidatas, não imagens aprovadas para substituir as anteriores. Texturas, paisagismo e detalhes permanecem interpretações; a geometria de referência é o modelo 3D e as pranchas.</p><div class="grid-two">'+''.join(figs)+'</div>'
mapping={'AREA_TOTAL':num(sum(a['construida_estimada'].values())),'AREA_TERREO':num(a['construida_estimada']['terreo']),'AREA_SUPERIOR':num(a['construida_estimada']['superior']),'NATURAL_PCT':num(a['solo_natural_percentual']),'NATURAL':num(a['solo_natural_conservador']),'MARGEM_NATURAL':num(a['margem_solo_natural']),'PROJECAO':num(a['projecao_estimada']),'OCUPACAO':num(a['ocupacao_estimada_percentual']),'ROOM_ROWS':rows,'WINDOW_ROWS':wrows,'PLANTAS':plans,'FOTOS_IA':photos}
template=(ROOT/'entrega-04.template.html').read_text(encoding='utf8')
for k,v in mapping.items():template=template.replace('{{'+k+'}}',v)
scripts=['three.min.js','OrbitControls.js','GLTFLoader.js']
normal=template.replace('{{THREE_SCRIPTS}}',''.join(f'<script src="assets/revisadas/{name}"></script>' for name in scripts)).replace('{{LOAD_MODEL}}',"new THREE.GLTFLoader().load('assets/atrio04/r1/CASA-04-R1.glb',loaded,undefined,failed);")
assert '{{' not in normal
(SITE/'entrega-04.html').write_text(normal,encoding='utf8')
# Documento de quadros independente e imprimível, sem scripts ou dependências.
tables=re.findall(r'<section id="(?:areas|clima|revisao)".*?</section>',normal,re.S)
css=re.search(r'<style>(.*?)</style>',normal,re.S).group(1)
(ASSETS/'04-quadros-R1.html').write_text('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Casa 04 / quadros R1</title><style>'+css+'</style><main class="wrap"><h1>Casa 04 / quadros.</h1><p>Revisão R1 · 13/11/2026 · estudo para aprovação</p>'+''.join(tables).replace('assets/atrio04/r1/','')+'</main><script>document.querySelectorAll("details").forEach(e=>e.open=true)</script></html>',encoding='utf8')
offline_scripts=''.join('<script>'+(SITE/'assets/revisadas'/name).read_text(encoding='utf8').replace('</script>',r'<\/script>')+'</script>' for name in scripts)
encoded=base64.b64encode((ROOT/'CASA-04-R1.glb').read_bytes()).decode('ascii')
load="try{const raw=atob('"+encoded+"'),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);new THREE.GLTFLoader().parse(bytes.buffer,'',loaded,failed)}catch(e){failed(e)}"
offline=template.replace('{{THREE_SCRIPTS}}',offline_scripts).replace('{{LOAD_MODEL}}',load)
offline=re.sub(r'<div class="project-tabs".*?</div>','<p class="hint">Apresentação offline · somente projeto 04 · imagens e modelo incorporados.</p>',offline,flags=re.S)
for name in re.findall(r'(?:src|href)="assets/atrio04/r1/([^"?#]+)"',offline):
    p=ASSETS/name
    if p.suffix.lower() not in ('.jpg','.png','.svg','.jfif'):continue
    mime='image/svg+xml' if p.suffix=='.svg' else 'image/png' if p.suffix=='.png' else 'image/jpeg'
    uri='data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode('ascii')
    offline=offline.replace('"assets/atrio04/r1/'+name+'"','"'+uri+'"')
offline=offline.replace('assets/atrio04/r1/','')
(ASSETS/'CASA04-OFFLINE.html').write_text(offline,encoding='utf8')
with zipfile.ZipFile(ASSETS/'FONTES-04-R1.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    source_names=['elementos_04.py','aberturas_04.py','quantitativos04.py','modelar-casa-estudo.py','mobiliar-maquete-estudo.py','compor-igz-mobiliado-r1.py','preservar-mobiliada-r1.py','gerar-pranchas-r1.py','gerar-estudo.py','detalhes_banhos.py','detalhes_lavabo.py','detalhes_mobiliario.py','revisao-r1.py','auditar-grafo.py','auditar-giros.py','auditar-percursos.py','auditar-banhos-terreos.py','auditar-banho-master.py','auditar-mobiliario.py','auditar-janelas-modelo.py','auditar-acesso-frontal.py','renderizar-r1.py','montar-entrega-r1.py','testar-interface-r1.py','ENVELOPES-VEICULOS-ESTUDO.json','extrair-limites-veiculos.py','CONCEPCAO-04.json','ABERTURAS-04-R1.json','ELEMENTOS-04-R1.json','QUADRO-AREAS-04-R1.json','REVISAO-04-R1.json','MEMORIAL-04-R1.md','REVISAO-FOTOS-R1.md','FOTOS-R1.json','entrega-04.template.html','testar-entrega-r1.cjs','QA-SITE-04-R1.json']
    files=[ROOT/n for n in source_names]+[ROOT/'APRENDIZADOS-R1.md',ROOT/'finalizar-r1.py']
    files+=list((ROOT/'PRANCHAS-R1').glob('*.svg'))
    credits=ROOT.parent.parent/'MODELOS REVISADOS/CREDITOS-ACERVO-3D.md'
    for p in files:
        if p.is_file():z.write(p,str(p.relative_to(ROOT)))
    if credits.exists():z.write(credits,'CREDITOS-ACERVO-3D.md')
print('Entrega local montada:',SITE/'entrega-04.html')
print('Offline:',round((ASSETS/'CASA04-OFFLINE.html').stat().st_size/1e6,2),'MB. Nenhum deploy executado.')
