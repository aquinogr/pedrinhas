"""Hipóteses de porta aberta para a maquete 04. Não é detalhe de fabricação."""

FOLD_SIDE={'v1 ↔ b1':-1,'v2 ↔ b2':1,'v3 ↔ b3':1,'vestibulo-5 ↔ banho-5':1}
# (lado da dobradiça no intervalo a..b, sinal da projeção perpendicular).
HINGED={
 'estar ↔ v1':('b',1),'estar ↔ circulacao':('a',-1),'q1 ↔ v1':('b',-1),
 'circulacao ↔ v2':('b',-1),'v2 ↔ q2':('b',-1),
 'circulacao ↔ v3':('b',-1),'v3 ↔ q3':('b',-1),
 'master ↔ hall-superior':('a',-1),'escritorio ↔ hall-superior':('b',-1),
 'hall-superior ↔ q5':('a',-1),'q5 ↔ vestibulo-5':('b',-1),
 'master ↔ closet':('a',1), 'entrada estar':('b',1),
 'apoio apoio':('b',1),'depósito deposito':('b',1),'serviço lavanderia':('b',1),
}
def open_panels(label,axis,f,a,b):
    """Retorna retângulos XY de folhas em posição aberta e seus tipos."""
    if label in FOLD_SIDE:
        assert axis=='v';sign=FOLD_SIDE[label];hinge=a
        return [('dobrável',min(f,f+sign*(b-a)/2),hinge-.02,max(f,f+sign*(b-a)/2),hinge+.02)]
    if label=='master ↔ banho-master':
        assert axis=='h';hinge=a
        return [('dobrável',hinge-.02,f-(b-a)/2,hinge+.02,f)]
    if label=='porta lavabo lavabo':
        assert axis=='h'
        return [('correr',b,f-.13,b+(b-a),f-.09)]
    if label.startswith('varanda ↔') or label.startswith('saída lazer'):
        assert axis=='h';width=(b-a)/2;sign=-1 if label.startswith('varanda') else 1
        y0,y1=sorted((f+sign*.075,f+sign*.115))
        return [('vidro correr',a-width,y0,a,y1),('vidro correr',b,y0,b+width,y1)]
    if label in HINGED:
        hinge,sign=HINGED[label];point=a if hinge=='a' else b;length=b-a
        if axis=='v':return [('giro',min(f,f+sign*length),point-.02,max(f,f+sign*length),point+.02)]
        return [('giro',point-.02,min(f,f+sign*length),point+.02,max(f,f+sign*length))]
    return []
