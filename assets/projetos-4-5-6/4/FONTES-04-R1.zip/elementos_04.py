"""Geometria comum da revisão R1; metros, Z vertical. Estudo arquitetônico."""
import math

VERSION='R1'
NATIVE='ARQUITETURA-04-R1.igz'
ARCH_GLB='ARQUITETURA-04-R1.glb'
WEB_GLB='CASA-04-R1.glb'
BLEND='CASA-04-R1.blend'
CUTS='ABERTURAS-04-R1.json'

# Identificação, retângulo XY, base da laje, espessura e destino do escoamento.
ROOFS=[
 ('superior-frente',(1.45,4.95,10.55,10.35),6.10,.20,'lateral leste'),
 ('superior-escada',(1.45,10.35,10.55,14.95),6.10,.20,'lateral leste'),
 ('superior-fundos',(1.45,14.95,7.95,18.65),6.10,.20,'fundos'),
 ('cozinha',(7.75,14.95,10.55,18.95),3.00,.20,'lateral leste'),
 ('ligacao',(1.45,18.45,7.95,20.75),3.00,.20,'fundos'),
 ('gourmet',(1.45,20.75,10.55,25.35),3.00,.20,'fundos'),
 ('quiosque',(5.85,25.70,10.55,31.10),3.00,.20,'lateral leste'),
 ('apoio-servico',(1.45,30.95,10.55,33.625),3.00,.20,'fundos'),
]
PILLARS=[('varanda-esquerda',1.65,5.15,0,6.10,.20),('varanda-direita',10.35,5.15,0,6.10,.20)]
PILLARS += [(f'quiosque-{x}-{y}',x,y,0,3.00,.20) for x in (6.05,10.35) for y in (25.90,30.90)]
PILLARS += [(f'eixo-central-{y}',6.55,y,0,3.00,.20) for y in (5.15,10.15,13.80,18.45,20.95)]
PILLARS += [(f'perimetral-{x}-{y}',x,y,0,3.00,.20) for x in (1.65,10.35) for y in (10.15,13.80,18.45,20.95)]

# Paredes principais funcionam como eixos de referência para os apoios propostos.
# Seções abaixo representam apenas espaço reservado; não há cálculo estrutural.
BEAMS=[
 ('varanda-frente',(1.55,5.05,5.80,10.45,5.25,6.10)),
 ('varanda-frente-entrepiso',(1.55,5.05,2.75,10.45,5.25,3.00)),
 ('eixo-central-superior',(6.15,5.05,2.75,6.70,21.05,3.00)),
 ('apoio-hall-superior',(7.65,14.90,2.75,7.85,18.50,3.00)),
 ('transferencia-fundos-superior',(1.575,18.30,2.75,10.425,18.50,3.00)),
 ('quiosque-esquerda',(5.95,25.80,2.75,6.15,31.00,3.00)),
 ('quiosque-direita',(10.25,25.80,2.75,10.45,31.00,3.00)),
 ('quiosque-frente',(5.95,25.80,2.75,10.45,26.00,3.00)),
 ('quiosque-fundos',(5.95,30.80,2.75,10.45,31.00,3.00)),
]
BEAMS += [(f'transversal-{y}',(1.55,y-.10,2.75,7.75 if y<14 else 10.45,y+.10,3.00)) for y in (10.15,13.80,18.45,20.95)]
BEAMS += [('fundo-desembarque',(7.75,14.80,2.75,10.45,15.00,3.00))]

# Pisos externos impermeáveis explicitamente delimitados. Coberturas contam à parte.
PAVING=[
 ('chegada',(4.40,4.15,5.80,5.075)),
 ('conexao-lazer',(4.95,25.225,6.50,31.025)),
 ('frente-servico',(1.575,30.05,6.50,31.025)),
 ('deck-frontal',(1.575,25.225,4.95,25.90)),
 ('deck-lateral',(1.575,25.90,2.05,30.05)),
 ('deck-borda-direita',(4.55,25.90,4.95,30.05)),
 ('deck-borda-fundos',(2.05,29.90,4.55,30.05)),
]
# Acesso lateral secundário em gramado; apenas os trechos de aproximação recebem
# pisantes. Não é uma rota acessível pavimentada. A entrada principal é contínua.
PAVING += [(f'pisante-lateral-{i}',(11.20,y,11.80,y+.25)) for i,y in enumerate([4.15,4.85,5.55,6.25,6.95,25.70,26.40,27.10,27.80,28.50])]
PARKING=[(1.65+2.5*i,0,4.15+2.5*i,5.0) for i in range(3)]
TIRE_STRIPS=[(cx+dx-.20,.25,cx+dx+.20,4.25) for cx in (2.89,5.39,7.89) for dx in (-.63,.63)]

def windows(data):
    """Vãos nominais; área de ventilação livre não se confunde com vão geométrico."""
    out=[]
    def add(level,room,side,center,width,sill,height):
        r=next(r for r in data[level] if r['id']==room)
        axis,f=('h',r['y']) if side=='frente' else ('h',r['y']+r['h']) if side=='fundos' else ('v',r['x']) if side=='esquerda' else ('v',r['x']+r['w'])
        out.append(dict(nivel=level,ambiente=room,eixo=axis,fixo=f,centro=center,largura=width,peitoril=sill,altura=height,nome='janela '+room+' '+side,angulo=45 if room.startswith(('b','lavabo')) else 30,folhas=2 if width>=1.4 else 1,lado=side))
    add('terreo','estar','frente',3.05,2.5,.85,1.5)
    for level in ('terreo','superior'):
        for r in data[level]:
            rid=r['id']
            if rid in ('q1','q2','q3','q5','master'):
                side='esquerda' if r['x']<3 else 'direita'
                add(level,rid,side,r['y']+1.25,1.8,.85,1.45)
            if rid in ('b1','b2','b3','banho-5','banho-master'):
                side='esquerda' if r['x']<3 else 'direita'
                add(level,rid,side,r['y']+.60,.9 if rid=='banho-master' else .8,1.95,.7 if rid=='banho-master' else .65)
    add('terreo','cozinha','direita',16.10,1.8,1.00,1.30)
    add('terreo','gourmet','esquerda',22.60,1.6,1.10,1.30)
    add('terreo','gourmet','direita',22.60,1.6,1.10,1.30)
    add('terreo','cozinha','fundos',9.1,1.5,1.0,1.3)
    add('terreo','gourmet','frente',9.1,1.5,1.1,1.3)
    add('terreo','ligacao','direita',19.875,1.0,1.2,1.1)
    add('superior','escritorio','direita',8.65,1.4,1.10,1.20)
    add('superior','escada-superior','direita',11.5,.9,1.4,1.1)
    for rid,c,w in [('lavanderia',3.0,1.2),('deposito',5.15,.6),('lavabo',6.95,.8),('apoio',9.1,.9)]:
        add('terreo',rid,'fundos',c,w,1.95,.65)
    return out

def equipment(data):
    # Identificação, pavimento, envelope XY, altura. Frente de uso conforme planta.
    return [
     ('churrasqueira','terreo',(7.85,30.10,8.65,30.75),2.4),
     ('pia quiosque','terreo',(8.65,30.10,10.20,30.75),.90),
     ('lavadora','terreo',(1.85,32.65,2.50,33.30),.90),
     ('tanque lavanderia','terreo',(2.60,32.65,3.25,33.30),.90),
     ('bancada lavanderia','terreo',(3.35,32.65,4.15,33.30),.90),
     ('prateleira deposito','terreo',(4.55,32.95,5.85,33.30),2.10),
     ('geladeira cozinha','terreo',(9.55,17.35,10.25,18.10),1.85),
     ('bancada cozinha','terreo',(9.63,14.35,10.18,17.25),.90),
     ('armario apoio','terreo',(8.05,32.90,10.15,33.30),2.10),
    ]

def stair_steps():
    steps=[]
    for i in range(8):
        y1=13.80-i*.28;steps.append(('inferior',i+1,(7.825,y1-.28,8.925,y1),(i+1)*.175))
        y0=11.56+i*.28;steps.append(('superior',i+1,(9.175,y0,10.275,y0+.28),1.575+(i+1)*.175))
    return steps

STAIR=dict(risers=18,rise=.175,tread=.28,width=1.10,landing=(7.825,10.225,10.275,11.56),landing_z=1.575,top_z=3.15,guard_height=1.10,handrail_height=.92)

def roof_slope_height(name,xy,z):
    # Caimento de 1% para um coletor próprio, acima da laje da cobertura.
    x0,y0,x1,y1=xy
    return z+.04, .01*(x1-x0 if name!='superior-fundos' and name!='gourmet' and name!='apoio-servico' else y1-y0)
