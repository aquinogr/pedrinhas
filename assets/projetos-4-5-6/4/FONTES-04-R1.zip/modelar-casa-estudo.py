"""Maquete volumétrica de trabalho em IGZ/GLB; NÃO é projeto executivo.

Gera paredes com vãos a partir do mesmo grafo usado no desenho 2D. A geometria
de folhas, estrutura, instalações e cobertura detalhada ainda deve ser revisada.
Não sobrescreve outros projetos ou saídas anteriores.
"""
from pathlib import Path
import importlib.util,json,math,sys,hashlib,shutil
from PySide6.QtGui import QVector3D
from core.group import Group
from core.mesh import Mesh
from core.scene import Scene
from core.layers import Layer
from formats.igz import save_scene,load_into
from formats.gltf import save_glb
from aberturas_04 import open_panels
from elementos_04 import NATIVE,ARCH_GLB,CUTS,ROOFS,PILLARS,BEAMS,PAVING,TIRE_STRIPS,STAIR,stair_steps,windows,equipment

root=Path(__file__).resolve().parent
out=root/NATIVE
glb=root/ARCH_GLB
if out.exists() or glb.exists():
    if '--rebuild' not in sys.argv:raise SystemExit('Destino já existe. Para regenerar arquivos desta revisão, usar --rebuild; serão preservadas cópias por hash.')
    history=root/'HISTORICO-GERADOS-R1';history.mkdir(exist_ok=True)
    for f in (out,glb,root/CUTS,root/'ELEMENTOS-04-R1.json'):
        if f.exists():shutil.copy2(f,history/(f.stem+'-'+hashlib.sha256(f.read_bytes()).hexdigest()[:10]+f.suffix))
spec=importlib.util.spec_from_file_location('planta04',root/'gerar-estudo.py')
plan=importlib.util.module_from_spec(spec);spec.loader.exec_module(plan)
d=json.loads((root/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
scene=Scene()
for name in ('Terreno','Térreo','Superior','Cobertura','Lazer','Estrutura proposta','Equipamentos'):
    scene.layers.append(Layer(name))

elements=[]
def box(name,x0,y0,z0,x1,y1,z1,color,layer):
    if min(x1-x0,y1-y0,z1-z0)<.0001:return
    m=Mesh()
    for p in [[(x0,y1,z0),(x1,y1,z0),(x1,y0,z0),(x0,y0,z0)],[(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)],[(x0,y0,z0),(x1,y0,z0),(x1,y0,z1),(x0,y0,z1)],[(x1,y0,z0),(x1,y1,z0),(x1,y1,z1),(x1,y0,z1)],[(x1,y1,z0),(x0,y1,z0),(x0,y1,z1),(x1,y1,z1)],[(x0,y1,z0),(x0,y0,z0),(x0,y0,z1),(x0,y1,z1)]]:
        f=m.add_face([QVector3D(*v) for v in p])
        if f:f.attrs['color']=color
    g=Group(m,name=name);g.layer=layer;scene.groups.append(g)
    elements.append(dict(nome=name,camada=layer,min=[x0,y0,z0],max=[x1,y1,z1]))

def profile(name,x0,x1,yz,color,layer):
    points=[(x0,y,z) for y,z in yz]+[(x1,y,z) for y,z in yz];n=len(yz)
    faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    mesh=Mesh()
    for indices in faces:
        f=mesh.add_face([QVector3D(*points[i]) for i in indices])
        if f:f.attrs['color']=color
    g=Group(mesh,name=name);g.layer=layer;scene.groups.append(g)
    elements.append(dict(nome=name,camada=layer,min=[min(p[i] for p in points) for i in range(3)],max=[max(p[i] for p in points) for i in range(3)]))

def outward_window(name,axis,f,a,b,z_bottom,z_top,angle,layer,direction):
    """Folha esquemática tipo maxim-ar, eixo no topo e abertura externa."""
    length=z_top-z_bottom;angle=math.radians(angle)
    projection=length*math.sin(angle);opened_bottom=z_top-length*math.cos(angle)
    if axis=='v':
        sign=direction
        pts=[(f,a,z_top),(f,b,z_top),(f+sign*projection,b,opened_bottom),(f+sign*projection,a,opened_bottom)]
    else:
        sign=direction
        pts=[(a,f,z_top),(b,f,z_top),(b,f+sign*projection,opened_bottom),(a,f+sign*projection,opened_bottom)]
    mesh=Mesh();face=mesh.add_face([QVector3D(*p) for p in pts])
    if face:face.attrs['color']=(.51,.68,.68)
    group=Group(mesh,name=name);group.layer=layer;scene.groups.append(group)

def rail_yz(name,x,y0,z0,y1,z1,width,layer):
    """Prisma inclinado para estudo de corrimão; não é detalhamento executivo."""
    length=math.hypot(y1-y0,z1-z0);py=-(z1-z0)/length*width/2;pz=(y1-y0)/length*width/2
    p=[(y0+py,z0+pz),(y1+py,z1+pz),(y1-py,z1-pz),(y0-py,z0-pz)]
    points=[(x-width/2,y,z) for y,z in p]+[(x+width/2,y,z) for y,z in p]
    faces=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
    m=Mesh()
    for face in faces:
        f=m.add_face([QVector3D(*points[i]) for i in face])
        if f:f.attrs['color']=(.28,.25,.22)
    g=Group(m,name=name);g.layer=layer;scene.groups.append(g)

# Coord.: metros; rua em y=0; z vertical. Paleta provisória.
pool=d['piscina'];px,py,pw,ph=(pool[k] for k in ('x','y','w','h'))
for x0,y0,x1,y1 in [(0,0,12,py-.15),(0,py+ph+.15,12,35),(0,py-.15,px-.15,py+ph+.15),(px+pw+.15,py-.15,12,py+ph+.15)]:
    box('Terreno',x0,y0,-.30,x1,y1,-.12,(.48,.61,.39),'Terreno')
for x0,y0,x1,y1 in TIRE_STRIPS:box('Faixa de vaga',x0,y0,-.12,x1,y1,-.08,(.73,.71,.65),'Terreno')
for name,(x0,y0,x1,y1) in PAVING:box('Piso externo '+name,x0,y0,-.12,x1,y1,-.01,(.75,.73,.67),'Terreno')
box('Piscina — fundo',px-.15,py-.15,-1.45,px+pw+.15,py+ph+.15,-1.30,(.35,.65,.67),'Lazer')
for name,rect in [('esquerda',(px-.15,py-.15,px,py+ph+.15)),('direita',(px+pw,py-.15,px+pw+.15,py+ph+.15)),('frente',(px,py-.15,px+pw,py)),('fundos',(px,py+ph,px+pw,py+ph+.15))]:
    box('Piscina — parede '+name,*rect[:2],-1.30,*rect[2:],-.04,(.38,.67,.70),'Lazer')
box('Piscina — água',px,py,-.115,px+pw,py+ph,-.10,(.20,.63,.69),'Lazer')
for i in range(3):box('Piscina — degrau submerso',px+.1,py+.1+i*.30,-1.30,px+.95,py+.4+i*.30,-.40-.30*i,(.55,.76,.75),'Lazer')

open_ids={'quiosque','varanda','patio'}
cut_log=[];cut_data=[]
for level in ('terreo','superior'):
    rooms=d[level];lookup={r['id']:r for r in rooms}; layer='Térreo' if level=='terreo' else 'Superior';z=0 if level=='terreo' else 3.15
    lines={};cuts=[]
    for r in rooms:
        x,y,w,h=(r[k] for k in ('x','y','w','h'))
        if r['id'] not in ('escada','escada-superior','patio'):
            box('Piso · '+r['uso'],x,y,z-.15,x+w,y+h,z,(.79,.75,.67),layer)
        if r['id'] in open_ids:continue
        for axis,f,a,b in [('h',y,x,x+w),('h',y+h,x,x+w),('v',x,y,y+h),('v',x+w,y,y+h)]:
            lines.setdefault((axis,round(f,5)),[]).append((a,b))
    def cut(axis,f,center,width,sill=0,height=2.20,label='vão'):
        cuts.append((axis,round(f,5),center,width,sill,height,label))
    for a,b in plan.G['04'][level]:
        axis,f,start,end=plan.shared(lookup[a],lookup[b]); desired=1.8 if (a,b) in plan.SLIDING else 1.0 if (a,b) in plan.OPEN else .8
        width=min(desired,end-start-.10);center=(start+end)/2
        if level=='terreo' and (a,b) in (('v1','b1'),('v2','b2'),('v3','b3')):center=plan.detalhes_banho(lookup[b])['porta_centro_y']
        if level=='superior' and (a,b)==('vestibulo-5','banho-5'):center=plan.detalhes_banho(lookup[b])['porta_centro_y']
        if level=='terreo' and (a,b)==('cozinha','escada'):center=8.30
        if level=='superior' and (a,b)==('chegada-escada','escada-superior'):center=9.75
        cut(axis,f,center,width,label=a+' ↔ '+b)
    def edge(name,side,center,width=1.0,sill=0,height=2.20,label='exterior'):
        r=lookup[name];x,y,w,h=(r[k] for k in ('x','y','w','h'))
        axis,f=('h',y) if side=='top' else ('h',y+h) if side=='bottom' else ('v',x) if side=='left' else ('v',x+w)
        cut(axis,f,center,width,sill,height,label+' '+name)
    if level=='terreo':
        edge('estar','top',d['diretrizes_em_revisao']['entrada_estar_x'],1.0,label='entrada')
        edge('gourmet','bottom',5.8,1.8,label='saída lazer')
        edge('lavabo','top',6.95,.90,label='porta lavabo')
        edge('lavanderia','top',3.0,.8,label='serviço')
        edge('apoio','right',32.1,.8,label='apoio')
        edge('deposito','top',5.15,.8,label='depósito')
    for win in windows(d):
        if win['nivel']==level:cut(win['eixo'],win['fixo'],win['centro'],win['largura'],win['peitoril'],win['altura'],win['nome'])
    # Une intervalos colineares antes de criar as peças de parede.
    for (axis,f),ranges in lines.items():
        merged=[]
        for a,b in sorted(ranges):
            if merged and a<=merged[-1][1]+.0001:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
            else:merged.append((a,b))
        for start,end in merged:
            openings=sorted((c for c in cuts if c[0]==axis and abs(c[1]-f)<.0001 and c[2]-c[3]/2>=start-.0001 and c[2]+c[3]/2<=end+.0001),key=lambda c:c[2])
            def wall(a,b,low,high):
                if level=='superior' and axis=='v' and abs(f-7.75)<.001 and low==0 and a<13.8 and b>10.15:
                    # O limite do átrio é guarda-corpo, não uma parede fechada de 3 m.
                    for aa,bb,hh in [(a,min(b,10.15),high),(max(a,10.15),min(b,13.8),min(high,1.10)),(max(a,13.8),b,high)]:
                        if bb>aa:box('Guarda átrio' if hh==1.10 else 'Parede superior',f-.075,aa,z+low,f+.075,bb,z+hh,(.88,.86,.80),layer)
                    return
                if axis=='h':box('Parede '+level,a,f-.075,z+low,b,f+.075,z+high,(.88,.86,.80),layer)
                else:box('Parede '+level,f-.075,a,z+low,f+.075,b,z+high,(.88,.86,.80),layer)
            cursor=start
            for _,_,center,width,sill,height,label in openings:
                a=center-width/2;b=center+width/2
                if a<cursor-.001:raise ValueError(f'Vãos sobrepostos: {level} {axis} {f} {label}, início {a:.2f} < {cursor:.2f}')
                walltop=3.00 if level=='terreo' else 2.95
                wall(cursor,a,0,walltop);wall(a,b,0,sill);wall(a,b,sill+height,walltop);cursor=b
                cut_log.append(f'{level}: {label}: {width:.2f} m')
                cut_data.append({'nivel':level,'eixo':axis,'fixo':f,'centro':center,'largura':width,'peitoril':sill,'altura':height,'nome':label})
                # Painéis fechados são apenas indicação visual; não validam folhas nem giros.
                window=('janela' in label or 'maxim-ar' in label)
                sliding=('varanda ↔' in label or 'saída lazer' in label)
                link=tuple(label.split(' ↔ ')) if ' ↔ ' in label else None
                is_door=(link is not None and link not in plan.OPEN and link not in plan.SLIDING) or label.startswith(('entrada ','porta lavabo ','serviço ','apoio ','depósito '))
                if window:
                    win=next(w for w in windows(d) if w['nivel']==level and w['nome']==label)
                    for leaf in range(win['folhas']):
                        aa=a+.03+(b-a-.06)*leaf/win['folhas'];bb=a+.03+(b-a-.06)*(leaf+1)/win['folhas']
                        direction=-1 if win['lado'] in ('esquerda','frente') else 1
                        outward_window('Vidro janela externa · '+label,axis,f,aa,bb,z+sill+.03,z+sill+height-.03,win['angulo'],layer,direction)
                    # Marcos fecham a espessura do vão; projeção das folhas é externa.
                    for mid in (a+.025,b-.025):
                        if axis=='v':box('Marco janela '+label,f-.085,mid-.025,z+sill,f+.085,mid+.025,z+sill+height,(.25,.29,.28),layer)
                        else:box('Marco janela '+label,mid-.025,f-.085,z+sill,mid+.025,f+.085,z+sill+height,(.25,.29,.28),layer)
                elif sliding or is_door:
                    panels=open_panels(label,axis,f,a+.03,b-.03)
                    if not panels:raise ValueError('Porta sem hipótese de abertura: '+label)
                    for kind,x0,y0,x1,y1 in panels:
                        color=(.51,.68,.68) if kind=='vidro correr' else (.48,.33,.23)
                        box('Porta aberta esquemática '+label,x0,y0,z+.03,x1,y1,z+height-.03,color,layer)
            wall(cursor,end,0,3.00 if level=='terreo' else 2.95)

# Escada em U fechada: 18 espelhos, 16 pisos e patamar intermediário.
for flight in ('inferior','superior'):
    selected=[s for s in stair_steps() if s[0]==flight]
    if flight=='inferior':
        yz=[(13.80,0)]
        for _,_,(x0,y0,x1,y1),zz in selected:yz.extend([(y1,zz),(y0,zz)])
        yz.extend([(11.56,1.575),(11.56,1.15),(13.80,-.15)])
        profile('Lance fechado inferior',7.825,8.925,[(yy,zz-.025) for yy,zz in yz],(.67,.58,.44),'Térreo')
    else:
        yz=[(11.56,1.575)]
        for _,_,(x0,y0,x1,y1),zz in selected:yz.extend([(y0,zz),(y1,zz)])
        yz.extend([(13.80,3.15),(13.80,2.725),(11.56,1.425)])
        profile('Lance fechado superior',9.175,10.275,[(yy,zz-.025) for yy,zz in yz],(.67,.58,.44),'Térreo')
    for _,i,(x0,y0,x1,y1),zz in selected:box(f'Piso de degrau {flight} {i}',x0,y0,zz-.02,x1,y1,zz,(.75,.66,.53),'Térreo')
x0,y0,x1,y1=STAIR['landing'];box('Patamar escada',x0,y0,1.395,x1,y1,1.575,(.67,.58,.44),'Térreo')
box('Separação fechada entre lances',8.925,11.56,0,9.175,13.80,4.25,(.84,.83,.77),'Térreo')
box('Guarda de borda sobre lance inferior',7.75,13.725,3.15,9.175,13.80,4.25,(.88,.86,.80),'Superior')
for x in (7.89,8.86):
    rail_yz('Corrimão lance inferior',x,13.80,1.095,11.56,2.495,.05,'Térreo')
    rail_yz('Prolongamento inferior',x,14.10,1.095,13.80,1.095,.05,'Térreo')
for x in (9.24,10.21):
    rail_yz('Corrimão lance superior',x,11.56,2.67,13.80,4.07,.05,'Térreo')
    rail_yz('Prolongamento superior',x,13.80,4.07,14.10,4.07,.05,'Superior')
rail_yz('Corrimão retorno esquerdo patamar',7.89,11.56,2.495,10.325,2.495,.05,'Térreo')
box('Corrimão transversal patamar',7.865,10.30,2.47,10.235,10.35,2.52,(.28,.25,.22),'Térreo')
rail_yz('Corrimão retorno direito patamar',10.21,10.325,2.495,11.28,2.495,.05,'Térreo')
rail_yz('Corrimão transição patamar',10.21,11.28,2.495,11.56,2.67,.05,'Térreo')

# Louças volumétricas rudimentares, com a mesma posição dos ensaios 2D.
from detalhes_banhos import detalhes_banho,detalhes_banho_master
from detalhes_lavabo import detalhes_lavabo
for level in ('terreo','superior'):
    z=0 if level=='terreo' else 3.15; layer='Térreo' if level=='terreo' else 'Superior'
    for r in d[level]:
        rid=r['id']
        if rid in ('b1','b2','b3','banho-5'):fixtures=detalhes_banho(r)
        elif rid=='banho-master':fixtures=detalhes_banho_master(r)
        elif rid=='lavabo':fixtures=detalhes_lavabo(r)
        else:continue
        for piece in ('box','bacia','cuba'):
            if piece not in fixtures:continue
            x0,y0,x1,y1=fixtures[piece]
            height=.04 if piece=='box' else .42 if piece=='bacia' else .86
            bottom=0 if piece!='cuba' else .70
            box('Louça esquemática '+piece+' '+rid,x0,y0,z+bottom,x1,y1,z+height,(.94,.95,.93),layer)

for name,(x0,y0,x1,y1),base,thickness,drain in ROOFS:
    box('Cobertura '+name,x0,y0,base,x1,y1,base+thickness,(.78,.76,.70),'Cobertura')
    # Regularização inclinada 1%: geometria do estudo; dimensionamento hidráulico posterior.
    if drain=='fundos':profile('Caimento cobertura '+name,x0,x1,[(y0,base+thickness),(y1,base+thickness),(y1,base+thickness+.04),(y0,base+thickness+.04+(y1-y0)*.01)],(.82,.80,.74),'Cobertura')
    else:
        low=base+thickness;high=low+.04+(x1-x0)*.01
        pts=[(x0,y0,low),(x1,y0,low),(x1,y1,low),(x0,y1,low),(x0,y0,high),(x1,y0,low+.04),(x1,y1,low+.04),(x0,y1,high)]
        mesh=Mesh()
        for face in [(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:
            f=mesh.add_face([QVector3D(*pts[i]) for i in face])
            if f:f.attrs['color']=(.82,.80,.74)
        g=Group(mesh,name='Caimento cobertura '+name);g.layer='Cobertura';scene.groups.append(g)
    if drain=='fundos':box('Calha cobertura '+name,x0,y1-.12,base+thickness+.01,x1,y1,base+thickness+.09,(.34,.39,.38),'Cobertura')
    else:box('Calha cobertura '+name,x1-.12,y0,base+thickness+.01,x1,y1,base+thickness+.09,(.34,.39,.38),'Cobertura')
for x,y,z in [(10.43,10.20,6.32),(7.82,18.40,6.32),(10.43,18.40,3.22),(10.43,25.15,3.22),(10.43,30.75,3.22),(1.70,33.43,3.22)]:
    box('Condutor pluvial próprio',x-.035,y-.035,-.03,x+.035,y+.035,z,(.42,.45,.43),'Estrutura proposta')
for name,x,y,z0,z1,width in PILLARS:box('Pilar '+name,x-width/2,y-width/2,z0,x+width/2,y+width/2,z1,(.83,.81,.74),'Estrutura proposta')
for name,bounds in BEAMS:
    # Folga numérica de 2 mm evita faces coincidentes nos encontros de volumes.
    # As seções são reservas arquitetônicas, não dimensões de fabricação.
    adjusted=[v+.002 if i<3 else v-.002 for i,v in enumerate(bounds)]
    box('Viga proposta '+name,*adjusted,(.83,.81,.74),'Estrutura proposta')
box('Guarda varanda frontal',1.75,5.10,3.15,10.25,5.20,4.25,(.88,.86,.80),'Superior')
box('Guarda varanda esquerda',1.60,5.20,3.15,1.70,7.25,4.25,(.88,.86,.80),'Superior')
box('Guarda varanda direita',10.30,5.20,3.15,10.40,7.25,4.25,(.88,.86,.80),'Superior')
for name,level,(x0,y0,x1,y1),height in equipment(d):
    bottom=0 if level=='terreo' else 3.15
    box('Equipamento '+name,x0,y0,bottom,x1,y1,bottom+height,(.68,.66,.59),'Equipamentos')
box('Chaminé churrasqueira',8.03,30.25,2.40,8.40,30.60,4.20,(.36,.37,.33),'Lazer')

save_scene(scene,out);check=Scene();load_into(check,out)
assert len(scene.groups)==len(check.groups)
save_glb(check,glb)
(root/CUTS).write_text(json.dumps(cut_data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(root/'ELEMENTOS-04-R1.json').write_text(json.dumps(elements,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Maquete de estudo: {len(check.groups)} grupos, {len(cut_log)} vãos reconhecidos. IGZ e GLB salvos; não é projeto final.')
