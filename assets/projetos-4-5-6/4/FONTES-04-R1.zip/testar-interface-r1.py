"""Abre o IGZ final num processo isolado, sem tocar no documento já aberto."""
from pathlib import Path
import hashlib,json
from PySide6.QtCore import QCoreApplication,QTimer
from PySide6.QtWidgets import QApplication
from views.main_window import MainWindow
root=Path(__file__).resolve().parent
QCoreApplication.setOrganizationName('CodexPedrinhasTesteIsolado')
QCoreApplication.setApplicationName('InspecaoR1')
app=QApplication([]);window=MainWindow(defer_extensions=True);window.resize(1440,1000);window.move(-30000,-30000);window.show()
def check():
    ok=window.open_path(root/'CASA-04-R1-MOBILIADA.igz');print('INTERFACE ABRIU R1:',ok,flush=True)
    if not ok:app.exit(1);return
    window._on_zoom_extents();window.viewport.update();QTimer.singleShot(4000,finish)
def finish():
    saved=window.grab().save(str(root/'INSPECAO-INGETRAZO-R1.png'));print('CAPTURA DA INTERFACE:',saved,flush=True)
    record=dict(arquivo='CASA-04-R1-MOBILIADA.igz',sha256=hashlib.sha256((root/'CASA-04-R1-MOBILIADA.igz').read_bytes()).hexdigest(),abertura=True,captura=saved,alcance='Abertura e captura em processo isolado; encerramento/estabilidade geral não certificados.')
    (root/'QA-IGZ-R1.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
    app.exit(0 if saved else 1)
QTimer.singleShot(500,check)
raise SystemExit(app.exec())
