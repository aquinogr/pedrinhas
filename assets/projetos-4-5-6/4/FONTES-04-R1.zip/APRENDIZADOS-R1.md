# Consistência da entrega arquitetônica

Aplicar quando o escopo pedir modelo editável, plantas, apresentação web e imagens do mesmo projeto. Não transformar parâmetros de uma residência em normas universais.

## Modelo e versões

- Centralizar ambientes, aberturas, níveis, coberturas, pilares, equipamentos e pisos externos em dados compartilhados. Incluir variações locais de largura: corredor nominal não é largura livre depois das paredes, pilares e corrimãos.
- Para um IGZ com móveis: exportar complementos GLB separados por pavimento e veículos; importar pela biblioteca oficial, conferir origem, eixos e envelopes; salvar e reabrir o IGZ com texturas incorporadas. `QVector3D` deve ser lido com `.x()/.y()/.z()`, não subscrito como lista.
- Em modelos pesados, simplificar cópias dos móveis apenas para o IGZ, preservando os originais no Blender/GLB de apresentação. Identificar diferença de nível de detalhe. Verificar que recursos continuam incorporados após a reabertura, e abrir a interface real em processo isolado.
- Superfícies exatamente coincidentes podem gerar faixas negras no Cycles e z-fighting na web. Evitar duplicar o acabamento no mesmo plano do substrato, e conferir encontros entre vigas, paredes e pilares. Uma folga numérica de modelagem não é uma junta ou dimensão executiva: não mudar níveis úteis para esconder defeito visual.
- Arquivar saídas próprias por revisão/hash antes de regenerar, sobretudo com outra IA trabalhando. Publicação deve ser integração incremental no estado então vigente, nunca sobreposição de uma cópia antiga inteira.

## Revisão geométrica que informa

- Verificar portas contra obstáculos, mas também rotas contínuas com folhas abertas, móveis e pilares. Incluir explicitamente cada quarto→banho, cozinha→gourmet, partida/patamar/desembarque de escada, e lazer→lavabo/apoio/serviço. Registrar corpo e malha do teste; isso não demonstra acessibilidade.
- Verificar também o sentido de uso dos móveis: um sofá pode caber sem colisões e ainda ficar perpendicular à TV. Conferir eixos de visão, cabeceiras, aproximação das pias e orientação das cadeiras no modelo, não só retângulos livres.
- Altura livre da escada deve usar as lajes e vigas efetivamente exportadas, não só números declarados. Inspecionar degraus, bordas, guarda-corpos, corrimãos e prolongamentos no 3D. Corte desenvolvido é esquemático e não deve parecer uma seção física única.
- Conferir projeção real das coberturas: uma cobertura faltante em um cômodo pode passar despercebida em perspectiva. Pátio declarado aberto não pode receber laje por engano.
- Áreas de janela são geométricas nominais; ventilação livre depende da esquadria. Porta nominal não equivale a passagem útil de ferragem real.
- Solo natural deve ser calculado por união de polígonos, excluindo piscina, pisos, estacionamento e demais superfícies não naturais segundo o critério adotado. Explicitar se beirais foram excluídos conservadoramente. Não usar grama entre rodas como área natural por suposição; não chamar caminho em gramado de rota acessível pavimentada.
- Parâmetros do briefing não certificam lei. No exemplo de Petrolina, a LC034/2022 diferencia zonas; recuo nulo ou5/1,5/1,5 m não pode ser aplicado genericamente a Pedrinhas. Confirmar zona, condomínio, situação cadastral/ambiental e atos vigentes; informar claramente incompatibilidade condicional quando conhecida.

## Imagens e site

- Renderizar vistas do modelo atual e usá-las como referências para a geração fotográfica. Rejeitar portas inventadas, piscina deslocada, varanda nova, alterações de vãos e carros invertidos. Pequenos detalhes interpretativos de materiais/paisagismo devem estar identificados; não prometer100% de fidelidade.
- Respeitar o gerador escolhido pelo usuário. Em operação de navegador, não afirmar variante de modelo que a interface não confirmou. Se só foi possível salvar o bitmap de prévia, informar dimensões e origem; não chamá-lo de original de alta resolução. Capturar somente a janela/aba pertinente e preservar a sessão existente.
- Se a substituição de imagens exige aprovação, colocar candidatas numa nova apresentação/comparação local sem sobrescrever os arquivos anteriores ou o publicado. Não publicar a conversa privada do gerador como se fosse um compartilhamento público.
- Para HTML offline: incorporar scripts, GLB, imagens e SVG; GLTFLoader pode ler ArrayBuffer a partir de base64. Testar via `file://` com rede desativada. Arquivos editáveis grandes podem ficar como irmãos externos, mas isso precisa ser dito.
- Testar celular e desktop, todos os modos e câmeras, ausência de overflow/erros, links e arquivos. Inspecionar visualmente: teste de botão não prova enquadramento útil da câmera. A vista da escada pode usar planos de recorte explicitamente identificados para expor os lances.
- PDF A3: conferir tamanho e número de páginas; a planta precisa manter escala física ao imprimir sem ajuste. Uma captura de SVG aberto diretamente no Chrome pode travar em fullPage; um HTML contendo `<img>` ou rasterização do PDF permite inspeção sem alterar o vetor.
