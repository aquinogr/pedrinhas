"""Compõe o IGZ arquitetônico com complementos GLB por pavimento e veículos."""
from pathlib import Path
import json,zipfile
from core.scene import Scene
from core.layers import Layer
from core.texture import texture_cache_root
import core.texture
from formats.igz import load_into,save_scene
from formats.glb import load_glb
from elementos_04 import NATIVE
root=Path(__file__).resolve().parent
out=root/'CASA-04-R1-MOBILIADA.igz'
if out.exists():raise SystemExit('IGZ mobiliado já existe; preservar versão.')
core.texture.texture_cache_root=lambda:root/'CACHE-TEXTURAS-R1'
scene=Scene();load_into(scene,root/NATIVE)
for kind,name in [('terreo','Mobiliário térreo'),('superior','Mobiliário superior'),('veiculos','Veículos')]:
    scene.layers.append(Layer(name));before=len(scene.groups)
    offset=load_glb(scene,root/f'COMPLEMENTO-04-R1-{kind}.glb')
    if offset is not None:raise AssertionError('Importação mudou origem do complemento')
    assert len(scene.groups)==before+1
    group=scene.groups[-1];group.name=name;group.layer=name
    points=[(v.position.x(),v.position.y(),v.position.z()) for v in group.mesh.vertices]
    lo=[min(p[i] for p in points) for i in range(3)];hi=[max(p[i] for p in points) for i in range(3)]
    assert lo[0]>0 and hi[0]<12 and lo[1]>=0 and hi[1]<35,(name,lo,hi)
    if kind=='superior':assert lo[2]>=3.14,(name,lo)
    else:assert hi[2]<3.01,(name,hi)
save_scene(scene,out);check=Scene();load_into(check,out)
assert len(check.groups)==len(scene.groups)
textures=0
for g in check.groups:
    for face in g.mesh.faces:
        t=face.attrs.get('texture') if face.attrs else None
        if t:
            assert Path(t['path']).is_file(),'Textura não localizada na reabertura'
            textures+=1
assert textures>0,'Complementos deveriam conter texturas'
assert zipfile.is_zipfile(out),'IGZ texturizado deve incorporar os recursos'
with zipfile.ZipFile(out) as z:
    assert any(n.startswith('textures/') for n in z.namelist())
print('IGZ mobiliado salvo e reaberto:',len(check.groups),'grupos;',textures,'faces com textura. Recursos incorporados.')
