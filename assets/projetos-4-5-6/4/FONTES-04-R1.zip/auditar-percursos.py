"""Busca percursos em malha conservadora com portas na posição aberta da maquete.

Ensaio planar de 0,60 m; não verifica uso real, rampa, pisos, norma ou segurança.
"""
from pathlib import Path
from collections import deque
import json,math,runpy
from shapely.geometry import box,Point
from shapely.ops import unary_union
from shapely.prepared import prep
from elementos_04 import PILLARS

root=Path(__file__).resolve().parent
audit=runpy.run_path(str(root/'auditar-giros.py'))
d=json.loads((root/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
cars=json.loads((root/'ENVELOPES-VEICULOS-ESTUDO.json').read_text(encoding='utf-8'))
pool=d['piscina'];p=box(pool['x'],pool['y'],pool['x']+pool['w'],pool['y']+pool['h'])
step=.025;clearance=.30+step*math.sqrt(2)/2
def build(level):
    solid=[audit['wall_masks'][level]]+[shape for _,shape in audit['obs'][level]]
    solid += [shape for lv,_,_,shape in audit['panels'] if lv==level]
    if level=='terreo':
        solid.append(p)
        for c in cars:solid.append(box(c['min'][0],c['min'][1],c['max'][0],c['max'][1]))
        for _,x,y,z0,z1,width in PILLARS:solid.append(box(x-width/2,y-width/2,x+width/2,y+width/2))
        solid.append(box(8.925,11.56,9.175,13.80))
    return prep(unary_union(solid).buffer(clearance,quad_segs=32))
blocked={k:build(k) for k in ('terreo','superior')}
def path(level,start,end):
    s=(round(start[0]/step),round(start[1]/step));target=(round(end[0]/step),round(end[1]/step));wall=blocked[level]
    def free(node):
        x,y=node[0]*step,node[1]*step
        return clearance<=x<=12-clearance and clearance<=y<=35-clearance and not wall.covers(Point(x,y))
    if not free(s):raise AssertionError(f'Início sem espaço em {level}: {start}')
    if not free(target):
        pt=Point(*end)
        nearby=[(name,round(shape.distance(pt),3)) for name,shape in audit['obs'][level] if shape.distance(pt)<clearance]
        nearby += [('painel '+name,round(shape.distance(pt),3)) for lv,name,_,shape in audit['panels'] if lv==level and shape.distance(pt)<clearance]
        nearby += [('paredes',round(audit['wall_masks'][level].distance(pt),3))] if audit['wall_masks'][level].distance(pt)<clearance else []
        raise AssertionError(f'Destino sem espaço em {level}: {end}; próximos: {nearby}')
    q=deque([s]);seen={s};directions=[(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
    while q:
        u=q.popleft()
        if u==target:return len(seen)
        for dx,dy in directions:
            v=(u[0]+dx,u[1]+dy)
            if v not in seen and free(v):seen.add(v);q.append(v)
    raise AssertionError(f'Sem faixa contínua {level} {start} → {end}')
checks=[
 ('terreo',(5.20,4.50),(5.85,9.55),'entrada → estar próximo ao corredor'),
 ('terreo',(5.85,9.55),(5.85,11.00),'estar → corredor'),
 ('terreo',(5.85,11.00),(7.00,16.00),'corredor → cozinha'),
 ('terreo',(7.00,16.00),(8.30,14.25),'cozinha → partida da escada'),
 ('terreo',(5.85,11.00),(5.80,21.50),'corredor → gourmet'),
 ('terreo',(5.80,21.50),(5.10,25.55),'gourmet → área externa'),
 ('terreo',(5.10,25.55),(6.95,31.50),'área externa → lavabo de piscina'),
 ('terreo',(5.85,11.00),(7.15,7.95),'corredor → quarto 1'),
 ('terreo',(5.85,11.00),(4.45,13.05),'corredor → quarto 2'),
 ('terreo',(5.85,11.00),(4.45,18.45),'corredor → quarto 3'),
 ('superior',(9.72,14.35),(6.95,14.35),'desembarque → hall superior'),
 ('superior',(6.95,14.35),(5.70,10.60),'hall superior → quarto master'),
 ('superior',(6.95,14.35),(7.00,9.60),'hall superior → escritório'),
 ('superior',(6.95,14.35),(5.60,15.10),'hall superior → quarto 5'),
 ('superior',(7.00,9.60),(8.30,6.80),'escritório → varanda'),
 ('terreo',(5.10,25.55),(3.00,31.65),'lazer → lavanderia'),
 ('terreo',(5.10,25.55),(5.15,31.65),'lazer → depósito'),
 ('terreo',(11.00,30.00),(9.70,32.10),'lateral → apoio'),
 ('terreo',(7.15,7.95),(9.10,9.10),'quarto 1 → banho 1 pelo vestíbulo'),
 ('terreo',(4.45,13.05),(2.90,14.50),'quarto 2 → banho 2 pelo vestíbulo'),
 ('terreo',(4.45,18.45),(2.90,19.90),'quarto 3 → banho 3 pelo vestíbulo'),
 ('superior',(5.70,10.60),(2.75,11.90),'master → banho master'),
 ('superior',(5.60,15.10),(2.90,17.50),'quarto 5 → banho 5 pelo vestíbulo'),
 ('terreo',(7.00,16.00),(7.10,19.80),'cozinha → ligação coberta'),
 ('terreo',(7.10,19.80),(5.80,21.50),'ligação coberta → gourmet'),
]
fail=[]
for level,start,end,label in checks:
    try:visited=path(level,start,end);print('PASSA',label,'células exploradas',visited)
    except AssertionError as e:fail.append((label,str(e)));print('FALHA',label,str(e))
print('Ensaio usa malha 2,5 cm, corpo circular 60 cm e pequena margem numérica; não é prova de acessibilidade, pavimentação ou operação simultânea de portas.')
if fail:raise SystemExit(1)
