"""Proposta de geometria para os banheiros térreos; unidades em metros.

Retângulos são caixas esquemáticas, sem instalações nem comprovação normativa.
"""
def detalhes_banho(r):
    x,y,w,h=(r[k] for k in ('x','y','w','h'))
    mirror = r['id']=='b1'
    def rbox(a,b,c,d):
        return (x+w-c,y+b,x+w-a,y+d) if mirror else (x+a,y+b,x+c,y+d)
    return {
        'espelhado':mirror,
        'box':rbox(.075,.075,.875,.875),
        'bacia':rbox(.075,h-.60,.725,h-.20),
        'cuba':rbox(w-.475,h-.525,w-.075,h-.075),
        'faixa_frontal_bacia':rbox(.725,h-.60,1.325,h-.20),
        'porta_centro_y':y+.75,
        'porta_largura_nominal':.8,
        'porta_sistema':'dobrável para vestíbulo; projeto e passagem útil pendentes',
    }

def detalhes_banho_master(r):
    x,y,w,h=(r[k] for k in ('x','y','w','h'))
    return {
        'box':(x+.075,y+h-.875,x+.875,y+h-.075),
        'bacia':(x+.95,y+h-.725,x+1.35,y+h-.075),
        'cuba':(x+w-.475,y+.20,x+w-.075,y+.65),
        'faixa_frontal_bacia':(x+.95,y+h-1.325,x+1.35,y+h-.725),
        'porta_centro_x':x+1.10,
        'porta_largura_nominal':.80,
        'porta_sistema':'dobrável para quarto; projeto e passagem útil pendentes',
    }
