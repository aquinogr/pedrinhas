"""Ensaio de percurso com carros parados; não prova manobra ou acessibilidade."""
from pathlib import Path
import json
from shapely.geometry import box,LineString
root=Path(__file__).resolve().parent
cars=json.loads((root/'ENVELOPES-VEICULOS-ESTUDO.json').read_text(encoding='utf-8'))
d=json.loads((root/'CONCEPCAO-04.json').read_text(encoding='utf-8'))
entry=d['diretrizes_em_revisao']['entrada_estar_x'];room=next(r for r in d['terreo'] if r['id']=='estar')
opening=(entry-.5,entry+.5);facade=room['y'];thickness=.15
left=box(room['x']-.075,facade-.075,opening[0],facade+.075)
right=box(opening[1],facade-.075,room['x']+room['w']+.075,facade+.075)
route=LineString([(10.80,.15),(10.80,4.50),(entry,4.50),(entry,5.30)]).buffer(.375,cap_style=2,join_style=2)
for car in cars:
    lo,hi=car['min'],car['max'];foot=box(lo[0],lo[1],hi[0],hi[1])
    assert route.intersection(foot).area<1e-7, f'Percurso cruza veículo {car["id"]}'
for name,wall in [('fachada esquerda',left),('fachada direita',right)]:
    assert route.intersection(wall).area<1e-7,'Percurso cruza '+name
assert route.bounds[0]>=0 and route.bounds[2]<=d['lote']['largura']
print('PASSA cenário com carros parados: faixa esquemática de 0,75 m pela lateral direita, atrás dos veículos até a entrada, sem cruzar os envelopes 3D ou a fachada modelada.')
print('NÃO COMPROVA giro da porta principal, liberação com portas dos carros abertas, manobra, pavimento, acessibilidade ou licenciamento.')
