"""Arquiva somente saídas provisórias R1 produzidas por estes scripts."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
history=root/'HISTORICO-GERADOS-R1';history.mkdir(exist_ok=True)
for name in ['CASA-04-R1.glb','CASA-04-R1.blend','CASA-04-R1-MOBILIADA.igz','COMPLEMENTO-04-R1-terreo.glb','COMPLEMENTO-04-R1-superior.glb','COMPLEMENTO-04-R1-veiculos.glb']:
    p=root/name
    if not p.exists():continue
    assert p.resolve().parent==root.resolve()
    sha=hashlib.sha256(p.read_bytes()).hexdigest()[:12]
    target=history/(p.stem+'-'+sha+p.suffix)
    if target.exists():
        assert target.read_bytes()==p.read_bytes()
        # Uma saída idêntica já arquivada não é removida: usar um segundo nome.
        i=2
        while target.exists():target=history/(p.stem+'-'+sha+f'-{i}'+p.suffix);i+=1
    p.rename(target)
    print('Preservado',target.name)
