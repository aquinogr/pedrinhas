"""Pranchas A3 1:100, áreas úteis estimadas, implantação e corte desenvolvido."""
from pathlib import Path
import json,math,html,importlib.util
from elementos_04 import CUTS,PAVING,PARKING,PILLARS,ROOFS,windows,equipment,stair_steps,STAIR
from detalhes_mobiliario import bed,wardrobe_list,office,tv
from detalhes_banhos import detalhes_banho,detalhes_banho_master
from detalhes_lavabo import detalhes_lavabo
from aberturas_04 import open_panels,HINGED
from quantitativos04 import calculate
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'PRANCHAS-R1';OUT.mkdir(exist_ok=True)
d,areas,natural=calculate();cuts=json.loads((ROOT/CUTS).read_text(encoding='utf-8'))
spec=importlib.util.spec_from_file_location('base04',ROOT/'gerar-estudo.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
E=html.escape
def text(x,y,s,size=.25,fill='#283f35',anchor='middle',rotate=None):
    tr=f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ''
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial,sans-serif" font-size="{size}" fill="{fill}"{tr}>{E(str(s))}</text>'
def rect(x0,y0,x1,y1,fill,stroke='none',sw=.025):return f'<rect x="{x0}" y="{y0}" width="{x1-x0}" height="{y1-y0}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def line(x0,y0,x1,y1,stroke='#748276',sw=.025,dash=None):return f'<line x1="{x0}" y1="{y0}" x2="{x1}" y2="{y1}" stroke="{stroke}" stroke-width="{sw}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>'
def dimension(x0,y0,x1,y1,label):
    horizontal=abs(y1-y0)<.001;parts=[line(x0,y0,x1,y1)]
    for x,y in [(x0,y0),(x1,y1)]:parts.append(line(x-.08,y-.08,x+.08,y+.08,'#52695a',.02))
    parts.append(text((x0+x1)/2,(y0+y1)/2-.12 if horizontal else (y0+y1)/2,label,.23,rotate=None if horizontal else -90))
    return ''.join(parts)
def header(title,height=42):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="297mm" height="{height*10}mm" viewBox="-2.4 -3.8 29.7 {height}">',rect(-2.4,-3.8,27.3,height-3.8,'#fcfaf5'),text(12.4,-2.8,'PEDRINHAS · CASA DO ÁTRIO SOCIAL · PROJETO 04',.40),text(12.4,-2.1,title,.31),text(12.4,-1.45,'Estudo arquitetônico R1 · 13/11/2026 · dimensões em metros',.22)]
def door_arc(c):
    label=c['nome']
    if label not in HINGED:return ''
    a=c['centro']-c['largura']/2+.03;b=c['centro']+c['largura']/2-.03;hinge,sign=HINGED[label];v=a if hinge=='a' else b;r=b-a;f=c['fixo']
    if c['eixo']=='v':center=(f,v);closed=(f,v+(r if hinge=='a' else -r));opened=(f+sign*r,v)
    else:center=(v,f);closed=(v+(r if hinge=='a' else -r),f);opened=(v,f+sign*r)
    aa=math.atan2(closed[1]-center[1],closed[0]-center[0]);bb=math.atan2(opened[1]-center[1],opened[0]-center[0]);delta=(bb-aa+math.pi)%(2*math.pi)-math.pi
    return f'<path d="M{closed[0]},{closed[1]} A{r},{r} 0 0 {1 if delta>0 else 0} {opened[0]},{opened[1]}" fill="none" stroke="#9d7658" stroke-width=".018" stroke-dasharray=".07 .04"/>'
def furnishing(r,level):
    rid=r['id'];x,y,w,h=(r[k] for k in ('x','y','w','h'));s=[]
    if rid in ('q1','q2','q3','q5','master'):s.append(base.bed(r))
    if rid in ('gourmet','quiosque'):s.append(base.table(r,10 if rid=='gourmet' else 8))
    for x0,y0,x1,y1 in wardrobe_list(r):s.append(rect(x0,y0,x1,y1,'#c7ac88','#866d53'))
    if rid=='estar':
        s += [rect(x+.3,y+1.1,x+2.6,y+1.9,'#a6b89e','#71816d'),rect(*tv(r),'#343d38')]
    if rid=='escritorio':
        for key,box in office(r).items():s.append(rect(*box,'#b79b77' if key=='mesa' else '#a6b89e','#7d715c'))
    details=detalhes_lavabo(r) if rid=='lavabo' else detalhes_banho_master(r) if rid=='banho-master' else detalhes_banho(r) if rid in ('b1','b2','b3','banho-5') else None
    if details:
        for key in ('box','cuba','bacia'):
            if key not in details:continue
            x0,y0,x1,y1=details[key];s.append(rect(x0,y0,x1,y1,'#dbefed' if key=='box' else '#ffffff','#789b9c',.02))
            if key=='box':s += [line(x0,y0,x1,y1,'#a9c9c6',.015),line(x1,y0,x0,y1,'#a9c9c6',.015)]
            if key=='bacia':s.append(f'<ellipse cx="{(x0+x1)/2}" cy="{(y0+y1)/2}" rx="{(x1-x0)*.33}" ry="{(y1-y0)*.33}" fill="none" stroke="#b1c4c1" stroke-width=".025"/>')
    if rid in ('escada','escada-superior'):
        s.append(rect(*STAIR['landing'],'#d4b890','#8a7458'))
        for flight,i,(x0,y0,x1,y1),z in stair_steps():s.append(rect(x0,y0,x1,y1,'#e8d4b5','#a48c70',.018))
        s.append('<path d="M8.37,14.2 V10.80 H9.72 V14.2" fill="none" stroke="#4f827a" stroke-width=".055" marker-end="url(#arrow)"/>')
    return ''.join(s)
def plans(level):
    res=header('PLANTA HUMANIZADA · '+('TÉRREO' if level=='terreo' else 'PAVIMENTO SUPERIOR'))
    res.append('<defs><pattern id="lawn" width=".5" height=".5" patternUnits="userSpaceOnUse"><rect width=".5" height=".5" fill="#e0ead6"/><path d="M.1,.2 l.04,-.07 M.3,.4 l-.03,-.07" stroke="#c3d4b6" stroke-width=".02"/></pattern><marker id="arrow" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 Z" fill="#477d76"/></marker></defs>')
    res += [rect(0,0,12,35,'url(#lawn)','#58705e',.04),text(6,-.60,'RUA · LAZER DO CONDOMÍNIO E RIO A ~100 m',.22),text(6,-.16,'Frente ESE · azimute 115°',.20)]
    if level=='terreo':
        for name,b in PAVING:res.append(rect(*b,'#e6dfce','#c3baa5',.012))
        for index,(x0,y0,x1,y1) in enumerate(PARKING):
            res += [rect(x0,y0,x1,y1,'none','#a7b09d',.02),text((x0+x1)/2,.32,f'VAGA {index+1} · 2,50 × 5,00',.16)]
            res += [rect(x0+.36,.40,x0+2.11,3.97,'#d1d6cf' if index!=1 else '#d9b455','#697e70',.02),rect(x0+.55,1.15,x0+1.92,2.1,'#a8c3c4','#7e9b9b',.015)]
        p=d['piscina'];res += [rect(p['x']-.15,p['y']-.15,p['x']+p['w']+.15,p['y']+p['h']+.15,'#f2ecdf','#a9ab99'),rect(p['x'],p['y'],p['x']+p['w'],p['y']+p['h'],'#91cbcf','#5a9eaa'),text(p['x']+p['w']/2,p['y']+p['h']/2,'PISCINA',.26),text(p['x']+p['w']/2,p['y']+p['h']/2+.38,'2,50 × 4,00 m',.21),text(p['x']+p['w']/2,p['y']+p['h']/2+.70,'prof. de estudo 1,20 m',.16)]
    rooms=d[level];lookup={r['id']:r for r in rooms}
    for number,r in enumerate(rooms,1):
        rid=r['id'];x,y,w,h=(r[k] for k in ('x','y','w','h'))
        if rid=='patio':res += [rect(x,y,x+w,y+h,'url(#lawn)'),text(x+w/2,y+h/2,'PÁTIO ABERTO',.21)];continue
        res.append(rect(x,y,x+w,y+h,base.color(r),'#4f6253' if rid not in ('varanda','quiosque') else '#bb9d79',.15 if rid not in ('varanda','quiosque') else .03))
        res.append(furnishing(r,level))
        label=rid if w<1.6 else r['uso']
        if len(label)>22:label=label[:21]+'…'
        res.append(text(x+w/2,y+.32,f'{number:02d} · {label}',.19 if w<2.3 else .22))
        a=next(a for a in areas['ambientes'] if a['nivel']==level and a['id']==rid)
        if h>1.0 and w>1.2:res.append(text(x+w/2,y+h-.23,f"{a['area_util']:.2f} m²".replace('.',','),.19))
    for name,lv,b,height in equipment(d):
        if lv==level:res.append(rect(*b,'#b7b8ac' if 'lavadora' in name or 'geladeira' in name else '#bba181','#7d806f',.025))
    for name,x,y,z0,z1,w in PILLARS:
        if (level=='terreo' and z1>0) or (level=='superior' and z1>3.15):res.append(rect(x-w/2,y-w/2,x+w/2,y+w/2,'#6b7765'))
    specs={w['nome']:w for w in windows(d) if w['nivel']==level}
    for c in [c for c in cuts if c['nivel']==level]:
        a=c['centro']-c['largura']/2;b=c['centro']+c['largura']/2;axis,f=c['eixo'],c['fixo']
        def al(a,b,f,stroke,sw,dash=None):return line(a,f,b,f,stroke,sw,dash) if axis=='h' else line(f,a,f,b,stroke,sw,dash)
        res.append(al(a,b,f,'#fcfaf5',.17))
        if c['peitoril']>0:
            win=specs[c['nome']];sign=-1 if win['lado'] in ('esquerda','frente') else 1
            res.append(al(a,b,f,'#529fa7',.065))
            projection=(c['altura']-.06)*math.sin(math.radians(win['angulo']))
            res.append(al(a+.03,b-.03,f+sign*projection,'#529fa7',.025,'.08 .05'))
        else:
            for kind,x0,y0,x1,y1 in open_panels(c['nome'],axis,f,a+.03,b-.03):res.append(rect(x0,y0,x1,y1,'#5a9da2' if kind=='vidro correr' else '#a37d59'))
            res.append(door_arc(c))
    if level=='superior':
        res += [line(7.75,10.15,7.75,13.8,'#6e9995',.10),line(7.75,13.8,9.175,13.8,'#6e9995',.10),text(8.1,12.0,'VAZIO',.19)]
        res += [line(1.75,5.15,10.25,5.15,'#58796c',.10),line(1.65,5.20,1.65,7.25,'#58796c',.10),line(10.35,5.20,10.35,7.25,'#58796c',.10),text(6,5.85,'GUARDA-CORPO H = 1,10 m',.18)]
    # Cotas gerais e cadeias da construção, entre eixos e faces explicitadas.
    res += [dimension(0,36.0,12,36.0,'12,00'),dimension(-1.10,0,-1.10,35,'35,00'),dimension(0,4.55,1.575,4.55,'1,575'),dimension(10.425,4.55,12,4.55,'1,575'),dimension(12.75,0,12.75,5.05,'5,05'),dimension(12.75,33.50,12.75,35,'1,50')]
    res.append(text(6,37.1,'Cotas gerais nas faces externas; dimensões úteis estimadas no quadro.',.18))
    # Quadro lateral legível e escala gráfica; 1 unidade = 1 metro = 10 mm nesta prancha.
    res.append(text(14.0,.7,'AMBIENTES · ÁREA ÚTIL ESTIMADA',.27,anchor='start'))
    for i,r in enumerate(rooms):
        y=1.5+i*.67
        if r['id']=='patio':name=r['uso'];detail=f"{r['w']*r['h']:.2f} m² abertos"
        else:
            a=next(a for a in areas['ambientes'] if a['nivel']==level and a['id']==r['id']);name=r['uso'];detail=f"{a['largura_util']:.2f} × {a['profundidade_util']:.2f} · {a['area_util']:.2f} m²"
        res += [text(14,y,f'{i+1:02d} {name}',.235,anchor='start'),text(14,y+.25,detail.replace('.',','),.195,fill='#6f7e6b',anchor='start')]
    for i,s in enumerate(['5 quartos · 3 banhos reversíveis + 2 privativos','Janelas propostas abrindo para fora','Gourmet: 10 lugares · quiosque: 8 lugares','Escada: 18 espelhos de 17,5 cm; piso 28 cm','Guarda-corpos: 1,10 m no desenho','Vigas e pilares: reserva arquitetônica, sem cálculo','Acesso lateral em gramado: rota secundária','Entrada principal e percurso interno: piso contínuo']):res.append(text(14,18.0+i*.47,s,.20,anchor='start'))
    res.append(text(14,22.5,'ORIENTAÇÃO E VENTO · dados do briefing',.23,anchor='start'))
    cx,cy=18.7,26.3
    for az,label in [(0,'N'),(66,'Nascer JUN'),(114,'Nascer DEZ'),(246,'Pôr DEZ'),(294,'Pôr JUN')]:
        angle=math.radians(az-115);xx=cx+2.35*math.sin(angle);yy=cy-2.35*math.cos(angle)
        res += [line(cx,cy,xx,yy,'#476f5c' if az==0 else '#be9153',.05 if az==0 else .025),text(xx,yy+.15,label,.21)]
    res += [line(cx+1,cy-2.75,cx+.3,cy-.8,'#4a969f',.06),text(cx+1.3,cy-2.9,'Vento SE 135°',.21)]
    res.append(text(14,30.6,'ESCALA GRÁFICA · metros',.23,anchor='start'))
    for i in range(5):res.append(rect(14+i,31.0,15+i,31.15,'#354e3e' if i%2==0 else '#fff','#354e3e',.02))
    for i in range(6):res.append(text(14+i,31.55,i,.20))
    res += [text(14,32.2,'1:100 ao imprimir em A3, sem ajustar à folha.',.20,anchor='start'),text(14,33.0,f"Solo natural conservador: {areas['solo_natural_conservador']:.2f} m² ({areas['solo_natural_percentual']:.2f}%)".replace('.',','),.20,anchor='start'),text(14,33.5,'Inclui exclusão de vagas, piscina, pisos e beirais.',.19,anchor='start'),text(14,34.4,'Estudo para avaliação. Executivo e licenças posteriores.',.19,anchor='start'),'</svg>']
    (OUT/f'04-{level}-R1.svg').write_text('\n'.join(res),encoding='utf-8')

def roof_plan():
    s=header('IMPLANTAÇÃO E COBERTURA · CAIMENTOS PROPOSTOS')
    s += [rect(0,0,12,35,'#e2ead9','#52695a',.04)]
    for name,b,basez,t,drain in ROOFS:
        x0,y0,x1,y1=b;s += [rect(*b,'#e3dccd','#7f8c79',.035),text((x0+x1)/2,(y0+y1)/2,name,.19),text((x0+x1)/2,(y0+y1)/2+.3,f'base +{basez:.2f} · caimento 1%',.16)]
        if drain=='fundos':s.append(line((x0+x1)/2,y0+.5,(x0+x1)/2,y1-.2,'#62949a',.05))
        else:s.append(line(x0+.4,(y0+y1)/2,x1-.2,(y0+y1)/2,'#62949a',.05))
    s += [dimension(0,36,12,36,'12,00'),dimension(-1,0,-1,35,'35,00')]
    notes=['Lajes de cobertura com regularização inclinada.', 'Coletores e condutores representados no modelo.', 'Descarga prevista para sistema dentro do próprio lote.', 'Não usar muro do vizinho como apoio nem drenagem.', 'Pátio lateral aberto ao céu entre cozinha e gourmet.', 'Vão da escada coberto no nível superior, sem laje no vazio.', 'Cobertura da cozinha fechada nesta revisão.', 'Estrutura, impermeabilização e hidráulica: detalhar em executivo.']
    for i,n in enumerate(notes):s.append(text(14,2+i*.7,n,.22,anchor='start'))
    s.append(text(14,9.0,'Recuos das faces de paredes/pilares:',.26,anchor='start'))
    for i,n in enumerate(['Frente: mínimo desenhado 5,05 m','Laterais: mínimo desenhado 1,55 m','Fundos do bloco de apoio: 1,50 m','Beirais tratados separadamente; validação municipal necessária.']):s.append(text(14,9.7+i*.6,n,.22,anchor='start'))
    s += [text(14,14,'Não foi confirmada a zona cadastral do lote.',.23,anchor='start'),text(14,14.7,'LC 034/2022: art. 141 remete ao Anexo 13-A.',.22,anchor='start'),text(14,15.4,'A implantação atende às premissas do briefing;',.22,anchor='start'),text(14,16.1,'isso não equivale a aprovação urbanística.',.22,anchor='start'),'</svg>']
    (OUT/'04-cobertura-R1.svg').write_text('\n'.join(s),encoding='utf-8')

def section():
    s=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 650" width="1200" height="650">','<rect width="1200" height="650" fill="#fcfaf5"/>']
    def T(x,y,t,size=16):return f'<text x="{x}" y="{y}" font-family="Arial" font-size="{size}" fill="#314c3b">{E(t)}</text>'
    s += [T(45,45,'ESCADA EM U · CORTE DESENVOLVIDO ESQUEMÁTICO',24),T(45,75,'Os dois lances aparecem desenvolvidos; não é um único plano de corte real.',15)]
    scale=88;ox=100;oy=545
    def pt(x,z):return ox+x*scale,oy-z*scale
    def L(x,z,xx,zz,color='#6b7768',width=2):
        a,b=pt(x,z);c,e=pt(xx,zz);return f'<line x1="{a}" y1="{b}" x2="{c}" y2="{e}" stroke="{color}" stroke-width="{width}"/>'
    s += [L(-.3,0,1.0,0),L(5.815,3.15,8.1,3.15),L(-.3,6.10,8.1,6.10)]
    x=0;z=0
    for i in range(9):
        s.append(L(x,z,x,z+.175));z+=.175
        if i<8:s.append(L(x,z,x+.28,z));x+=.28
    s.append(L(x,z,x+1.335,z));x+=1.335
    for i in range(9):
        s.append(L(x,z,x,z+.175));z+=.175
        if i<8:s.append(L(x,z,x+.28,z));x+=.28
    s += [L(0,1.095,2.24,2.495,'#b38252',4),L(3.575,2.67,5.815,4.07,'#b38252',4),T(50,575,'±0,00 · térreo'),T(730,280,'+3,15 · superior'),T(700,120,'+6,10 · face inferior da cobertura'),T(75,615,'18 × 0,175 = 3,15 m · 16 pisos de 0,28 m + patamar · 2e+p = 0,63 m',17),T(760,360,'Guarda-corpo: 1,10 m'),T(760,390,'Lance nominal: 1,10 m'),T(760,420,'Entre corrimãos: ~0,92 m'),T(760,450,'Altura livre verificada ≥2,10 m'),T(760,480,'nos elementos representados.'),'</svg>']
    (OUT/'04-corte-escada-R1.svg').write_text('\n'.join(s),encoding='utf-8')

if __name__=='__main__':
    for lv in ('terreo','superior'):plans(lv)
    roof_plan();section()
    (ROOT/'QUADRO-AREAS-04-R1.json').write_text(json.dumps(areas,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Geradas quatro pranchas R1; plantas A3 1:100, implantação/cobertura e corte desenvolvido.')
