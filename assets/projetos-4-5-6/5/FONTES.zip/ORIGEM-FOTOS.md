# Fotos interpretativas — Casas 5 e 6 / 13-11-2026

Gerador: ferramenta de imagem OpenAI disponível nesta sessão. Não foram feitas no NanoBanana/Gemini. Originais gerados com 1536 × 1024 px; sem afirmar resolução 4K ou fotografia real.

Referências: `CASA-05/render-fachada.png`, `render-lazer.png`, e os dois renders equivalentes da Casa 6, produzidos pelo Blender a partir da arquitetura IngeTrazo revisada e do mobiliário licenciado. As imagens não definem cotas.

Instruções em todas as quatro gerações: editar a referência, preservar câmera, volumes, vãos, pilares, varandas, telhados, posições da piscina e do mobiliário, três vagas/carros e mesa de oito lugares; não inventar vãos, pergolados, chaminés ou piscina maior. Somente materiais, iluminação, reflexos e contexto de semiárido fora do lote interpretativos. Casa 6 deve manter parede frontal térrea cega e telhado cerâmico no pavilhão posterior. Casa 5 mantém alpendre aberto à direita e parede superior cega sobre o gourmet.

Inspeção visual: mantidos os volumes e principais alinhamentos, posição relativa da piscina/quiosque/apoio, vãos, varandas frontais e tipos de cobertura nas quatro imagens. Oito assentos por mesa, com os posteriores parcialmente encobertos pelo telhado na Casa 6. Detalhes de caixilhos, acabamento dos telhados, modelos dos veículos, reflexos, paisagem e textura do piso são interpretativos. Não há promessa de correspondência pixel a pixel ou uso executivo. O site oferece comparação com cada render de referência.

Originais preservados no acervo de imagens geradas da sessão; cópias organizadas em `CASA-05/FOTOS-IA` e `CASA-06/FOTOS-IA`. Nenhuma imagem das Casas 1–4 ou 7–9 substituída.
