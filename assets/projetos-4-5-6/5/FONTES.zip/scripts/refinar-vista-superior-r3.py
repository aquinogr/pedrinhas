"""Recorte diagramático: não mostrar pedaços de pilares do térreo flutuando sob o superior. Não exporta nem modifica modelos."""
import bpy,bmesh,sys
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent;n=int(sys.argv[sys.argv.index('--')+1]);out=ROOT/'PUBLICACAO-R3'/f'CASA-{n:02}'
bpy.ops.wm.open_mainfile(filepath=str(out/'CASA-MOBILIADA-JUNTAS.blend'))
for ob in bpy.data.objects:
    if ob.type!='MESH':continue
    vv=[ob.matrix_world @ Vector(v) for v in ob.bound_box]
    if ob.name.startswith(('Cobertura','Caimento','Calha','Oitao')) or max(v.z for v in vv)<3.13:ob.hide_render=True;continue
    if min(v.z for v in vv)<3.13:
        ob.data=ob.data.copy();bm=bmesh.new();bm.from_mesh(ob.data);bm.transform(ob.matrix_world)
        bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),dist=.00001,plane_co=Vector((0,0,3.13)),plane_no=Vector((0,0,1)),clear_inner=True,clear_outer=False)
        bm.transform(ob.matrix_world.inverted());bm.to_mesh(ob.data);bm.free();ob.data.update()
s=bpy.context.scene;cam=s.camera;cam.location=(22,-4,25);cam.rotation_euler=(Vector((6,12.5,3.5))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=26;s.render.filepath=str(out/'render-superior.png');bpy.ops.render.render(write_still=True)
print('VISTA SUPERIOR REFINADA',n,flush=True)
