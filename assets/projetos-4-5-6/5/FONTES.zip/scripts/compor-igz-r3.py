"""Compõe e reabre os nativos com texturas e acervo detalhado."""
from pathlib import Path
import json,hashlib,zipfile
from core.scene import Scene
from core.layers import Layer
from formats.igz import load_into,save_scene
from formats.glb import load_glb
import core.texture
ROOT=Path(__file__).resolve().parent
for n in (5,6):
    out=ROOT/'PUBLICACAO-R3'/f'CASA-{n:02}';core.texture.texture_cache_root=lambda:out/'CACHE-TEXTURAS'
    scene=Scene();load_into(scene,out/'ARQUITETURA.igz');feet_corrected=0
    for kind,label in [('terreo','Mobiliário térreo'),('superior','Mobiliário superior'),('veiculos','Veículos')]:
        scene.layers.append(Layer(label));before=len(scene.groups);offset=load_glb(scene,out/f'COMPLEMENTO-{kind}.glb');assert offset is None and len(scene.groups)==before+1
        g=scene.groups[-1];g.name=label;g.layer=label
        # A simplificação pode projetar pés cerca de 1 mm abaixo do piso.
        # Corrige apenas essa penetração numérica na cópia IGZ, sem elevar o pavimento.
        if kind in ('terreo','superior'):
            floor=3.15 if kind=='superior' else 0
            for v in g.mesh.vertices:
                zz=v.position.z()
                if floor-.005<=zz<floor:
                    v.position.setZ(floor);feet_corrected+=1
        pp=[(v.position.x(),v.position.y(),v.position.z()) for v in g.mesh.vertices]
        lo=[min(v[i] for v in pp) for i in range(3)];hi=[max(v[i] for v in pp) for i in range(3)]
        assert lo[0]>=0 and hi[0]<=12 and lo[1]>=0 and hi[1]<=35,(label,lo,hi)
        if kind=='superior':assert lo[2]>=3.149,(label,lo)
    native=out/'CASA-MOBILIADA.igz';save_scene(scene,native);check=Scene();load_into(check,native);assert len(check.groups)==len(scene.groups)
    textures=0
    for g in check.groups:
        for face in g.mesh.faces:
            t=face.attrs.get('texture') if face.attrs else None
            if t:assert Path(t['path']).is_file();textures+=1
    assert textures>0 and zipfile.is_zipfile(native)
    with zipfile.ZipFile(native) as z:assert z.testzip() is None and any(s.startswith('textures/') for s in z.namelist())
    r=dict(data='2026-11-13',numero=n,estado='PASSOU',grupos=len(check.groups),faces_texturizadas=textures,vertices_pes_reassentados_no_piso=feet_corrected,recursos_incorporados=True,sha256=hashlib.sha256(native.read_bytes()).hexdigest(),limite='Reabertura e integridade nativa; ver interface e auditorias separadas. Pés de cópias simplificadas reajustados até 5 mm ao plano nominal, sem mudar arquitetura ou GLB de apresentação.')
    (out/'QA-NATIVO-MOBILIADO.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');print(n,r)
