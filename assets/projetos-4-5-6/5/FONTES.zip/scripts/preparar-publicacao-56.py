"""Integra apenas 5/6 numa cópia atual do site. Sem git/push neste script."""
import base64,hashlib,html,json,mimetypes,re,shutil,zipfile
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parent
PUB=ROOT.parent/'PUBLICACAO-05-06'
R3=ROOT/'PUBLICACAO-R3'
BASE='assets/projetos-4-5-6/'
def read(p):return p.read_text(encoding='utf8')
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def uri(p):return 'data:'+(mimetypes.guess_type(p.name)[0] or 'application/octet-stream')+';base64,'+base64.b64encode(p.read_bytes()).decode()
def jpg(src,dest,width=None):
    im=Image.open(src).convert('RGB')
    if width:im.thumbnail((width,round(width*2/3)))
    im.save(dest,quality=93,optimize=True)
DATA={}
for n in [5,6]:
    src=R3/f'CASA-{n:02}';old=ROOT/f'CASA-{n:02}';dst=PUB/BASE/str(n);dst.mkdir(parents=True,exist_ok=True)
    c=json.loads(read(old/'CONCEPCAO.json'));a=json.loads(read(old/'AREAS.json'));e=json.loads(read(old/'REVISAO-ESQUADRIAS-PUBLICACAO.json'))
    assert not e['falhas']
    decisions=(['Estar e cozinha na frente, lazer no jardim central e dormitórios térreos mais reservados ao fundo.','Gourmet com mesa de oito lugares ao lado da piscina; lavabo e apoio próximos, sem bloquear o acesso ao lazer.','Master, escritório, varanda frontal e quinto quarto com banho no superior.','Três vagas descobertas; entrada pelo alpendre à direita e escada em U com chegada em hall comum.'] if n==5 else ['Ala íntima na frente e pavilhão social ao fundo, conectados por passagem coberta junto ao jardim.','Piscina transversal nos fundos junto ao quiosque; mesa de oito lugares na varanda de refeições e apoio na faixa posterior.','Master, escritório, varanda frontal e quinto quarto com banho no superior.','Entrada lateral esquerda, escada em U e três vagas descobertas; telhado de duas águas sobre o pavilhão social.'])
    d=dict(nome=c['nome'],subtitulo=('Lazer central entre pavilhões, cinco quartos e varanda frontal.' if n==5 else 'Ala íntima frontal, jardim de ligação e lazer no pavilhão dos fundos.'),areas=a,ambientes=c['ambientes'],decisoes=decisions,esquadrias=dict(janelas=e['janelas']),notaFotos='Imagens fotográficas interpretativas geradas por IA a partir dos renders deste modelo IngeTrazo/Blender. Compare cada vista com sua referência: materiais, reflexos e paisagem não substituem as plantas cotadas nem constituem projeto executivo.',vistas=[dict(id='01',nome='Piscina e gourmet central' if n==5 else 'Piscina e pavilhão dos fundos'),dict(id='02',nome='Fachada, varanda e três vagas')])
    DATA[str(n)]=d
    d['notaFotos']='Imagens fotográficas interpretativas geradas com a ferramenta de imagem OpenAI a partir dos renders deste modelo IngeTrazo/Blender. Originais de 1536 × 1024 px, não 4K. Compare cada vista com sua referência: materiais, reflexos, paisagem e pequenos detalhes são interpretativos; as fotos não substituem plantas cotadas nem projeto executivo.'
    files=['terreo.svg','superior.svg','PLANTAS-A3.pdf','AREAS.json','AUDITORIA.json','REVISAO-ESQUADRIAS-PUBLICACAO.json','QA-MOBILIARIO-ESQUADRIAS-R3.json','QA-INTERFACE-R3.json','QA-NATIVO-MOBILIADO.json','DETALHES-R3.json','CASA-MOBILIADA.glb','CASA-MOBILIADA.igz']
    for f in files:shutil.copy2(src/f,dst/f)
    (dst/'fotos').mkdir(exist_ok=True)
    for view,render in [('01','lazer'),('02','fachada')]:
        jpg(src/f'render-{render}.png',dst/'fotos'/f'{view}-modelo.jpg')
        photo=src/'FOTOS-IA'/f'{view}.png'
        assert photo.exists(),f'Imagem fotográfica ausente: {photo}'
        jpg(photo,dst/'fotos'/f'{view}-foto.jpg');jpg(photo,dst/'fotos'/f'{view}-thumb.jpg',420)
    for f in ['terreo','superior']:jpg(src/f'render-{f}.png',dst/f'render-{f}.jpg')
    credits=read(PUB/BASE/'4/CREDITOS-ACERVO-3D.md')
    credits=credits.replace('| Potted Plant 01 | Rico Cilliers | https://polyhaven.com/a/potted_plant_01 |\n','')
    credits=credits.replace('O acervo inclui também o carro pequeno Scopia; ele não é utilizado na visualização atual.','Nesta revisão são usados dois SUVs e um carro compacto central.')
    credits=credits.replace('Os modelos realistas são usados no visualizador de navegador; os `.sh3d` continuam com os objetos de seu próprio acervo, descritos nos créditos originais.','Nesta entrega, GLB e navegador contêm os modelos texturizados; o IGZ incorpora cópias simplificadas do mesmo mobiliário para edição. Não há novo arquivo SH3D nesta revisão.')
    write(dst/'CREDITOS-ACERVO-3D.md',credits)
    memorial=f'''# Casa {n} — {c['nome']} / revisão R3

Distribuição aprovada pelo cliente; publicação dos projetos 5 e 6 autorizada em 13/11/2026. Estudo preliminar, não usar para obra.

## Organização

'''+''.join('- '+t+'\n' for t in decisions)+f'''
## Revisão solicitada

Giros completos de portas e envolventes de abertura das {e['janelas']} janelas externas ensaiados, sem interferências nos cenários descritos nos relatórios. Janelas maxim-ar abrindo para fora com limitador de estudo a 15°; não pressupor abertura irrestrita. Cassete/folhas de correr, acesso à escada, banhos reversíveis, mobiliário e circulação da mesa também estão na auditoria geométrica. Folhas reais, ferragens, espessuras e instalações ainda exigem detalhamento.

Escada: 18 espelhos de 17,5 cm, pisos de 28 cm, largura nominal 1,20 m por lance (aproximadamente 1,08 m entre corrimãos). Guarda de 1,10 m, corrimãos e patamar representados. Altura livre mínima amostrada: 3,00 m. Isso não certifica resistência, acessibilidade ou execução.

Foram eliminadas sobreposições coplanares no piso externo e nos encontros do guarda-corpo frontal com pilares, preservando distribuição e cotas aprovadas. Na Casa 6, o oitão frontal do pavilhão fecha o encontro sob o telhado. Móveis e carros texturizados respeitam os envelopes horizontais do estudo. No IGZ simplificado, pés com variação inferior a 5 mm foram reassentados no piso nominal; o GLB de apresentação conserva a malha de origem. Mesa com oito cadeiras no local indicado; sem segunda mesa fictícia no quiosque.

## Áreas estimadas

Térreo {a['terreo']:.2f} m²; superior {a['superior']:.2f} m²; construída {a['construida']:.2f} m²; projeção {a['projecao']:.2f} m². Solo natural conservador {a['solo_natural']:.2f} m² ({a['solo_natural_percentual']:.2f}%). Piscina 2,50 × 4,00 m. Vagas 3 × 2,50 × 5,00 m. O cálculo desconta vagas inteiras, piscina/bordas e pisos externos. Casa 6 com margem pequena: mudanças exigem recálculo.

## Premissas urbanísticas e limites

Recuos do briefing: 5 m frontais e 1,50 m laterais/fundos; zona cadastral e regras do condomínio NÃO confirmadas. Se ZT2, a LC 034/2022 contém recuos diferentes que exigem outra implantação. Não foi presumida permissão para encostar apoio na divisa. Fonte documental: [Diário Oficial municipal, edição 2.960](https://doem.org.br/pe/petrolina/diarios/previsualizar/XVrk7eNw). Não é certidão urbanística nem consolidação de todos os atos posteriores.

Estrutura/fundações, vãos, guarda-corpos, segurança infantil da piscina, instalações, exaustão, drenagem, impermeabilização, esquadrias e acessibilidade dependem de profissionais habilitados e licenciamento. Áreas gramadas de passagem não são rotas acessíveis pavimentadas. Os relatórios não cobrem deformações, ferragens ou obstáculos não modelados.

## Entrega e origem visual

IGZ editável no IngeTrazo, GLB mobiliado, plantas SVG e PDF A3 a 1:100 em impressão a 100%, modelo 3D web com modos de pavimento e câmeras de inspeção. Renders com Blender; fotos interpretativas por gerador de imagem a partir das mesmas câmeras. O botão de comparação mantém disponível a geometria de referência. Paisagem, reflexos e materiais nas fotos são interpretativos, não medidas ou especificações para obra. Não se afirma fidelidade pixel a pixel.

Móveis Poly Haven CC0; carros Scopia CC BY 3.0, redimensionados. Ver arquivo de créditos. Fontes incluem a concepção e scripts; modelos e texturas exigem o acervo citado. Não alterar os projetos de outras equipes ou substituir casas já publicadas.
'''
    write(dst/'MEMORIAL.md',memorial)
    # O mesmo controlador de câmera da revisão aprovada, agora com o GLB mobiliado.
    oldhtml=read(old/'modelo-3d.html');blocks=list(re.finditer(r'<script[^>]*>(.*?)</script>',oldhtml,re.S));assert len(blocks)==4
    code=blocks[-1].group(1)
    code,count=re.subn(r"\{const bytes=Uint8Array\.from\(atob\('[A-Za-z0-9+/=]+'\),c=>c\.charCodeAt\(0\)\);new THREE\.GLTFLoader\(\)\.parse\(bytes\.buffer,'',loaded,failed\);\}","new THREE.GLTFLoader().load('CASA-MOBILIADA.glb',loaded,undefined,failed);",code);assert count==1
    code=re.sub(r'const adjusted=new Set\(\);root\.traverse\(o=>\{if\(!o\.isMesh\)return;for\(const m of \(Array\.isArray\(o\.material\)\?o\.material:\[o\.material\]\)\)\{if\(adjusted\.has\(m\)\)\)continue;adjusted\.add\(m\);if\(m\.color\)m\.color\.convertSRGBToLinear\(\);\}\}\);','',code)
    # Forma literal, para versões do controlador que diferem na parentização.
    start=code.find('const adjusted=new Set();');end=code.find('root.updateMatrixWorld(true);',start)
    if start>=0 and end>start:code=code[:start]+code[end:]
    code=code.replace('Cobertura|Caimento|Calha','Cobertura|Caimento|Calha|Oitao').replace('estudo R2','estudo R3').replace('mobiliário esquemático, não foto de apresentação','mobiliário texturizado; medidas nas plantas cotadas')
    shell=oldhtml[:blocks[0].start()];shell=shell.replace('mobiliário esquemático','mobiliário texturizado').replace(f'../index.html?projeto={n}',f'../../../projetos-4-5-6.html?projeto={n}')
    libs=[m.group(1) for m in blocks[:3]]
    external=''.join('<script src="../../revisadas/'+f+'"></script>' for f in ['three.min.js','OrbitControls.js','GLTFLoader.js'])
    write(dst/'modelo-3d.html',shell+external+'<script>'+code+'</script></body></html>')
    embed="{const bytes=Uint8Array.from(atob('"+base64.b64encode((dst/'CASA-MOBILIADA.glb').read_bytes()).decode()+"'),c=>c.charCodeAt(0));new THREE.GLTFLoader().parse(bytes.buffer,'',loaded,failed);}"
    offline3d=shell+''.join('<script>'+v+'</script>' for v in libs)+'<script>'+code.replace("new THREE.GLTFLoader().load('CASA-MOBILIADA.glb',loaded,undefined,failed);",embed)+'</script></body></html>'
    write(src/'MODELO-OFFLINE.html',offline3d)
    with zipfile.ZipFile(dst/'FONTES.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in ['CONCEPCAO.json','AREAS.json']:z.write(old/f,f)
        for f in ['definir.py','geometria.py','gerar-plantas.py','auditar.py','modelar.py','auditar-esquadrias-publicacao.py','preparar-r3.py','mobiliar-renderizar-r3.py','corrigir-juntas-render-r3.py','refinar-vista-superior-r3.py','compor-igz-r3.py','auditar-mobiliado-r3.py','inspecionar-ingetrazo-r3.py','preparar-publicacao-56.py','publico-56.js']:
            z.write(ROOT/f,'scripts/'+f)
        z.writestr('LEIA-ME.md',memorial);z.write(dst/'CREDITOS-ACERVO-3D.md','CREDITOS-ACERVO-3D.md')
        for f in ['DETALHES-R3.json','REVISAO-ESQUADRIAS-PUBLICACAO.json','AUDITORIA.json','QA-MOBILIARIO-ESQUADRIAS-R3.json','QA-NATIVO-MOBILIADO.json','QA-INTERFACE-R3.json']:z.write(dst/f,f)
        z.write(R3/'ORIGEM-FOTOS.md','ORIGEM-FOTOS.md')

group=PUB/'projetos-4-5-6.html';backup=R3/'PAGINA-GRUPO-ANTES.html'
if not backup.exists():shutil.copy2(group,backup)
original=read(backup);style=re.search(r'<style>(.*?)</style>',original,re.S).group(1)
top=re.search(r'(<div class="top">.*?</nav></div></div>)',original,re.S).group(1)
dataset='window.PEDRINHAS56='+json.dumps(DATA,ensure_ascii=False,separators=(',',':'))+';'
write(PUB/BASE/'dados-56.js',dataset);shutil.copy2(ROOT/'publico-56.js',PUB/BASE/'publico-56.js')
scripts='<script src="'+BASE+'dados-56.js"></script><script src="'+BASE+'publico-56.js"></script>'
updated=original
for n in [5,6]:updated=updated.replace(f'Casa {n}<span class="tab-status">em preparação</span>',f'Casa {n} · '+DATA[str(n)]['nome'])
updated=updated.replace('Projetos 5 e 6 reservados.','Casas 5 e 6: plantas, fotos, revisão de esquadrias e 3D navegável.').replace('Casa 4 / Átrio Social · revisão R1-P1 · estudo preliminar · Casas 5 e 6: plantas, fotos, revisão de esquadrias e 3D navegável.','Casas 4, 5 e 6 · estudos preliminares · Casa 4 R1-P1 / Casas 5 e 6 R3')
updated=updated.replace('</body>',scripts+'</body>');write(group,updated)
for n in [5,6]:
    d=DATA[str(n)];title=f'Casa {n} — '+d['nome']
    detail=f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)} · Pedrinhas</title><meta name="description" content="Plantas cotadas, fotos interpretativas, revisão de portas e janelas e 3D navegável."><style>{style}</style></head><body data-casa="{n}">{top}<main><div class="eyebrow">IngeTrazo + Blender · estudo preliminar</div><h1>{html.escape(title)}</h1><p class="lead">{d["subtitulo"]}</p><p><a href="projetos-4-5-6.html?projeto={n}">← Projetos 4 · 5 · 6</a></p><div id="project56"></div></main><footer class="bottom"><div class="in">Pedrinhas · Casa {n} / R3 · estudo preliminar, não usar para obra.</div></footer>{scripts}</body></html>'
    write(PUB/f'projeto-{n}.html',detail)
    dst=PUB/BASE/str(n);off=detail.replace(scripts,'<script>'+dataset+'</script><script>'+read(ROOT/'publico-56.js')+'</script>')
    # Remapeia URLs locais depois da montagem dinâmica, antes de qualquer imagem/iframe carregar.
    js=read(ROOT/'publico-56.js');mapping={}
    for p in [*dst.glob('*.svg'),*dst.glob('render-*.jpg'),* (dst/'fotos').glob('*.jpg')]:mapping[BASE+str(n)+'/'+p.relative_to(dst).as_posix()]=uri(p)
    mapping[BASE+str(n)+'/modelo-3d.html']='data:text/html;base64,'+base64.b64encode(read(R3/f'CASA-{n:02}'/'MODELO-OFFLINE.html').encode()).decode()
    # URLs dos elementos são atribuídos por JS: troca no template/base e nas concatenações.
    offjs=js.replace("const b='assets/projetos-4-5-6/'+n+'/'","const b='assets/projetos-4-5-6/'+n+'/'")
    # Intercepta apenas atributos de recursos na árvore e nos novos elementos (sem rede).
    resolver='const RES='+json.dumps(mapping,separators=(',',':'))+';const originalSet=Element.prototype.setAttribute;Element.prototype.setAttribute=function(k,v){return originalSet.call(this,k,RES[v]||v)};for(const [proto,key] of [[HTMLImageElement.prototype,"src"],[HTMLAnchorElement.prototype,"href"]]){const desc=Object.getOwnPropertyDescriptor(proto,key);Object.defineProperty(proto,key,{...desc,set(v){desc.set.call(this,RES[v]||v)}})};const iframeSrc=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,"src");Object.defineProperty(HTMLIFrameElement.prototype,"src",{...iframeSrc,set(v){const u=RES[v];if(u&&u.startsWith("data:text/html;base64,")){this.srcdoc=new TextDecoder().decode(Uint8Array.from(atob(u.split(",")[1]),c=>c.charCodeAt(0)))}else iframeSrc.set.call(this,v)}});const desc=Object.getOwnPropertyDescriptor(Element.prototype,"innerHTML");Object.defineProperty(Element.prototype,"innerHTML",{...desc,set(v){for(const [k,u] of Object.entries(RES))v=v.split(k).join(u);desc.set.call(this,v)}});'
    off=off.replace('<script>'+js+'</script>','<script>'+resolver+offjs+'</script>')
    off=off.replace('</h1>','</h1><p class="note">Cópia offline: plantas, imagens e 3D incorporados. Os downloads complementares e links externos precisam dos arquivos publicados ou de conexão.</p>',1)
    write(dst/'CASA-OFFLINE.html',off)

home=PUB/'index.html';homebackup=R3/'HOME-ANTES.html'
if not homebackup.exists():shutil.copy2(home,homebackup)
s=read(homebackup)
for n in [5,6]:
    pattern=rf'<a\b[^>]*class="hc"[^>]*href="projetos-4-5-6.html\?projeto={n}".*?</a>'
    m=re.search(pattern,s,re.S)
    if not m:
        pattern=rf'<a\b[^>]*href="projetos-4-5-6.html\?projeto={n}"[^>]*class="hc".*?</a>';m=re.search(pattern,s,re.S)
    assert m,f'Card da casa {n} não localizado'
    oldcard=m.group(0);newcard=f'<a class="hc" href="projetos-4-5-6.html?projeto={n}#fotos56"><img src="{BASE}{n}/fotos/01-thumb.jpg" alt="" loading="lazy" width="480" height="320"><span class="hc-t"><b>{n:02} · Casa {html.escape(DATA[str(n)]["nome"])}</b><small>Plantas cotadas · fotos e 3D navegável</small></span></a>'
    # Textos internos variam conforme a revisão do site; preserva classe e destino, altera somente este card.
    newcard=re.sub(r'(<h3[^>]*>).*?(</h3>)',lambda m:m[1]+f'Casa {n} · '+html.escape(DATA[str(n)]['nome'])+m[2],newcard,flags=re.S)
    newcard=re.sub(r'(<p[^>]*>).*?(</p>)',lambda m:m[1]+'Plantas cotadas, fotos e 3D navegável'+m[2],newcard,flags=re.S)
    newcard=newcard.replace('Em preparação','Disponível').replace('em preparação','Disponível').replace('Espaço reservado','Projeto completo')
    s=s[:m.start()]+newcard+s[m.end():]
write(home,s)
readme=PUB/'README.md';r=read(readme);r=r.replace('- **5 e 6**: espaços reservados na mesma página, ainda em preparação.','- **5 e 6**: Jardim entre Pavilhões e Duas Varandas; plantas cotadas, fotos interpretativas, revisão de esquadrias, modelo 3D navegável e arquivos IngeTrazo. Distribuição aprovada pelo cliente; revisão R3 de 13/11/2026.');write(readme,r)
manifest={p.relative_to(PUB).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in (PUB/BASE).rglob('*') if p.is_file() and ('/5/' in p.as_posix() or '/6/' in p.as_posix())}
write(R3/'MANIFESTO-PUBLICACAO.json',json.dumps(manifest,ensure_ascii=False,indent=2));print('PREPARADO',len(manifest),'arquivos exclusivos 5/6')
