"""Ensaios independentes de distribuição, giro e rotas contínuas.

Lê os JSON, não importa definir.py. Corpo circular de 0,60 m, grade de 0,10 m.
Box é piso transitável: fechamento deve ser dobrável/retrátil e detalhado.
Não certifica legislação, estrutura, hidráulica ou acessibilidade.
"""
import json,math,collections
from pathlib import Path
from shapely.geometry import box,Point,LineString,Polygon
from shapely.ops import unary_union
from shapely.prepared import prep
from geometria import wall_parts,door_shape,stair,measures,opening_point,slab
ROOT=Path(__file__).resolve().parent
def audit(d):
    findings=[];checks=[];metrics=measures(d)
    def test(condition,message,detail=None):
        (checks if condition else findings).append(dict(item=message,detalhe=detail))
    rooms=d['ambientes'];lookup={(r['nivel'],r['id']):r for r in rooms}
    for level in ('terreo','superior'):
        rr=[r for r in rooms if r['nivel']==level]
        for i,a in enumerate(rr):
            for b in rr[i+1:]:test(box(*a['limites']).intersection(box(*b['limites'])).area<.001,'Ambientes sem sobreposição '+level+' '+a['id']+'/'+b['id'])
    for roof in d['coberturas']:
        x,y,X,Y=roof['limites'];test(x>=1.5-.001 and X<=10.5+.001 and y>=5-.001 and Y<=33.5+.001,'Cobertura dentro das premissas: '+roof['nome'])
        test(box(*roof['limites']).intersection(box(*d['piscina'])).area<.001,'Piscina não coberta: '+roof['nome'])
    test(metrics['solo_natural']>=126,'Solo natural ≥ 30% do briefing',metrics)
    test(metrics['piscina']==10,'Piscina pequena de 10 m²')
    test(len(d['vagas'])==3,'Três vagas de 2,50 × 5,00')
    for p in d['pilares']:
        test(p['x']-.1>=1.5-1e-5 and p['x']+.1<=10.5+1e-5 and p['y']-.1>=5-1e-5 and p['y']+.1<=33.5+1e-5,'Pilar dentro dos recuos do briefing',p)
    upper_slab=slab(d,'superior')
    for ar in rooms:
        if ar['tipo']=='escada':continue
        roof_polys=[box(*r['limites']) for r in d['coberturas'] if r['z']>=(6 if ar['nivel']=='superior' else 3)-.001]
        coverage=unary_union(roof_polys+([upper_slab] if ar['nivel']=='terreo' else []))
        missing=box(*ar['limites']).buffer(-.075).difference(coverage).area
        test(missing<.002,'Cobertura integral do ambiente: '+ar['nivel']+' '+ar['id'],round(missing,4))
    for level in ('terreo','superior'):
        rr=[r for r in rooms if r['nivel']==level]
        mm=[m for m in d['moveis'] if m['nivel']==level]
        for i,a in enumerate(mm):
            test(box(*lookup[(level,a['ambiente'])]['limites']).buffer(-.07).covers(box(*a['limites'])),'Móvel dentro do ambiente: '+level+' '+a['ambiente']+' '+a['nome'])
            for b in mm[i+1:]:
                if a['ambiente']==b['ambiente']:test(box(*a['limites']).intersection(box(*b['limites'])).area<.002,'Móveis sem colisão: '+level+' '+a['ambiente']+' '+a['nome']+'/'+b['nome'])
        walls=unary_union([box(*w['limites']) for w in wall_parts(d,level) if w['z']<2.1 and w['z']+w['altura']>.08])
        for o in d['aberturas']:
            if o['nivel']!=level:continue
            if o['tipo']=='giro':
                sector=door_shape(o,True).buffer(-.035)
                collisions=[m['ambiente']+'/'+m['nome'] for m in mm if sector.intersection(box(*m['limites'])).area>.003]
                test(not collisions,'Giro sem móvel: '+level+' '+o['a']+'/'+o['b'],collisions)
                test(sector.intersection(walls).area<.005,'Giro sem parede: '+level+' '+o['a']+'/'+o['b'],round(sector.intersection(walls).area,4))
            if o['tipo']=='correr':
                # Faixa necessária ao cassete; precisa de parede contínua de mesma espessura.
                c=o['centro'];w=o['largura'];sg=o.get('bolso',1)
                aa=c+w/2 if sg>0 else c-w*1.5;bb=c+w*1.5 if sg>0 else c-w/2
                f=o['fixo']; pocket=box(aa,f-.04,bb,f+.04) if o['eixo']=='h' else box(f-.04,aa,f+.04,bb)
                test(pocket.difference(walls.buffer(.001)).area<.003,'Cassete em parede contínua: '+level+' '+o['a']+'/'+o['b'])
        # Obstáculos a partir das peças efetivamente modeladas e folhas simultaneamente abertas.
        fixtures=[box(*m['limites']) for m in mm if not m['nome'].startswith('Box')]
        leaves=[door_shape(o) for o in d['aberturas'] if o['nivel']==level and o['tipo'] in ('giro','correr-vidro')]
        pillars=[box(p['x']-.1,p['y']-.1,p['x']+.1,p['y']+.1) for p in d['pilares'] if level=='terreo' or p['z']>=6]
        window_leaves=[]
        if level=='terreo':
            for o in d['aberturas']:
                if o['nivel']!=level or o['tipo']!='janela' or o['peitoril']>=2.1:continue
                p=o['altura']*math.sin(math.radians(o['angulo']))*(-1 if o['lado'] in ('left','top') else 1)
                f=o['fixo'];aa=o['centro']-o['largura']/2;bb=o['centro']+o['largura']/2
                window_leaves.append(box(aa,min(f,f+p),bb,max(f,f+p)) if o['eixo']=='h' else box(min(f,f+p),aa,max(f,f+p),bb))
        obstacles=unary_union([walls,*fixtures,*leaves,*pillars,*window_leaves])
        if level=='terreo':domain=box(.1,0,11.9,35).difference(box(*d['piscina']).buffer(.15))
        else:
            floors=unary_union([box(*r['limites']) for r in rr if r['tipo']!='escada'])
            domain=floors.buffer(.001)
        free=domain.difference(obstacles).buffer(-.30)
        prepared=prep(free)
        for o in d['aberturas']:
            if o['nivel']!=level or o['tipo']=='janela' or o['b']=='escada':continue
            c=o['centro'];w=o['largura'];lo=c-w/2+.33;hi=c+w/2-.33
            if o['tipo']=='correr-vidro':hi=c-.33
            cross=[]
            for i in range(max(1,int((hi-lo)/.05)+1)):
                t=lo+i*.05
                if t>hi+.001:continue
                points=[(t,o['fixo']-.40),(t,o['fixo']+.40)] if o['eixo']=='h' else [(o['fixo']-.40,t),(o['fixo']+.40,t)]
                if prepared.covers(LineString(points)):cross.append(round(t,2))
            # Upper balcony/doors also require usable floor either side, not an alternate route.
            test(bool(cross),'Passagem direta pelo vão: '+level+' '+o['a']+'/'+o['b'],cross[:3])
        # Grelha nas coordenadas mundiais evita saltos diagonais através das paredes.
        nodes={(i,j) for i in range(120) for j in range(351) if prepared.covers(Point(i/10,j/10))}
        components={};count=0
        for seed in nodes:
            if seed in components:continue
            count+=1;components[seed]=count;queue=collections.deque([seed])
            while queue:
                i,j=queue.popleft()
                for v in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
                    if v in nodes and v not in components:
                        # Segmento também deve estar livre; teste de nó isolado não basta.
                        if not prepared.covers(LineString([(i/10,j/10),(v[0]/10,v[1]/10)])):continue
                        components[v]=count;queue.append(v)
        def locate(point):
            near=sorted((n for n in nodes if math.dist((n[0]/10,n[1]/10),point)<=.24),key=lambda v:math.dist((v[0]/10,v[1]/10),point))
            return components[near[0]] if near else None
        def route(a,b,label):
            ca,cb=locate(a),locate(b);test(ca is not None and cb is not None and ca==cb,'Rota contínua: '+level+' '+label,dict(inicio=a,fim=b,componente_inicio=ca,componente_fim=cb))
        def entry(rid):
            ar=lookup[(level,rid)];x,y,X,Y=ar['limites']
            if rid in ('q1','q2','q3','q5','master'):
                bed=next(m for m in mm if m['ambiente']==rid and 'Cama' in m['nome']);bx,by,bX,bY=bed['limites'];return (bX+.35,(by+bY)/2)
            if rid in ('b1','b2','b3','b5','banho-master','lavabo'):
                wc=next(m for m in mm if m['ambiente']==rid and m['nome']=='Bacia sanitária');bx,by,bX,bY=wc['limites'];return (bx-.34,(by+bY)/2) if bx>(x+X)/2 else (bX+.34,(by+bY)/2)
            if rid=='escritorio':return ((x+X)/2,Y-.7)
            if rid=='estar':return (x+3.5,y+2.3)
            if rid=='closet':return ((x+X)/2,y+.95)
            return ((x+X)/2,(y+Y)/2)
        if level=='terreo':
            start=(11.4,.5) if d['numero']==5 else (.6,.5)
            for rid in ['q1','q2','q3','estar','cozinha','lavanderia','deposito','lavabo']:
                ar=lookup[(level,rid)];goal=entry(rid)
                if rid in ('lavanderia','deposito'):x,y,X,Y=ar['limites'];goal=((x+X)/2,y+.6)
                route(start,goal,'rua → '+rid)
            for i in (1,2,3):route(entry('q'+str(i)),entry('b'+str(i)),'quarto '+str(i)+' → banho próprio/reversível')
            s=d['escada'];route(start,(s['x']+.675,s['y']-.60),'rua → partida da escada')
            px,py,pX,pY=d['piscina'];pooldeck=(pX+.55,(py+pY)/2)
            route(entry('cozinha'),pooldeck,'cozinha → deck da piscina')
            route(pooldeck,entry('lavabo'),'piscina → lavabo externo')
        else:
            s=d['escada'];start=(s['x']+2.125,s['y']-.60)
            for rid in ('master','escritorio','q5','closet','b5','banho-master'):route(start,entry(rid),'chegada da escada → '+rid)
            route(entry('master'),entry('banho-master'),'master → banheiro')
            route(entry('q5'),entry('b5'),'suíte 5 → banheiro')
            # Abertura efetiva da varanda é metade do vão de correr.
            for rid in ('master','escritorio'):
                o=next(o for o in d['aberturas'] if o['nivel']==level and o['a']==rid and o['b']=='varanda');p=opening_point(o)
                route(entry(rid),(p[0],p[1]-.60),rid+' → varanda frontal')
        for ar in rr:
            if ar['id'] not in ('q1','q2','q3','q5','master','escritorio','estar','b1','b2','b3','b5','banho-master'):continue
            windows=[o for o in d['aberturas'] if o['nivel']==level and o['a']==ar['id'] and o['tipo'] in ('janela','correr-vidro')]
            area=sum(o['largura']*o['altura'] for o in windows);x,y,X,Y=ar['limites'];use=(X-x-.15)*(Y-y-.15);ratio=8 if ar['id'].startswith('b') else 6
            test(area>=use/ratio,'Abertura nominal conforme referência do briefing: '+level+' '+ar['id'],dict(area=round(area,2),referencia=round(use/ratio,2),ventilacao_efetiva='não calculada'))
        # Envelopes de uso dos armários: uma posição de aproximação frontal livre.
        for m in mm:
            if not m['nome'].startswith('Armário'):continue
            x,y,X,Y=m['limites'];candidates=[(x+.3+i*.10,y-.32) for i in range(max(1,int((X-x-.6)/.10)))]
            candidates=[p for p in candidates if prepared.covers(Point(*p))]
            test(bool(candidates),'Aproximação ao armário: '+level+' '+m['ambiente'],candidates[:3])
        # Oito cadeiras; 0,75 m atrás das cadeiras ocupadas é referência geométrica.
        chairs=[m for m in mm if m['nome']=='Cadeira refeição']
        if chairs:
            test(len(chairs)==8,'Oito cadeiras na mesa, sem sobreposição')
            for idx,m in enumerate(chairs):
                x,y,X,Y=m['limites'];ty=next(t for t in mm if t['nome']=='Mesa 8 lugares')['limites'];sg=-1 if Y<ty[1] else 1
                area=box(x,y-.75,X,y) if sg<0 else box(x,Y,X,Y+.75)
                # Não incluir o próprio assento no espaço posterior.
                test(area.intersection(obstacles).area<.002,'Espaço posterior da cadeira '+str(idx+1),list(area.bounds))
    s=d['escada'];test(abs(s['espelhos']*s['espelho']-d['entre_pisos'])<1e-6,'Escada vence 3,15 m')
    test(.63-1e-6<=2*s['espelho']+s['piso']<=.65,'Blondel 63–65 cm')
    test(s['largura_lance']-.12>=.9,'Largura entre corrimãos ≥ 0,90 m',s['largura_lance']-.12)
    return dict(numero=d['numero'],revisao=d['revisao'],estado='PASSOU' if not findings else 'CORRIGIR',metricas=metrics,total_verificacoes=len(checks)+len(findings),falhas=findings,verificados=checks,limites='Corpo 0,60 m, grade 0,10 m, folhas abertas. Não certifica acessibilidade ou segurança. Box tratado como piso transitável, a detalhar com fechamento retrátil; ensaio não inclui ferragens, vegetação ou obstáculos não modelados.')

if __name__=='__main__':
    failed=False
    for n in (5,6):
        p=ROOT/f'CASA-{n:02}';d=json.loads((p/'CONCEPCAO.json').read_text(encoding='utf8'));r=audit(d)
        (p/'AUDITORIA.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
        print(n,r['estado'],r['total_verificacoes'],'ensaios',len(r['falhas']),'falhas')
        for f in r['falhas']:print(' ',f)
        failed|=bool(r['falhas'])
    raise SystemExit(int(failed))
