"""Revisão adicional independente, sem alterar a distribuição aprovada.

Portas: todo o setor de giro versus móveis, paredes e outras folhas.
Janelas: volume envolvente de toda abertura de 0° ao ângulo limitado,
em 3D, versus paredes, lajes, coberturas, pilares e mobiliário do IGZ.
Contatos em dobradiças/marcos do próprio conjunto não são interferências.
"""
from pathlib import Path
import json,math,hashlib
from shapely.geometry import Polygon,box
from geometria import door_shape,wall_parts
ROOT=Path(__file__).resolve().parent
all_failures=[]
for n in (5,6):
    p=ROOT/f'CASA-{n:02}';d=json.loads((p/'CONCEPCAO.json').read_text(encoding='utf8'));elements=json.loads((p/'ELEMENTOS.json').read_text(encoding='utf8'));results=[];failures=[]
    def record(label,collisions,extra=None):
        item=dict(item=label,resultado='PASSOU' if not collisions else 'CORRIGIR',interferencias=collisions,detalhe=extra)
        results.append(item)
        if collisions:failures.append(item)
    for level in ('terreo','superior'):
        z=0 if level=='terreo' else 3.15
        openings=[o for o in d['aberturas'] if o['nivel']==level]
        for idx,o in enumerate(openings):
            label=f'{level} {o["a"]} → {o["b"]} ({o["tipo"]})'
            if o['tipo']=='giro':
                # Setor completo, removendo somente 3,5 cm do marco/folha nominal.
                sweep=door_shape(o,True).buffer(-.035)
                collisions=[]
                for m in d['moveis']:
                    if m['nivel']!=level or m['z']>=o['altura']:continue
                    overlap=sweep.intersection(box(*m['limites'])).area
                    if overlap>.003:collisions.append(dict(tipo='móvel',nome=m['nome'],ambiente=m['ambiente'],area=round(overlap,4)))
                for j,v in enumerate(openings):
                    if j<=idx or v['tipo'] not in ('giro','correr-vidro'):continue
                    other=door_shape(v,True) if v['tipo']=='giro' else door_shape(v)
                    overlap=sweep.intersection(other.buffer(-.018) if v['tipo']=='giro' else other).area
                    if overlap>.003:collisions.append(dict(tipo='outra folha / giros simultâneos',nome=v['a']+'/'+v['b'],area=round(overlap,4)))
                for v in wall_parts(d,level):
                    if v['z']>=o['altura'] or v['z']+v['altura']<=.03:continue
                    overlap=sweep.intersection(box(*v['limites'])).area
                    if overlap>.005:collisions.append(dict(tipo='parede',limites=list(v['limites']),area=round(overlap,4)))
                record(label,collisions,dict(angulo_ensaiado='setor inteiro 0–90°',limite='Folha nominal menos tolerância do marco; ferragens reais a especificar.'))
            elif o['tipo']=='janela':
                a=o['centro']-o['largura']/2+.015;b=o['centro']+o['largura']/2-.015;f=o['fixo'];h=o['altura'];projection=h*math.sin(math.radians(o['angulo']))
                direction=-1 if o['lado'] in ('left','top') else 1
                # Desconsidera os primeiros 8,5 cm dentro do marco/parede hospedeira.
                near=f+direction*.086;far=f+direction*projection
                if o['eixo']=='h':xy=box(a,min(near,far),b,max(near,far))
                else:xy=box(min(near,far),a,max(near,far),b)
                bottom=z+o['peitoril'];top=z+o['peitoril']+h
                collisions=[]
                for e in elements:
                    name=e['nome'];lo=e['min'];hi=e['max']
                    if name.startswith(('Vidro janela','Marco janela','Caimento')):continue
                    if min(top,hi[2])-max(bottom,lo[2])<.002:continue
                    intersection=xy.intersection(box(lo[0],lo[1],hi[0],hi[1])).area
                    # AABB da laje inteira não preenche seus vazios: a folha está externa ao envelope.
                    if intersection>.001:collisions.append(dict(tipo='peça do modelo',nome=name,area=round(intersection,4)))
                record(label,collisions,dict(angulo=o['angulo'],projecao_maxima=round(projection,3),sentido='para fora',envolvente_conservadora=True))
    # Nomes/sistemas explícitos: a correção não pode converter janela em folha interna.
    windows=[o for o in d['aberturas'] if o['tipo']=='janela'];assert windows and all(o['angulo']>0 and o['lado'] in ('left','right','top','bottom') for o in windows)
    report=dict(numero=n,data='2026-11-13',estado='PASSOU' if not failures else 'CORRIGIR',fonte_sha256=hashlib.sha256((p/'CONCEPCAO.json').read_bytes()).hexdigest(),total=len(results),janelas=len(windows),itens=results,falhas=failures,limites='Envoltórias geométricas do estudo, não especificação de produtos ou laudo. Não inclui ferragens, deformações, construção real, vegetação futura ou restrições não modeladas. Rotas com corpo e folhas abertas estão na AUDITORIA.json.')
    (p/'REVISAO-ESQUADRIAS-PUBLICACAO.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(n,report['estado'],len(results),'ensaios adicionais;',len(windows),'janelas externas;',len(failures),'conflitos')
    for f in failures:print(f)
    all_failures+=failures
raise SystemExit(bool(all_failures))
