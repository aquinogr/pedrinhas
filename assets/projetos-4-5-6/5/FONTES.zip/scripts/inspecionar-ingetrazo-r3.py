"""Abre somente as cópias R3 em aplicação isolada; não toca a sessão do usuário."""
import json,hashlib
from pathlib import Path
from PySide6.QtCore import QCoreApplication,QTimer
from PySide6.QtWidgets import QApplication
from views.main_window import MainWindow
ROOT=Path(__file__).resolve().parent/'PUBLICACAO-R3'
QCoreApplication.setOrganizationName('CodexPedrinhasInspecaoIsolada')
QCoreApplication.setApplicationName('Plantas05e06R3')
app=QApplication([]);window=MainWindow(defer_extensions=True);window.resize(1440,1000);window.move(-30000,-30000);window.show();pending=iter([5,6]);current=None
def load():
    global current
    current=next(pending,None)
    if current is None:app.quit();return
    folder=ROOT/f'CASA-{current:02}';ok=window.open_path(folder/'CASA-MOBILIADA.igz');print('ABERTURA R3',current,ok,flush=True)
    if not ok:app.exit(2);return
    window._on_zoom_extents();window.viewport.update();QTimer.singleShot(2500,capture)
def capture():
    folder=ROOT/f'CASA-{current:02}';ok=window.grab().save(str(folder/'INGETRAZO-R3-interface.png'))
    (folder/'QA-INTERFACE-R3.json').write_text(json.dumps(dict(abriu_interface=True,captura=ok,sha256=hashlib.sha256((folder/'CASA-MOBILIADA.igz').read_bytes()).hexdigest(),limite='Reabertura real da aplicação e captura; não certifica arquitetura.'),ensure_ascii=False,indent=2),encoding='utf8')
    print('CAPTURA R3',current,ok,flush=True);QTimer.singleShot(100,load)
QTimer.singleShot(500,load)
raise SystemExit(app.exec())
