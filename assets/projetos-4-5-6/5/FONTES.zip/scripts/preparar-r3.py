"""Cópia da distribuição aprovada; não sobrescreve a entrega R2."""
from pathlib import Path
import json,shutil,hashlib
from core.scene import Scene
from formats.igz import load_into,save_scene
from formats.gltf import save_glb
from core.mesh import Mesh
from core.group import Group
from PySide6.QtGui import QVector3D
from shapely.geometry import box
from shapely.ops import unary_union,triangulate
ROOT=Path(__file__).resolve().parent
for n in (5,6):
    old=ROOT/f'CASA-{n:02}';out=ROOT/'PUBLICACAO-R3'/f'CASA-{n:02}';out.mkdir(parents=True,exist_ok=True)
    manifest={}
    for name in ['CONCEPCAO.json','terreo.svg','superior.svg','PLANTAS-A3.pdf','AREAS.json','AUDITORIA.json','QA-GEOMETRIA-NATIVA.json','REVISAO-ESQUADRIAS-PUBLICACAO.json']:
        src=old/name;dst=out/name
        if dst.exists():assert dst.read_bytes()==src.read_bytes(),f'Não substituir revisão aprovada {dst}'
        else:shutil.copy2(src,dst)
        manifest[name]=hashlib.sha256(src.read_bytes()).hexdigest()
    (out/'BASE-APROVADA.json').write_text(json.dumps(dict(data='2026-11-13',autorizacao='Usuário aprovou distribuição, pediu revisão de esquadrias e publicação nos destinos 5/6.',arquivos=manifest),ensure_ascii=False,indent=2),encoding='utf8')
    scene=Scene();load_into(scene,old/'CASA.igz')
    scene.groups[:]=[g for g in scene.groups if not str(g.layer).startswith('Mobiliário')]
    # Juntas arquitetônicas, sem alterar áreas ou distribuição: panos param
    # na face dos pilares; pavimentos externos tornam-se uma união sem duplicação.
    scene.groups[:]=[g for g in scene.groups if not g.name.startswith(('Guarda varanda','Piso externo'))]
    corrections=[]
    def extrude(name,poly,z,h,color,layer):
        m=Mesh()
        for t in triangulate(poly):
            if not poly.covers(t):continue
            xy=list(t.exterior.coords)[:-1]
            for zz,pp in [(z,list(reversed(xy))),(z+h,xy)]:
                f=m.add_face([QVector3D(x,y,zz) for x,y in pp])
                if f:f.attrs['color']=color
        for p in list(poly.geoms) if hasattr(poly,'geoms') else [poly]:
            for ring in [p.exterior,*p.interiors]:
                xy=list(ring.coords)
                for (x,y),(X,Y) in zip(xy,xy[1:]):
                    f=m.add_face([QVector3D(x,y,z),QVector3D(X,Y,z),QVector3D(X,Y,z+h),QVector3D(x,y,z+h)])
                    if f:f.attrs['color']=color
        g=Group(m,name=name);g.layer=layer;scene.groups.append(g);corrections.append(g)
    for label,b in [('frontal',[1.8,5.1,10.2,5.2]),('esquerda',[1.6,5.3,1.7,7.275]),('direita',[10.3,5.3,10.4,7.275])]:extrude('Guarda varanda '+label,box(*b),3.15,1.1,(.83,.81,.71),'Superior')
    d=json.loads((old/'CONCEPCAO.json').read_text(encoding='utf8'))
    extrude('Piso externo unificado',unary_union([box(*b) for _,b in d['pisos_externos']]),-.12,.1,(.70,.65,.53),'Terreno')
    fix=Scene();fix.groups.extend(corrections);save_glb(fix,out/'CORRECOES-ARQUITETURA.glb')
    (out/'DETALHES-R3.json').write_text(json.dumps(dict(distribuicao_alterada=False,esquadrias_alteradas=False,guarda_varanda='Panos encerrados nos pilares, mantendo altura 1,10 m e proteção contínua.',pisos_externos='União das mesmas projeções aprovadas, sem faces duplicadas.'),ensure_ascii=False,indent=2),encoding='utf8')
    save_scene(scene,out/'ARQUITETURA.igz');save_glb(scene,out/'ARQUITETURA.glb')
    print(n,'Arquitetura copiada sem os móveis de estudo:',len(scene.groups),'grupos')
