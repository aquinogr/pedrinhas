"""Reaplica somente encontros corrigidos à composição já mobiliada."""
import bpy,sys,math
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent;n=int(sys.argv[sys.argv.index('--')+1]);out=ROOT/'PUBLICACAO-R3'/f'CASA-{n:02}'
bpy.ops.wm.open_mainfile(filepath=str(out/'CASA-MOBILIADA.blend'))
for ob in list(bpy.data.objects):
    if ob.name.startswith(('Guarda varanda','Piso externo')):bpy.data.objects.remove(ob,do_unlink=True)
before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(out/'CORRECOES-ARQUITETURA.glb'))
for ob in set(bpy.data.objects)-before:
    if ob.type!='MESH':continue
    material=bpy.data.materials['Piso areia'] if ob.name.startswith('Piso') else bpy.data.materials['Reboco marfim'];ob.data.materials.clear();ob.data.materials.append(material)
    mod=ob.modifiers.new('Aresta de acabamento','BEVEL');mod.width=.004;mod.segments=2
bpy.ops.object.select_all(action='DESELECT')
for ob in bpy.data.objects:
    if ob.type=='MESH' and not ob.name.startswith('Entorno'):ob.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(out/'CASA-MOBILIADA.glb'),export_format='GLB',use_selection=True,export_cameras=False,export_lights=False)
bpy.ops.object.select_all(action='DESELECT');bpy.ops.wm.save_as_mainfile(filepath=str(out/'CASA-MOBILIADA-JUNTAS.blend'))
s=bpy.context.scene;cam=s.camera
def render(name,pos,target,ortho=None):
    cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO' if ortho else 'PERSP';cam.data.lens=42
    if ortho:cam.data.ortho_scale=ortho
    s.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True);print('FINAL',n,name,flush=True)
render('render-fachada',(22,-16,13),(6,8.7,2.6))
render('render-lazer',(-10,17.2,11),(6,18.5,1.6)) if n==5 else render('render-lazer',(-9,38,13),(6,27.3,1.3))
hidden=[]
for ob in bpy.data.objects:
    if ob.type!='MESH':continue
    vv=[ob.matrix_world @ Vector(v) for v in ob.bound_box]
    if ob.name.startswith(('Cobertura','Caimento','Calha','Oitao')) or vv and min(v.z for v in vv)>=3-.001:ob.hide_render=True;hidden.append(ob)
render('render-terreo',(-12,-5,31),(6,17,0),43)
for ob in hidden:ob.hide_render=False
for ob in bpy.data.objects:
    if ob.type!='MESH':continue
    vv=[ob.matrix_world @ Vector(v) for v in ob.bound_box]
    if ob.name.startswith(('Cobertura','Caimento','Calha')) or vv and max(v.z for v in vv)<3.13:ob.hide_render=True
render('render-superior',(22,-4,25),(6,12.5,3.5),26)
