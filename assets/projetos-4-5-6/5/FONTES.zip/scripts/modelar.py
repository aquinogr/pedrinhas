"""IGZ editável de conferência, criado/reaberto com a biblioteca do IngeTrazo.

Geometria de estudo, nunca projeto executivo. Mobiliário em escala simplificado.
Fontes JSON são as mesmas das pranchas. Nenhum modelo publicado é modificado.
"""
import json,math,hashlib
from pathlib import Path
from PySide6.QtGui import QVector3D
from core.scene import Scene
from core.mesh import Mesh
from core.group import Group
from core.layers import Layer
from formats.igz import save_scene,load_into
from formats.gltf import save_glb
from geometria import wall_parts,door_shape,stair,slab
from shapely.ops import triangulate
ROOT=Path(__file__).resolve().parent
def make(d,dest):
    scene=Scene();records=[]
    for n in ['Terreno','Térreo','Superior','Cobertura','Escada','Piscina','Mobiliário térreo','Mobiliário superior','Estrutura proposta']:scene.layers.append(Layer(n))
    def mesh(name,pts,faces,color,layer):
        m=Mesh()
        for f in faces:
            face=m.add_face([QVector3D(*pts[i]) for i in f])
            if face:face.attrs['color']=color
        g=Group(m,name=name);g.layer=layer;scene.groups.append(g)
        records.append(dict(nome=name,camada=layer,min=[min(p[i] for p in pts) for i in range(3)],max=[max(p[i] for p in pts) for i in range(3)]))
    def prism(name,b,z,h,c,layer):
        x,y,X,Y=b
        if min(X-x,Y-y,h)<.00001:return
        p=[(x,y,z),(X,y,z),(X,Y,z),(x,Y,z),(x,y,z+h),(X,y,z+h),(X,Y,z+h),(x,Y,z+h)]
        mesh(name,p,[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],c,layer)
    def rail(name,x,y,z,X,Y,Z,layer):
        # Corrimão de seção quadrada: prisma orientado ao eixo do lance.
        v=QVector3D(X-x,Y-y,Z-z).normalized();side=QVector3D.crossProduct(v,QVector3D(0,0,1)).normalized();up=QVector3D.crossProduct(side,v).normalized();pts=[]
        for q in (QVector3D(x,y,z),QVector3D(X,Y,Z)):
            for a,b in ((-1,-1),(1,-1),(1,1),(-1,1)):
                p=q+side*a*.025+up*b*.025;pts.append((p.x(),p.y(),p.z()))
        mesh(name,pts,[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],(.20,.24,.20),layer)
    def floor_mesh(level,z,layer):
        poly=slab(d,level);pts=[];faces=[]
        for tri in triangulate(poly):
            if not poly.covers(tri):continue
            xy=list(tri.exterior.coords)[:-1];idx=len(pts);pts.extend((x,y,z) for x,y in xy);faces.append(tuple(range(idx,idx+3)))
            idx=len(pts);pts.extend((x,y,z-.15) for x,y in reversed(xy));faces.append(tuple(range(idx,idx+3)))
        polys=list(poly.geoms) if hasattr(poly,'geoms') else [poly]
        for p in polys:
            for ring in [p.exterior,*p.interiors]:
                xy=list(ring.coords)
                for (x,y),(X,Y) in zip(xy,xy[1:]):
                    i=len(pts);pts.extend([(x,y,z-.15),(X,Y,z-.15),(X,Y,z),(x,y,z)]);faces.append((i,i+1,i+2,i+3))
        mesh('Piso laje '+level,pts,faces,(.79,.73,.62),layer)
    px,py,pX,pY=d['piscina']
    for b in [(0,0,12,py-.15),(0,pY+.15,12,35),(0,py-.15,px-.15,pY+.15),(pX+.15,py-.15,12,pY+.15)]:prism('Terreno natural',b,-.3,.18,(.48,.59,.35),'Terreno')
    for _,b in d['pisos_externos']:prism('Piso externo',b,-.12,.1,(.70,.65,.53),'Terreno')
    for b in d['vagas']:prism('Faixa de estacionamento',b,-.12,.08,(.71,.70,.62),'Terreno')
    prism('Piscina fundo',(px-.15,py-.15,pX+.15,pY+.15),-1.42,.12,(.38,.67,.69),'Piscina')
    for b in [(px-.15,py-.15,px,pY+.15),(pX,py-.15,pX+.15,pY+.15),(px,py-.15,pX,py),(px,pY,pX,pY+.15)]:prism('Piscina parede',b,-1.3,1.25,(.41,.70,.71),'Piscina')
    prism('Piscina agua',(px,py,pX,pY),-.10,.012,(.18,.59,.63),'Piscina')
    for level,z,layer in [('terreo',0,'Térreo'),('superior',3.15,'Superior')]:
        floor_mesh(level,z,layer)
        for w in wall_parts(d,level):prism('Parede '+level,w['limites'],z+w['z'],w['altura'],(.89,.86,.77),layer)
        for o in d['aberturas']:
            if o['nivel']!=level:continue
            a=o['centro']-o['largura']/2;b=o['centro']+o['largura']/2;f=o['fixo']
            if o['tipo']=='janela':
                projection=o['altura']*math.sin(math.radians(o['angulo']))*(-1 if o['lado'] in ('left','top') else 1)
                bot=z+o['peitoril']+o['altura']*(1-math.cos(math.radians(o['angulo'])));top=z+o['peitoril']+o['altura']
                pts=[(a,f,top),(b,f,top),(b,f+projection,bot),(a,f+projection,bot)] if o['eixo']=='h' else [(f,a,top),(f,b,top),(f+projection,b,bot),(f+projection,a,bot)]
                mesh('Vidro janela externa '+o['a'],pts,[(0,1,2,3)],(.44,.65,.66),layer)
                if o['eixo']=='h':prism('Marco janela',(a-.025,f-.075,a+.025,f+.075),z+o['peitoril'],o['altura'],(.22,.28,.23),layer);prism('Marco janela',(b-.025,f-.075,b+.025,f+.075),z+o['peitoril'],o['altura'],(.22,.28,.23),layer)
                else:prism('Marco janela',(f-.075,a-.025,f+.075,a+.025),z+o['peitoril'],o['altura'],(.22,.28,.23),layer);prism('Marco janela',(f-.075,b-.025,f+.075,b+.025),z+o['peitoril'],o['altura'],(.22,.28,.23),layer)
            elif o['tipo'] in ('giro','correr-vidro'):
                shape=door_shape(o);prism('Vidro porta' if o['tipo']=='correr-vidro' else 'Porta aberta '+o['a'],shape.bounds,z+.025,o['altura']-.05,(.45,.62,.62) if o['tipo']=='correr-vidro' else (.49,.32,.18),layer)
            elif o['tipo']=='correr':
                # Folha integralmente recolhida em cassete, identificada pela fonte e pelas pranchas.
                pass
    ss,landing=stair(d);s=d['escada'];x=s['x']+.075;y=s['y'];run=2.24
    for st in ss:
        # Lances maciços por degrau são volumes de estudo; sobreposição interna não é volume executivo.
        base=0 if 'inferior' in st['nome'] else 1.40
        prism('Degrau '+st['nome'],st['limites'],base,st['z']-base,(.73,.62,.46),'Escada')
    prism('Patamar escada',landing,1.395,.18,(.73,.62,.46),'Escada')
    prism('Separacao lances',(x+1.2,y,x+1.45,y+run),0,4.25,(.87,.84,.76),'Escada')
    prism('Guarda chegada escada',(x,y-.035,x+1.45,y+.035),3.15,1.10,(.84,.83,.74),'Superior')
    for xx in (x+.06,x+1.14):rail('Corrimao inferior',xx,y,1.095,xx,y+run,2.495,'Escada')
    for xx in (x+1.51,x+2.59):rail('Corrimao superior',xx,y+run,2.67,xx,y,4.07,'Escada')
    for xx in (x+.06,x+2.59):rail('Corrimao patamar',xx,y+run,2.495,xx,landing[3]-.06,2.495,'Escada')
    rail('Corrimao retorno',x+.06,landing[3]-.06,2.495,x+2.59,landing[3]-.06,2.495,'Escada')
    for xx in (x+.06,x+1.14):rail('Prolongamento inferior',xx,y-.30,1.095,xx,y,1.095,'Térreo')
    for xx in (x+1.51,x+2.59):rail('Prolongamento superior',xx,y,4.07,xx,y-.30,4.07,'Superior')
    for r in d['coberturas']:
        b=r['limites'];z=r['z']
        if r['tipo']=='plana':
            prism('Cobertura '+r['nome'],b,z,.18,(.79,.77,.66),'Cobertura')
            # Platibanda baixa com calha; queda ilustrativa de 1%, a dimensionar.
            xx,yy,XX,YY=b
            pts=[(xx,yy,z+.18),(XX,yy,z+.18),(XX,YY,z+.18),(xx,YY,z+.18),(xx,yy,z+.22+(YY-yy)*.01),(XX,yy,z+.22+(YY-yy)*.01),(XX,YY,z+.22),(xx,YY,z+.22)]
            mesh('Caimento '+r['nome'],pts,[(4,5,6,7),(0,1,5,4),(2,3,7,6)],(.85,.82,.74),'Cobertura')
            prism('Calha '+r['nome'],(xx,YY-.1,XX,YY),z+.19,.08,(.26,.33,.28),'Cobertura')
        else:
            xx,yy,XX,YY=b;mid=(xx+XX)/2;high=z+r['elevacao'];pts=[(xx,yy,z),(mid,yy,high),(XX,yy,z),(xx,YY,z),(mid,YY,high),(XX,YY,z),(xx,yy,z+.12),(mid,yy,high+.12),(XX,yy,z+.12),(xx,YY,z+.12),(mid,YY,high+.12),(XX,YY,z+.12)]
            mesh('Cobertura duas aguas',pts,[(6,7,10,9),(7,8,11,10),(0,1,7,6),(1,2,8,7),(3,9,10,4),(4,10,11,5),(0,6,9,3),(2,5,11,8)],(.63,.30,.15),'Cobertura')
    for p in d['pilares']:
        w=p['largura']/2;prism('Pilar reservado',(p['x']-w,p['y']-w,p['x']+w,p['y']+w),0,p['z'],(.85,.80,.69),'Estrutura proposta')
    for b in [(1.65,5.10,10.35,5.20),(1.60,5.20,1.70,7.35),(10.30,5.20,10.40,7.35)]:prism('Guarda varanda',b,3.15,1.10,(.83,.81,.71),'Superior')
    for m in d['moveis']:
        lev=m['nivel'];z=(0 if lev=='terreo' else 3.15)+m['z'];lay='Mobiliário térreo' if lev=='terreo' else 'Mobiliário superior';b=m['limites'];name=m['nome']
        c=(.60,.42,.24) if 'Armário' in name or 'Mesa' in name else (.92,.90,.82) if 'Cama' in name or 'Bacia' in name or 'Lavatório' in name else (.37,.47,.38)
        if 'Cama' in name:
            prism('Estrado '+m['ambiente'],b,z,.24,(.47,.31,.17),lay);prism('Colchao '+m['ambiente'],b,z+.24,.28,(.91,.87,.77),lay)
            bx,by,bX,bY=b
            py,pY=(bY-.48,bY-.1) if m['rotacao']==180 else (by+.1,by+.48)
            for a,B in [(bx+.1,(bx+bX)/2-.03),((bx+bX)/2+.03,bX-.1)]:prism('Travesseiro',(a,py,B,pY),z+.52,.10,(.98,.96,.90),lay)
        elif m['asset']=='wooden_table_02':
            bx,by,bX,bY=b;prism(name+' tampo',b,z+.70,.06,c,lay)
            for xx in (bx+.08,bX-.13):
                for yy in (by+.08,bY-.13):prism(name+' pe',(xx,yy,xx+.05,yy+.05),z,.70,c,lay)
        else:prism(name,b,z,m['altura'],c,lay)
    igz=dest/'CASA.igz';save_scene(scene,igz);reopen=Scene();load_into(reopen,igz);assert len(reopen.groups)==len(scene.groups)
    save_glb(reopen,dest/'CASA.glb')
    (dest/'ELEMENTOS.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8')
    (dest/'QA-NATIVO.json').write_text(json.dumps(dict(abriu_biblioteca=True,grupos=len(reopen.groups),sha256=hashlib.sha256(igz.read_bytes()).hexdigest(),alcance='Reabertura pela biblioteca; ver QA da interface separadamente.'),ensure_ascii=False,indent=2),encoding='utf8')
    print('IGZ/GLB',d['numero'],len(reopen.groups),'grupos')
if __name__=='__main__':
    for n in (5,6):
        folder=ROOT/f'CASA-{n:02}';make(json.loads((folder/'CONCEPCAO.json').read_text(encoding='utf8')),folder)
