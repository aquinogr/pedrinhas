"""Conversão da fonte para elementos; sem dependências de renderização."""
import math
from shapely.geometry import box,LineString,Polygon
from shapely.ops import unary_union

def rect(v):return box(*v)
def slab(d,level):
    poly=unary_union([rect(r['limites']) for r in d['ambientes'] if r['nivel']==level]).buffer(.075,join_style=2)
    if level=='superior':poly=poly.difference(rect(next(r['limites'] for r in d['ambientes'] if r['nivel']==level and r['id']=='escada')))
    return poly
def wall_lines(d,level):
    result={}
    for r in d['ambientes']:
        if r['nivel']!=level or r['tipo']=='aberto':continue
        x,y,X,Y=r['limites']
        for axis,f,a,b in [('h',y,x,X),('h',Y,x,X),('v',x,y,Y),('v',X,y,Y)]:result.setdefault((axis,round(f,5)),[]).append((a,b))
    merged=[]
    for (axis,f),spans in result.items():
        spans=sorted(spans);runs=[]
        for a,b in spans:
            if runs and a<=runs[-1][1]+1e-5:runs[-1]=(runs[-1][0],max(b,runs[-1][1]))
            else:runs.append((a,b))
        merged.extend((axis,f,a,b) for a,b in runs)
    return merged

def wall_parts(d,level):
    result=[]
    for axis,f,a,b in wall_lines(d,level):
        cuts=sorted([o for o in d['aberturas'] if o['nivel']==level and o['eixo']==axis and abs(o['fixo']-f)<1e-4 and o['centro']-o['largura']/2>=a-1e-4 and o['centro']+o['largura']/2<=b+1e-4],key=lambda o:o['centro'])
        current=a
        def add(start,end,low,high):
            if end-start<1e-5 or high-low<1e-5:return
            bounds=(start,f-.075,end,f+.075) if axis=='h' else (f-.075,start,f+.075,end)
            result.append(dict(limites=bounds,z=low,altura=high-low))
        for o in cuts:
            A=o['centro']-o['largura']/2;B=o['centro']+o['largura']/2
            if A<current-.001:raise ValueError(('Vãos sobrepostos',axis,f,o))
            add(current,A,0,3);add(A,B,0,o['peitoril']);add(A,B,o['peitoril']+o['altura'],3);current=B
        add(current,b,0,3)
    return result

def door_shape(o,sweep=False):
    a=o['centro']-o['largura']/2;b=o['centro']+o['largura']/2;f=o['fixo'];w=o['largura']
    if o['tipo']=='giro':
        h=a if o['dobradica']=='inicio' else b;s=1 if h==a else -1
        P=(h,f) if o['eixo']=='h' else (f,h)
        closed=(h+s*w,f) if o['eixo']=='h' else (f,h+s*w)
        opened=(h,f+o['direcao']*w) if o['eixo']=='h' else (f+o['direcao']*w,h)
        if sweep:
            return Polygon([P]+[(h+s*w*math.cos(t),f+o['direcao']*w*math.sin(t)) if o['eixo']=='h' else (f+o['direcao']*w*math.sin(t),h+s*w*math.cos(t)) for t in [i*math.pi/48 for i in range(25)]])
        return LineString([P,opened]).buffer(.018,cap_style=2)
    if o['tipo']=='correr-vidro':
        # Duas folhas, passagem efetiva aproximada igual a metade do vão menos marcos.
        return rect((o['centro'],f-.025,b,f+.025) if o['eixo']=='h' else (f-.025,o['centro'],f+.025,b))
    return Polygon()

def opening_point(o):
    c=o['centro']-o['largura']/4 if o['tipo']=='correr-vidro' else o['centro']
    return (c,o['fixo']) if o['eixo']=='h' else (o['fixo'],c)

def stair(d):
    s=d['escada'];x,y=s['x']+.075,s['y'];width=s['largura_lance'];split=.25;p=s['piso'];e=s['espelho'];run=8*p
    steps=[]
    for i in range(8):
        steps.append(dict(nome=f'Lance inferior {i+1}',limites=[x,y+i*p,x+width,y+(i+1)*p],z=e*(i+1)))
        steps.append(dict(nome=f'Lance superior {i+1}',limites=[x+width+split,y+run-(i+1)*p,x+2*width+split,y+run-i*p],z=e*(10+i)))
    return steps,[x,y+run,x+2*width+split,s['y']+s['h']-.075]

def measures(d):
    footprint={}
    for level in ('terreo','superior'):
        rooms=[rect(r['limites']) for r in d['ambientes'] if r['nivel']==level]
        # Buffer das paredes externas; união evita duplicação de superfícies.
        footprint[level]=unary_union(rooms).buffer(.075,join_style=2)
    columns=[box(p['x']-.1,p['y']-.1,p['x']+.1,p['y']+.1) for p in d['pilares']]
    covered=unary_union([rect(r['limites']) for r in d['coberturas']]+list(footprint.values())+columns)
    parking=unary_union([rect(r) for r in d['vagas']])
    paved=unary_union([rect(b) for _,b in d['pisos_externos']])
    pool=rect(d['piscina']).buffer(.15,join_style=2)
    nonnatural=unary_union([covered,parking,paved,pool]).intersection(box(0,0,12,35))
    upper_area=footprint['superior'].area-rect(next(r['limites'] for r in d['ambientes'] if r['nivel']=='superior' and r['id']=='escada')).area
    return dict(terreno=420,terreo=round(footprint['terreo'].area,2),superior=round(upper_area,2),construida=round(footprint['terreo'].area+upper_area,2),projecao=round(covered.area,2),solo_natural=round(420-nonnatural.area,2),solo_natural_percentual=round((420-nonnatural.area)/4.2,2),piscina=round(rect(d['piscina']).area,2),criterio='União de projeções, coberturas, piscina/bordas, pavimentação e vagas inteiras; não conta grama das vagas como natural.')
