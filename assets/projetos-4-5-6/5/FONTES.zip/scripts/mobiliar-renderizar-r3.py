"""Acervo licenciado nos envelopes aprovados; renders derivados do modelo.

Executar com Blender. Originais R2 e projetos publicados ficam intocados.
"""
import bpy,sys,math,json
from pathlib import Path
from mathutils import Matrix,Vector
ROOT=Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
n=int(args[0]);out=ROOT/'PUBLICACAO-R3'/f'CASA-{n:02}'
d=json.loads((out/'CONCEPCAO.json').read_text(encoding='utf8'))
OLD=ROOT.parent/'PROJETO-04-ATRIO'
assets=ROOT.parent/'SITE-ISOLADO-BASE-f51f2c9/assets/revisadas/modelos'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(out/'ARQUITETURA.glb'))
def mat(name,color,rough=.7,metal=0,transmission=0,noise=False):
    m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=(*color,1);b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*color,1);b.inputs['Roughness'].default_value=rough;b.inputs['Metallic'].default_value=metal
    if transmission:b.inputs['Transmission Weight'].default_value=transmission;b.inputs['IOR'].default_value=1.333 if 'Água' in name else 1.45
    if noise:
        nod=m.node_tree.nodes.new('ShaderNodeTexNoise');nod.inputs['Scale'].default_value=110;nod.inputs['Detail'].default_value=2
        bump=m.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.16;bump.inputs['Distance'].default_value=.008;m.node_tree.links.new(nod.outputs['Fac'],bump.inputs['Height']);m.node_tree.links.new(bump.outputs['Normal'],b.inputs['Normal'])
    return m
wall=mat('Reboco marfim',(.70,.66,.56),noise=True);stone=mat('Pedra clara / textura de apresentação',(.42,.37,.28),noise=True);roof=mat('Cobertura clara',(.65,.63,.55),noise=True);tile=mat('Telha cerâmica',(.34,.105,.045),noise=True);wood=mat('Madeira natural',(.27,.145,.065),noise=True);floor=mat('Piso areia',(.48,.43,.33),.65,noise=True);grass=mat('Jardim',(.19,.27,.075),noise=True);glass=mat('Vidro',(.55,.70,.73),.10,transmission=.62);metal=mat('Alumínio grafite',(.08,.105,.09),.32,.65);water=mat('Água piscina',(.045,.24,.29),.075,transmission=.4,noise=True);ceramic=mat('Louça branca',(.85,.86,.81),.25);fabric=mat('Linho cru',(.75,.72,.63),noise=True);screen=mat('Tela TV',(.009,.014,.018),.25)
architecture=list(bpy.data.objects)
for ob in architecture:
    if ob.type!='MESH':continue
    name=ob.name
    material=glass if name.startswith('Vidro') else metal if name.startswith(('Marco','Corrimao','Prolongamento','Calha')) else water if name.startswith('Piscina agua') else grass if name.startswith('Terreno') else tile if name.startswith('Cobertura duas') else roof if name.startswith(('Cobertura','Caimento')) else floor if name.startswith(('Piso','Faixa','Degrau','Patamar')) else wood if name.startswith('Porta aberta') else wall
    if n==6 and name.startswith('Parede'):
        vv=[ob.matrix_world @ v.co for v in ob.data.vertices]
        if vv and max(p.y for p in vv)<5.24 and max(p.z for p in vv)<3.01:material=stone
    ob.data.materials.clear();ob.data.materials.append(material)
    # Bevel apenas de acabamento, dentro do volume original.
    if not name.startswith(('Vidro','Terreno','Piscina agua','Piso laje')):
        mod=ob.modifiers.new('Aresta de acabamento','BEVEL');mod.width=.004;mod.segments=2
def mark(ob,level):ob['complemento']='superior' if level=='superior' else 'veiculos' if level=='veiculos' else 'terreo'
def cube(name,b,z,h,material,level='terreo',bevel=.007):
    x,y,X,Y=b;bpy.ops.mesh.primitive_cube_add(size=1,location=((x+X)/2,(y+Y)/2,z+h/2));ob=bpy.context.object;ob.name=name;ob.dimensions=(X-x,Y-y,h);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);ob.data.materials.append(material);mark(ob,level)
    if bevel:
        mod=ob.modifiers.new('Arestas arredondadas','BEVEL');mod.width=min(bevel,min(X-x,Y-y,h)/5);mod.segments=3
    return ob
def ellipsoid(name,b,z,h,material,level):
    x,y,X,Y=b;bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,location=((x+X)/2,(y+Y)/2,z+h/2));ob=bpy.context.object;ob.name=name;ob.dimensions=(X-x,Y-y,h);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);ob.data.materials.append(material);mark(ob,level)
    for p in ob.data.polygons:p.use_smooth=True
prototypes={}
def proto(name):
    if name in prototypes:return prototypes[name]
    before=set(bpy.data.objects)
    if name in ('carSegmentA','suv2'):bpy.ops.wm.obj_import(filepath=str(OLD/'ACERVO-SCOPIA-CONVERTIDO'/(name+'.obj')))
    else:bpy.ops.import_scene.gltf(filepath=str(assets/(name+'.gltf')))
    objs=[o for o in bpy.data.objects if o not in before and o.type=='MESH'];bpy.context.view_layer.update();vv=[o.matrix_world @ Vector(v) for o in objs for v in o.bound_box]
    lo=Vector([min(v[i] for v in vv) for i in range(3)]);hi=Vector([max(v[i] for v in vv) for i in range(3)])
    for o in objs:o.hide_render=True;o.hide_viewport=True
    prototypes[name]=(objs,lo,hi);return prototypes[name]
def place(name,label,b,z,h,level,angle=0):
    objs,lo,hi=proto(name);size=hi-lo;x,y,X,Y=b
    if name in ('carSegmentA','suv2'):
        factor=min((X-x)/size.x,(Y-y)/size.y,h/size.z);S=Matrix.Diagonal(Vector((factor,factor,factor,1)))
    else:S=Matrix.Diagonal(Vector(((X-x)/size.x,(Y-y)/size.y,h/size.z,1)))
    T=Matrix.Translation(Vector(((x+X)/2,(y+Y)/2,z))) @ Matrix.Rotation(math.radians(angle),4,'Z') @ S @ Matrix.Translation(Vector((-(lo.x+hi.x)/2,-(lo.y+hi.y)/2,-lo.z)))
    for original in objs:
        ob=original.copy();ob.data=original.data;ob.name=label;ob.parent=None;bpy.context.scene.collection.objects.link(ob);ob.matrix_world=T @ original.matrix_world;ob.hide_render=False;ob.hide_viewport=False;mark(ob,level)
for m in d['moveis']:
    level=m['nivel'];z=(3.15 if level=='superior' else 0)+m['z'];b=m['limites'];x,y,X,Y=b;name=m['nome'];label=name+' / '+m['ambiente'];h=m['altura']
    if m['asset']:
        place(m['asset'],label,b,z,1.0 if 'Cama' in name else h,level,m['rotacao'])
        if 'Cama' in name:
            cube('Colchão / '+m['ambiente'],b,z+.24,.22,fabric,level,.035)
            by,bY=(Y-.49,Y-.10) if m['rotacao']==180 else (y+.1,y+.49)
            for xx,XX in ((x+.1,(x+X)/2-.03),((x+X)/2+.03,X-.1)):cube('Travesseiro / '+m['ambiente'],(xx,by,XX,bY),z+.46,.12,fabric,level,.045)
    elif name.startswith('Box'):
        cube(label,b,z+.005,.025,floor,level,.002)
    elif name=='Bacia sanitária':
        ellipsoid(label,b,z,.42,ceramic,level)
        # Cisterna dentro do mesmo envelope horizontal; acabamento ilustrativo.
        right=(x+X)/2>6
        tank=(X-.16,y+.015,X,Y-.015) if right else (x,y+.015,x+.16,Y-.015)
        cube('Cisterna / '+m['ambiente'],tank,z+.33,.43,ceramic,level,.015)
    elif name=='Lavatório':
        cube('Gabinete / '+m['ambiente'],b,z-.55,.55,wood,level)
        cube('Bancada / '+m['ambiente'],b,z,.045,stone,level)
        ellipsoid('Cuba / '+m['ambiente'],(x+.05,y+.05,X-.05,Y-.05),z+.045,.10,ceramic,level)
    elif name=='TV / rack':
        cube('Rack',b,0,.43,wood,level)
        cy=y+.05 if n==5 else Y-.05;cx=(x+X)/2
        cube('TV',(cx-.70,cy-.025,cx+.70,cy+.025),.60,.79,screen,level)
    elif name=='Geladeira':
        cube(label,b,z,h,metal,level,.025)
        cube('Puxador geladeira',(x+.06,y-.012,x+.10,y+.02),z+.78,.65,metal,level,.005)
    else:
        cube(label,b,z,h,wood if 'Armário' in name else stone,level)
        if 'Bancada' in name or 'bancada' in name or 'churrasqueira' in name.lower():
            cube('Tampo '+label,(x,y,X,Y),z+h-.035,.035,stone,level,.003)
            if m['ambiente']=='cozinha':
                cube('Cooktop',(x+.08,y+.12,X-.08,y+.62),z+h,.018,screen,level,.003)
                cube('Cuba cozinha',(x+.08,y+.95,X-.08,min(Y-.07,y+1.55)),z+h,.02,metal,level,.008)
            elif m['ambiente']=='apoio':
                cube('Churrasqueira eletrica / grelha',(x+.03,y+.08,min(x+.50,X-.60),Y-.08),z+h,.03,screen,level,.004)
                cube('Cuba apoio',(X-.54,y+.08,X-.04,Y-.08),z+h,.025,metal,level,.008)
        if 'Armário' in name:
            for t in (.33,.66):
                xx=x+(X-x)*t;cube('Friso armário',(xx-.005,y-.001,xx+.005,y+.01),z+.06,h-.12,metal,level,.001)
for i,b in enumerate(d['vagas']):
    x,y,X,Y=b;cx=(x+X)/2;place('carSegmentA' if i==1 else 'suv2',f'Veículo Scopia {i+1}',(cx-.875,.20,cx+.875,4.30),-.08,1.55,'veiculos')
for objs,_,_ in prototypes.values():
    for ob in objs:bpy.data.objects.remove(ob,do_unlink=True)
bpy.context.view_layer.update()
envelopes=[]
for ob in bpy.data.objects:
    if ob.type!='MESH' or not ob.get('complemento'):continue
    vv=[ob.matrix_world @ Vector(v) for v in ob.bound_box]
    envelopes.append(dict(nome=ob.name,camada=ob['complemento'],min=[min(v[i] for v in vv) for i in range(3)],max=[max(v[i] for v in vv) for i in range(3)]))
(out/'ENVELOPES-MOBILIARIO-R3.json').write_text(json.dumps(envelopes,ensure_ascii=False,indent=2),encoding='utf8')
# Arremate do oitão visível da Casa 6, fora do pavimento superior, sem alterar ambientes.
if n==6:
    x0,x1,y=1.575,4.375,19.325;z0=3.;slope=1.3/4.425;h1=(x1-x0)*slope
    verts=[(x0,y,z0),(x1,y,z0),(x1,y,z0+h1),(x0,y+.10,z0),(x1,y+.10,z0),(x1,y+.10,z0+h1)]
    me=bpy.data.meshes.new('Oitao de fechamento');me.from_pydata(verts,[],[(0,2,1),(3,4,5),(0,1,4,3),(1,2,5,4),(2,0,3,5)]);ob=bpy.data.objects.new('Oitao frontal do pavilhao',me);bpy.context.scene.collection.objects.link(ob);ob.data.materials.append(wall);mark(ob,'terreo')
# Complementos simplificados e portáveis para o IGZ; originais permanecem no GLB de apresentação.
for kind in ('terreo','superior','veiculos'):
    bpy.ops.object.select_all(action='DESELECT');copies=[]
    for ob in list(bpy.data.objects):
        if ob.type!='MESH' or ob.get('complemento')!=kind:continue
        c=ob.copy();c.data=ob.data.copy();bpy.context.scene.collection.objects.link(c);copies.append(c);bpy.context.view_layer.objects.active=c;c.select_set(True)
        if len(c.data.polygons)>1500:
            mod=c.modifiers.new('Simplificação IGZ','DECIMATE');mod.ratio=.25;bpy.ops.object.modifier_apply(modifier=mod.name)
        c.select_set(False)
    for c in copies:c.select_set(True)
    bpy.ops.export_scene.gltf(filepath=str(out/f'COMPLEMENTO-{kind}.glb'),export_format='GLB',use_selection=True,export_cameras=False,export_lights=False)
    for c in copies:bpy.data.objects.remove(c,do_unlink=True)
bpy.ops.object.select_all(action='DESELECT');bpy.ops.export_scene.gltf(filepath=str(out/'CASA-MOBILIADA.glb'),export_format='GLB',export_cameras=False,export_lights=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True;scene.render.threads_mode='FIXED';scene.render.threads=4
scene.render.resolution_x=1800;scene.render.resolution_y=1200;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.68,.76,.88,1);scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.45
bpy.ops.object.light_add(type='SUN',location=(-12,-15,25));sun=bpy.context.object;sun.name='Sol';sun.data.energy=3;sun.data.angle=math.radians(8);sun.rotation_euler=(math.radians(28),math.radians(-22),math.radians(-35))
for x,y,z,power,size in [(-7,8,15,1600,10),(18,24,15,1300,10)]:bpy.ops.object.light_add(type='AREA',location=(x,y,z));ob=bpy.context.object;ob.data.energy=power;ob.data.shape='DISK';ob.data.size=size
bpy.ops.mesh.primitive_plane_add(size=200,location=(6,17.5,-.305));bg=bpy.context.object;bg.name='Entorno ilustrativo fora do lote';bg.data.materials.append(mat('Solo externo',(.33,.29,.20),noise=True))
bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.lens=42;scene.camera=cam
def camera(pos,target,ortho=None):
    cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO' if ortho else 'PERSP'
    if ortho:cam.data.ortho_scale=ortho
def render(name,pos,target,ortho=None):
    camera(pos,target,ortho);scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True);print('RENDER CONCLUÍDO',n,name,flush=True)
bpy.ops.wm.save_as_mainfile(filepath=str(out/'CASA-MOBILIADA.blend'))
render('render-fachada',(22,-16,13),(6,8.7,2.6))
if n==5:render('render-lazer',(-10,17.2,11),(6,18.5,1.6))
else:render('render-lazer',(-9,38,13),(6,27.3,1.3))
# Vistas abertas, sem remover/alterar arquitetura de origem.
hidden=[]
for ob in bpy.data.objects:
    if ob.type!='MESH':continue
    vv=[ob.matrix_world @ Vector(v) for v in ob.bound_box]
    if ob.name.startswith(('Cobertura','Caimento','Calha','Oitao')) or vv and min(v.z for v in vv)>=3.0-.001:ob.hide_render=True;hidden.append(ob)
render('render-terreo',(-12,-5,31),(6,17,0),43)
for ob in hidden:ob.hide_render=False
for ob in bpy.data.objects:
    if ob.type!='MESH':continue
    vv=[ob.matrix_world @ Vector(v) for v in ob.bound_box]
    if ob.name.startswith(('Cobertura','Caimento','Calha')) or vv and max(v.z for v in vv)<3.13:ob.hide_render=True
render('render-superior',(22,-4,25),(6,12.5,3.5),26)
print('CASA',n,'RENDERS FINALIZADOS',flush=True)
