"""Fonte autoral de duas alternativas; metros, rua Y=0, Z vertical.

Os .json gerados centralizam paredes, aberturas, móveis, percursos e coberturas.
Não altera os esboços originais, a casa 4 ou checkouts de publicação.
"""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def proposal(n):
    d=dict(numero=n,nome='Jardim entre Pavilhões' if n==5 else 'Duas Varandas',
        revisao='R2',status='ESTUDO_PRELIMINAR_LOCAL_PARA_APROVACAO',
        lote=dict(largura=12,profundidade=35,frente_azimute=115),
        paredes=.15,pe_direito=3.0,entre_pisos=3.15,
        premissas=dict(frente=5,laterais=1.5,fundos=1.5,solo_natural=.30,zona='Não confirmada'),
        ambientes=[],aberturas=[],moveis=[],coberturas=[],pilares=[],pisos_externos=[],rotas=[],
        decisoes=[],limites=['Estudo, não projeto executivo ou aprovação de obra.',
            'Recuos do briefing são condicionais à zona cadastral e ao condomínio.',
            'Cassete de portas de correr, impermeabilização, acústica, estrutura e instalações a dimensionar.',
            'Rotas são ensaios de corpo de 0,60 m; não certificam acessibilidade.',
            'Orientação e vento informados pelo usuário; não houve simulação térmica.'])
    def room(level,id,label,bounds,kind='fechado'):
        d['ambientes'].append(dict(nivel=level,id=id,nome=label,limites=list(bounds),tipo=kind))
    r=lambda *a,**k:room('terreo',*a,**k)
    u=lambda *a,**k:room('superior',*a,**k)
    if n==5:
        r('estar','Estar / entrada',(1.65,5.15,7.55,9.40))
        r('entrada','Alpendre de entrada',(7.55,5.15,10.35,10.60),'aberto')
        r('cozinha','Cozinha integrada',(1.65,9.40,7.55,14.15))
        r('hall-escada','Hall da escada',(7.55,10.60,10.35,11.80))
        r('escada','Escada em U',(7.55,11.80,10.35,15.39),'escada')
        r('conexao','Ligação coberta',(5.10,14.15,7.55,15.39),'aberto')
        r('quiosque','Gourmet / mesa 8',(5.10,15.39,10.35,19.65),'aberto')
        r('apoio','Churrasqueira / apoio',(6.80,19.65,8.35,21.80))
        r('lavabo','Lavabo piscina',(8.35,19.65,10.35,21.80))
        r('passagem','Passagem seca',(5.35,19.65,6.80,21.80),'aberto')
        rear=21.80
        r('q1','Quarto 1',(1.65,rear,5.35,25.60))
        r('b1','Banho reversível 1',(1.65,25.60,3.65,27.80))
        r('v1','Vestíbulo 1',(3.65,25.60,5.35,27.80))
        r('q2','Quarto 2',(6.65,rear,10.35,25.60))
        r('v2','Vestíbulo 2',(6.65,25.60,8.35,27.80))
        r('b2','Banho reversível 2',(8.35,25.60,10.35,27.80))
        r('q3','Quarto 3 compacto',(1.65,27.80,5.35,31.225))
        r('b3','Banho reversível 3',(1.65,31.225,3.65,33.425))
        r('v3','Vestíbulo 3',(3.65,31.225,5.35,33.425))
        r('circulacao','Galeria dos quartos',(5.35,rear,6.65,33.425))
        r('lavanderia','Lavanderia',(6.65,27.80,8.95,30.20))
        r('deposito','Depósito',(8.95,27.80,10.35,30.20))
        u('varanda','Varanda / rio',(1.65,5.15,10.35,7.35),'aberto')
        u('master','Suíte master',(1.65,7.35,6.25,11.15))
        u('escritorio','Escritório',(6.25,7.35,10.35,10.60))
        u('banho-master','Banho master',(1.65,11.15,3.85,13.55))
        u('closet','Closet',(3.85,11.15,6.25,13.55))
        u('hall-frente','Hall / chegada',(6.25,10.60,10.35,11.80))
        u('hall-central','Circulação',(6.25,11.80,7.55,13.55))
        u('hall-retorno','Ligação à suíte 5',(5.50,13.55,7.55,15.39))
        u('escada','Vazio protegido',(7.55,11.80,10.35,15.39),'escada')
        u('hall-fundo','Galeria superior',(5.50,15.39,6.80,21.80))
        u('q5','Suíte 5',(6.80,15.39,10.35,19.65))
        u('v5','Vestíbulo suíte 5',(6.80,19.65,8.35,21.80))
        u('b5','Banho suíte 5',(8.35,19.65,10.35,21.80))
        d['piscina']=[1.75,16.0,4.25,20.0]
        d['escada']=dict(x=7.55,y=11.80,w=2.8,h=3.59,espelhos=18,espelho=.175,piso=.28,largura_lance=1.20,patamar=1.20,guarda=1.10,corrimao=.92)
        d['coberturas']=[dict(nome='Frente e varanda',limites=[1.575,5.075,10.425,13.625],z=6.15,tipo='plana'),dict(nome='Retorno superior',limites=[5.425,13.625,10.425,21.875],z=6.15,tipo='plana'),dict(nome='Ala íntima',limites=[1.575,21.80,10.425,27.875],z=3.0,tipo='plana'),dict(nome='Quarto 3',limites=[1.575,27.875,6.725,33.50],z=3.0,tipo='plana'),dict(nome='Serviço',limites=[6.725,27.875,10.425,30.275],z=3.0,tipo='plana')]
        d['coberturas'] += [dict(nome='Arremate cozinha',limites=[1.575,13.625,5.425,14.225],z=3.0,tipo='plana'),dict(nome='Galeria lateral gourmet',limites=[5.025,14.225,5.425,21.80],z=3.0,tipo='plana')]
        d['decisoes']=['Lazer central separa o pavilhão social dos três quartos térreos; circulação íntima não atravessa a mesa.',
          'Suíte 5 fica sobre o gourmet, nunca sobre a piscina; reserva de pilares alinhados, sem cálculo estrutural.',
          'Apoio e lavabo formam uma faixa lateral coberta, acessada pelo quiosque; lavanderia e depósito têm entradas próprias.',
          'A mesa principal tem oito cadeiras, quatro de cada lado, sem cadeiras nas cabeceiras.',
          'O quarto 3 e o gourmet isolado são mais compactos; cozinha e gourmet somam o conjunto de convívio, mas não são uma sala única.']
    else:
        r('q1','Quarto 1',(1.65,5.15,5.35,8.95));r('b1','Banho reversível 1',(1.65,8.95,3.65,11.15));r('v1','Vestíbulo 1',(3.65,8.95,5.35,11.15))
        r('q2','Quarto 2',(6.65,5.15,10.35,8.95));r('v2','Vestíbulo 2',(6.65,8.95,8.35,11.15));r('b2','Banho reversível 2',(8.35,8.95,10.35,11.15))
        r('circulacao','Galeria íntima',(5.35,5.15,6.65,11.15))
        r('hall-escada','Entrada lateral / hall',(1.65,11.15,4.45,12.35))
        r('hall-central','Hall e jardim',(4.45,11.15,6.65,17.15))
        r('escada','Escada em U',(1.65,12.35,4.45,15.94),'escada')
        r('q3','Quarto 3',(6.65,11.15,10.35,14.95));r('v3','Vestíbulo 3',(6.65,14.95,8.35,17.15));r('b3','Banho reversível 3',(8.35,14.95,10.35,17.15))
        r('conexao','Passeio coberto',(4.45,17.15,6.65,18.65),'aberto')
        r('estar','Estar no jardim',(1.65,18.65,6.65,22.60));r('cozinha','Cozinha aberta',(6.65,18.65,10.35,22.60))
        r('gourmet','Varanda de refeições',(1.65,22.60,10.35,26.30),'aberto')
        r('quiosque','Quiosque / estar',(6.80,26.30,10.35,31.225),'aberto')
        r('lavanderia','Lavanderia',(1.65,31.225,4.05,33.425));r('deposito','Depósito',(4.05,31.225,5.65,33.425));r('lavabo','Lavabo piscina',(5.65,31.225,7.65,33.425));r('apoio','Churrasqueira / apoio',(7.65,31.225,10.35,33.425))
        u('varanda','Varanda / rio',(1.65,5.15,10.35,7.35),'aberto')
        u('escritorio','Escritório',(1.65,7.35,5.75,10.75));u('master','Suíte master',(5.75,7.35,10.35,11.15))
        u('hall-escada','Chegada da escada',(1.65,10.75,4.45,12.35));u('hall-central','Galeria superior',(4.45,10.75,5.75,19.25))
        u('escada','Vazio protegido',(1.65,12.35,4.45,15.94),'escada')
        u('closet','Closet / acesso master',(5.75,11.15,8.15,13.55));u('banho-master','Banho master',(8.15,11.15,10.35,13.55))
        u('q5','Suíte 5',(5.75,13.55,10.35,17.15));u('v5','Vestíbulo suíte 5',(5.75,17.15,8.15,19.25));u('b5','Banho suíte 5',(8.15,17.15,10.35,19.25))
        d['piscina']=[1.8,27.3,5.8,29.8]
        d['escada']=dict(x=1.65,y=12.35,w=2.8,h=3.59,espelhos=18,espelho=.175,piso=.28,largura_lance=1.2,patamar=1.20,guarda=1.1,corrimao=.92)
        d['coberturas']=[dict(nome='Bloco íntimo / varanda rio',limites=[1.575,5.075,10.425,12.425],z=6.15,tipo='plana'),dict(nome='Suítes posteriores',limites=[4.375,12.425,10.425,19.325],z=6.15,tipo='plana'),dict(nome='Escada superior',limites=[1.575,12.425,4.375,16.015],z=6.15,tipo='plana'),dict(nome='Transição estar',limites=[1.575,18.575,4.375,19.325],z=3.0,tipo='plana'),dict(nome='Pavilhão social duas águas',limites=[1.575,19.325,10.425,26.375],z=3.0,tipo='duas-aguas',elevacao=1.3),dict(nome='Quiosque',limites=[6.725,26.375,10.425,31.225],z=3.0,tipo='plana'),dict(nome='Apoio de fundos',limites=[1.575,31.225,10.425,33.50],z=3.0,tipo='plana')]
        d['decisoes']=['Entrada principal lateral protegida: os três quartos térreos preservam privacidade diante da rua.',
          'Um jardim e passeio coberto separam o bloco íntimo do pavilhão social; não é espelhamento da Casa 5.',
          'Varanda de refeições de oito lugares junto à cozinha e quiosque de estar no fundo, sem duplicar duas mesas grandes.',
          'Piscina transversal de 4 × 2,5 m; faixa posterior permite chegar ao lavabo, apoio, depósito e lavanderia sem entrar na casa.',
          'Pavilhão social com cobertura de duas águas; pátio do jardim e piscina permanecem descobertos.']
    lookup={(r['nivel'],r['id']):r for r in d['ambientes']}
    def shared(a,b):
        ax,ay,bx,by=a;cx,cy,dx,dy=b
        if abs(bx-cx)<.001 or abs(dx-ax)<.001:return 'v',bx if abs(bx-cx)<.001 else ax,max(ay,cy),min(by,dy)
        if abs(by-cy)<.001 or abs(dy-ay)<.001:return 'h',by if abs(by-cy)<.001 else ay,max(ax,cx),min(bx,dx)
        raise ValueError(('Sem parede comum',a,b))
    def opening(level,a,b,width=.90,kind='correr',center=None,hinge=None,direction=None,pocket=1):
        ar=lookup[(level,a)];br=lookup[(level,b)]
        axis,f,start,end=shared(ar['limites'],br['limites'])
        if center is None:center=(start+end)/2
        if center-width/2<start+.075-.001 or center+width/2>end-.075+.001:raise ValueError(('Vão não cabe',a,b,start,end,center,width))
        d['aberturas'].append(dict(nivel=level,a=a,b=b,eixo=axis,fixo=f,centro=center,largura=width,peitoril=0,altura=3.0 if kind=='livre' else 2.20,tipo=kind,dobradica=hinge,direcao=direction,bolso=pocket))
    def ext(level,a,side,center,width=1,kind='janela',sill=1,height=1.3,**kw):
        ar=lookup[(level,a)];x,y,X,Y=ar['limites'];axis,f=('v',x) if side=='left' else ('v',X) if side=='right' else ('h',y) if side=='top' else ('h',Y)
        d['aberturas'].append(dict(nivel=level,a=a,b='exterior',eixo=axis,fixo=f,centro=center,largura=width,peitoril=sill,altura=height,tipo=kind,lado=side,angulo=15,**kw))
    # Três pares quarto / vestíbulo / banho, sem acesso por quarto alheio.
    for i in (1,2,3):
        q=lookup[('terreo','q'+str(i))];v=lookup[('terreo','v'+str(i))];b=lookup[('terreo','b'+str(i))]
        x,y,X,Y=q['limites'];right=x>6
        c=x+.65 if right else X-.65
        opening('terreo',q['id'],v['id'],kind='giro',center=c,hinge='inicio' if right else 'fim',direction=-1)
        opening('terreo',v['id'],b['id'],center=b['limites'][1]+.58)
        ci='circulacao' if n==5 or i<3 else 'hall-central'
        opening('terreo',v['id'],ci,center=v['limites'][1]+.60,pocket=1)
        ext('terreo',q['id'],'right' if right else 'left',y+(Y-y)*.42,1.8)
        ext('terreo',b['id'],'right' if right else 'left',b['limites'][1]+1.08,.9,sill=1.6,height=.7)
    # Superior: dois quartos exclusivos + escritório com acesso independente à varanda.
    for rid,width,c in [('master',2.4,3.9 if n==5 else 8.0),('escritorio',2.0,8.1 if n==5 else 3.7)]:
        opening('superior',rid,'varanda',width,kind='correr-vidro',center=c)
    if n==5:
        opening('terreo','estar','entrada',1.2,kind='giro',center=7.2,hinge='inicio',direction=-1)
        opening('terreo','estar','cozinha',2.6,kind='livre',center=5.6)
        opening('terreo','entrada','hall-escada',1.5,kind='livre',center=8.9)
        opening('terreo','cozinha','hall-escada',1.0,kind='livre',center=11.2)
        opening('terreo','hall-escada','escada',2.55,kind='livre',center=8.95)
        opening('terreo','cozinha','conexao',1.8,kind='correr-vidro',center=6.25)
        opening('terreo','passagem','circulacao',1.05,kind='livre',center=6.0)
        ext('terreo','lavabo','top',9.0,.9,'giro',0,2.2,dobradica='inicio',direcao=1)
        ext('terreo','apoio','top',7.55,1.15,'livre',0,2.2)
        opening('terreo','lavanderia','circulacao',.9,center=28.5)
        opening('terreo','deposito','lavanderia',.9,center=28.5)
        # Depósito ganha acesso próprio pelo jardim posterior, não atravessa a lavanderia.
        d['aberturas'].pop()
        ext('terreo','deposito','bottom',9.65,.9,'giro',0,2.2,dobradica='fim',direcao=-1)
        opening('superior','master','closet',.9,kind='giro',center=5.5,hinge='fim',direction=-1)
        opening('superior','closet','banho-master',.9,center=11.73)
        opening('superior','closet','hall-central',.9,center=12.60,pocket=-1)
        opening('superior','escritorio','hall-frente',.9,center=6.95,kind='giro',hinge='inicio',direction=-1)
        opening('superior','hall-frente','hall-central',1.05,kind='livre',center=6.90)
        opening('superior','hall-frente','escada',2.55,kind='livre',center=8.95)
        opening('superior','hall-central','hall-retorno',1.05,kind='livre',center=6.90)
        opening('superior','hall-retorno','hall-fundo',1.05,kind='livre',center=6.15)
        opening('superior','hall-fundo','v5',.9,center=20.25)
        opening('superior','v5','q5',.9,kind='giro',center=7.5,hinge='inicio',direction=-1)
        opening('superior','v5','b5',.9,center=20.23)
        ext('superior','master','left',9.2,2.2);ext('superior','escritorio','right',8.8,1.8)
        ext('superior','q5','right',17.35,2.0);ext('superior','b5','right',20.7,.9,sill=1.6,height=.7)
        ext('superior','banho-master','left',12.3,.9,sill=1.6,height=.7)
        ext('terreo','estar','top',4.1,2.4);ext('terreo','estar','left',7.0,1.2);ext('terreo','cozinha','left',11.4,2.4)
        d['pisos_externos']=[['entrada lateral',[11.0,0,11.85,10.8]],['acesso alpendre',[10.35,7.0,11.85,8.2]],['deck piscina',[4.25,15.39,5.1,21.8]],['depósito',[9.1,30.2,10.35,31.2]]]
    else:
        opening('terreo','circulacao','hall-central',1.05,kind='livre',center=6.0)
        opening('terreo','hall-escada','hall-central',1.0,kind='livre',center=11.75)
        opening('terreo','hall-escada','escada',2.55,kind='livre',center=3.05)
        ext('terreo','hall-escada','left',11.75,.95,'giro',0,2.2,dobradica='inicio',direcao=1)
        opening('terreo','hall-central','conexao',1.7,kind='livre',center=5.55)
        opening('terreo','conexao','estar',1.6,kind='livre',center=5.55)
        opening('terreo','estar','cozinha',2.6,kind='livre',center=20.85)
        opening('terreo','estar','gourmet',2.4,kind='correr-vidro',center=4.6)
        opening('terreo','cozinha','gourmet',2.4,kind='livre',center=8.2)
        for rid in ['lavanderia','deposito','lavabo','apoio']:
            ar=lookup[('terreo',rid)];x,y,X,Y=ar['limites']
            ext('terreo',rid,'top',(x+X)/2,.9 if rid!='apoio' else 1.8,'livre' if rid=='apoio' else 'giro',0,2.2,dobradica='fim' if rid=='lavabo' else 'inicio',direcao=1)
        opening('superior','escritorio','hall-escada',.9,center=3.6,kind='giro',hinge='inicio',direction=-1)
        opening('superior','hall-escada','hall-central',1.05,kind='livre',center=11.6)
        opening('superior','hall-escada','escada',2.55,kind='livre',center=3.05)
        opening('superior','hall-central','closet',.9,center=12.60,pocket=-1)
        opening('superior','closet','master',.9,center=6.6)
        opening('superior','closet','banho-master',.9,center=11.73)
        opening('superior','hall-central','v5',.9,center=17.73)
        opening('superior','v5','q5',.9,kind='giro',center=6.45,hinge='inicio',direction=-1)
        opening('superior','v5','b5',.9,center=17.73)
        ext('superior','master','right',9.2,2.2);ext('superior','escritorio','left',8.9,1.8)
        ext('superior','q5','right',15.1,2.0);ext('superior','b5','right',18.2,.9,sill=1.6,height=.7)
        ext('superior','banho-master','right',12.3,.9,sill=1.6,height=.7)
        ext('terreo','estar','left',20.65,2.4);ext('terreo','cozinha','right',20.65,2.0)
        d['pisos_externos']=[['entrada lateral',[.15,0,1.10,12.35]],['soleira entrada',[1.1,11.2,1.65,12.3]],['deck de ligação',[5.8,26.3,6.8,31.225]],['deck posterior piscina',[1.65,29.8,6.8,31.225]]]
    # Ventilação externa independente do acesso seco do lavabo e dos serviços.
    for rid in ['lavabo','lavanderia','deposito']:
        ar=lookup[('terreo',rid)];x,y,X,Y=ar['limites']
        side='right' if rid in ('lavabo','deposito') and n==5 else 'bottom'
        ext('terreo',rid,side,(y+Y)/2 if side=='right' else (x+X)/2,.9,sill=1.6,height=.7)
    # Mobiliário com envelope físico, em metros. Portas de armário são de correr.
    def item(level,room,name,rect,z=.0,h=.8,asset=None,rot=0):
        d['moveis'].append(dict(nivel=level,ambiente=room,nome=name,limites=list(rect),z=z,altura=h,asset=asset,rotacao=rot))
    for level,id in [('terreo','q1'),('terreo','q2'),('terreo','q3'),('superior','master'),('superior','q5')]:
        x,y,X,Y=lookup[(level,id)]['limites'];cx=(x+X)/2
        offset=.10 if n==5 and id=='q3' else .25
        bounds=(cx-.79,Y-2.23,cx+.79,Y-.25) if id=='master' else (cx-.79,y+offset,cx+.79,y+offset+1.98)
        item(level,id,'Cama queen' if id=='master' else 'Cama casal',bounds,h=.62,asset='old_bed_frame',rot=180 if id=='master' else 0)
        if id=='master':continue
        if id=='q5':ward=(X-1.55,Y-.675,X-.10,Y-.075)
        else:
            sideleft=x<6
            ward=(x+.10,Y-.675,x+1.55,Y-.075) if sideleft else (X-1.55,Y-.675,X-.10,Y-.075)
        item(level,id,'Armário de correr',ward,h=2.15)
    # Banheiros: box no fundo externo, bacia no primeiro terço, cuba no fundo interno.
    for ar in d['ambientes']:
        if ar['id'] not in ('b1','b2','b3','b5','banho-master','lavabo'):continue
        level=ar['nivel'];id=ar['id'];x,y,X,Y=ar['limites'];right=x>6 or n==6 and id=='lavabo'
        if id=='lavabo':
            item(level,id,'Bacia sanitária',(X-.82,Y-.58,X-.12,Y-.18),h=.43)
            basin=(X-.90,y+.15,X-.35,y+.60) if n==5 else (x+.10,y+.15,x+.55,y+.65)
            item(level,id,'Lavatório',basin,z=.70,h=.17)
        else:
            if right:
                box=(X-1.08,Y-1.07,X-.10,Y-.10);wc=(X-.82,y+.15,X-.12,y+.55);sink=(x+.12,Y-.70,x+.65,Y-.15)
            else:
                box=(x+.10,Y-1.07,x+1.08,Y-.10);wc=(x+.12,y+.15,x+.82,y+.55);sink=(X-.65,Y-.70,X-.12,Y-.15)
            for name,b,h,z in [('Box 0,98 × 0,97',box,.04,0),('Bacia sanitária',wc,.43,0),('Lavatório',sink,.17,.70)]:item(level,id,name,b,z,h)
    # Closet linear: a retirada do segundo braço libera entrada e acesso ao banho.
    x,y,X,Y=lookup[('superior','closet')]['limites']
    item('superior','closet','Armário de correr',(x+.15,Y-.675,X-.15,Y-.075),h=2.15)
    x,y,X,Y=lookup[('superior','escritorio')]['limites']
    item('superior','escritorio','Mesa escritório',(X-1.85,y+.65,X-.25,y+1.4),h=.76,asset='wooden_table_02')
    item('superior','escritorio','Cadeira escritório',(X-1.25,y+1.55,X-.7,y+2.10),h=.90,asset='modern_arm_chair_01')
    x,y,X,Y=lookup[('terreo','estar')]['limites']
    item('terreo','estar','Sofá',(x+.5,y+1.0,x+2.8,y+1.85),h=.85,asset='sofa_02',rot=180 if n==6 else 0)
    tv=(x+.50,y+.15,x+2.80,y+.50) if n==6 else (x+.60,Y-.50,x+2.50,Y-.15)
    item('terreo','estar','TV / rack',tv,h=1.3)
    # Cozinha: bancada lateral direita; geladeira não fica no vão de ligação.
    x,y,X,Y=lookup[('terreo','cozinha')]['limites']
    counter=(x+.10,y+.15,x+.70,y+1.90) if n==5 else (X-.70,y+.15,X-.10,y+1.90)
    item('terreo','cozinha','Bancada cozinha',counter,h=.9)
    item('terreo','cozinha','Geladeira',(X-.85,Y-1.0,X-.10,Y-.20),h=1.85)
    dining='quiosque' if n==5 else 'gourmet'
    cx,cy=(8.10,17.52) if n==5 else (5.9,24.50)
    item('terreo',dining,'Mesa 8 lugares',(cx-1.4,cy-.5,cx+1.4,cy+.5),h=.76,asset='wooden_table_02')
    for j in range(4):
        xx=cx-1.05+j*.70
        for sign in (-1,1):item('terreo',dining,'Cadeira refeição',(xx-.225,cy+sign*.80-.25,xx+.225,cy+sign*.80+.25),h=.90,asset='dining_chair_02',rot=0 if sign<0 else 180)
    if n==6:
        item('terreo','quiosque','Sofá de jardim',(8.0,27.0,10.15,27.85),h=.80,asset='sofa_02')
        for yy in (29.0,30.1):item('terreo','quiosque','Poltrona jardim',(7.6,yy,8.25,yy+.65),h=.85,asset='modern_arm_chair_01',rot=90)
    for id in ('lavanderia','apoio'):
        x,y,X,Y=lookup[('terreo',id)]['limites']
        item('terreo',id,'Tanque e bancada' if id=='lavanderia' else 'Pia / churrasqueira',(x+.12,Y-.70,X-.12,Y-.10),h=.9)
    # Pilares de reserva arquitetônica: em encontros, fora das rotas de portas.
    if n==5:pts=[(1.70,5.20,6.15),(10.30,5.20,6.15),(10.25,15.49,6.15),(10.25,19.55,6.15),(5.25,15.49,6.15),(6.90,19.55,6.15)]
    else:pts=[(1.70,5.20,6.15),(10.30,5.20,6.15),(10.35,17.05,6.15),(10.35,19.15,6.15),(6.55,18.53,6.15),(1.78,22.75,3.0),(10.22,22.75,3.0),(1.78,26.17,3.0),(10.22,26.17,3.0),(6.93,26.50,3.0),(10.22,31.10,3.0)]
    d['pilares']=[dict(x=x,y=y,z=z,largura=.20) for x,y,z in pts]
    d['vagas']=[[1.65+i*2.5,0,4.15+i*2.5,5.0] for i in range(3)]
    return d

if __name__=='__main__':
    for n in (5,6):
        out=ROOT/f'CASA-{n:02}';out.mkdir(exist_ok=True)
        d=proposal(n)
        (out/'CONCEPCAO.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
        print(n,len(d['ambientes']),'ambientes',len(d['aberturas']),'vãos',len(d['moveis']),'móveis/louças')
