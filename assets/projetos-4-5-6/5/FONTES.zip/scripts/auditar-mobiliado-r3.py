"""Revisão das folhas versus caixas reais dos móveis importados no Blender."""
import json,math,re
from pathlib import Path
from shapely.geometry import box
from geometria import door_shape
ROOT=Path(__file__).resolve().parent
fail=[]
for n in [5,6]:
    out=ROOT/'PUBLICACAO-R3'/f'CASA-{n:02}'
    d=json.loads((out/'CONCEPCAO.json').read_text(encoding='utf8'));els=json.loads((out/'ENVELOPES-MOBILIARIO-R3.json').read_text(encoding='utf8'));checks=[]
    for o in d['aberturas']:
        if o['tipo'] not in ['giro','janela']:continue
        z=3.15 if o['nivel']=='superior' else 0
        if o['tipo']=='giro':shape=door_shape(o,True).buffer(-.035);z1=z;z2=z+o['altura'];tol=.003
        else:
            a=o['centro']-o['largura']/2+.015;b=o['centro']+o['largura']/2-.015;direction=-1 if o['lado'] in ['left','top'] else 1
            near=o['fixo']+direction*.086;far=o['fixo']+direction*o['altura']*math.sin(math.radians(o['angulo']))
            shape=box(a,min(near,far),b,max(near,far)) if o['eixo']=='h' else box(min(near,far),a,max(near,far),b)
            z1=z+o['peitoril'];z2=z1+o['altura'];tol=.001
        collisions=[]
        for e in els:
            if e['camada']!=o['nivel']:continue
            lo=e['min'];hi=e['max']
            if min(z2,hi[2])-max(z1,lo[2])<.002:continue
            overlap=shape.intersection(box(lo[0],lo[1],hi[0],hi[1])).area
            if overlap>tol:collisions.append(dict(nome=e['nome'],area=round(overlap,4)))
        item=dict(abertura=f"{o['nivel']} / {o['a']} → {o['b']} / {o['tipo']}",interferencias=collisions);checks.append(item)
        if collisions:fail.append(dict(casa=n,**item))
    report=dict(numero=n,estado='PASSOU' if not any(c['interferencias'] for c in checks) else 'CORRIGIR',ensaios=len(checks),pecas_mobiliario=len(els),itens=checks,limites='Caixas reais das malhas de móveis/veículos exportadas do Blender versus folhas; superfícies curvas tratadas conservadoramente. Aberturas versus paredes/pilares e rotas estão nos outros relatórios. Não especificação de ferragens ou certificação para obra.')
    (out/'QA-MOBILIARIO-ESQUADRIAS-R3.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(n,report['estado'],len(checks),'aberturas',len(els),'peças',flush=True)
for f in fail:print(f)
raise SystemExit(bool(fail))
