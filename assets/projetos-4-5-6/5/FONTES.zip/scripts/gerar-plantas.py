"""Pranchas A3, escala física 1:100; mesma fonte JSON do modelo."""
import json,math,html
from pathlib import Path
from geometria import wall_parts,door_shape,stair,measures
ROOT=Path(__file__).resolve().parent
def num(v):return f'{v:.2f}'.replace('.',',')
def make(d,level):
    out=[]
    def rect(b,fill,stroke='none',sw=.02,rx=0):
        x,y,X,Y=b;out.append(f'<rect x="{x}" y="{y}" width="{X-x}" height="{Y-y}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    def line(x,y,X,Y,color='#6f7b70',sw=.018,dash=''):
        out.append(f'<path d="M{x},{y} L{X},{Y}" stroke="{color}" stroke-width="{sw}" fill="none" stroke-dasharray="{dash}"/>')
    def text(x,y,t,size=.23,color='#253c30',anchor='middle',weight='normal'):
        out.append(f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}">{html.escape(t)}</text>')
    def dim(x,y,X,Y,label):
        line(x,y,X,Y,'#758476',.012)
        if y==Y:
            for xx in (x,X):line(xx-.06,y-.08,xx+.06,y+.08,'#758476',.015)
            text((x+X)/2,y-.09,label,.20)
        else:
            for yy in (y,Y):line(x-.08,yy-.06,x+.08,yy+.06,'#758476',.015)
            out.append(f'<text transform="translate({x-.1},{(y+Y)/2}) rotate(-90)" font-size=".20" text-anchor="middle" fill="#758476">{html.escape(label)}</text>')
    out.append('<svg xmlns="http://www.w3.org/2000/svg" width="297mm" height="420mm" viewBox="0 0 29.7 42"><defs><pattern id="wood" width=".24" height=".24" patternUnits="userSpaceOnUse"><path d="M0 .02H.24" stroke="#be9977" stroke-width=".012"/></pattern><pattern id="tile" width=".6" height=".6" patternUnits="userSpaceOnUse"><rect width=".6" height=".6" fill="#e9e1d0"/><path d="M.6 0H0V.6" fill="none" stroke="#d1c8b7" stroke-width=".013"/></pattern><pattern id="water" width=".35" height=".35" patternUnits="userSpaceOnUse"><rect width=".35" height=".35" fill="#8dbcc1"/><path d="M0 .1Q.1 .03 .2 .1T.4 .1" fill="none" stroke="#cee2df" stroke-width=".018"/></pattern></defs><rect width="29.7" height="42" fill="#fffdf7"/><g font-family="Arial,sans-serif">')
    text(1.5,1.0,'PEDRINHAS  /  INGETRAZO',.28,anchor='start',weight='bold')
    text(1.5,1.75,f'CASA {d["numero"]} — {d["nome"]}',.52,anchor='start',weight='bold')
    text(1.5,2.32,('TÉRREO' if level=='terreo' else 'PAVIMENTO SUPERIOR')+'   ·   R2 / 13.11.2026   ·   ESTUDO PRELIMINAR',.24,anchor='start')
    out.append('<g transform="translate(4.5 4.1)">')
    rect((0,0,12,35),'#e4ebd8','#597355',.035)
    rect((0,-.7,12,0),'#e5e5dc')
    text(6,-.31,'RUA · LAZER DO CONDOMÍNIO E RIO A ~100 m',.22)
    for name,b in d['pisos_externos']:rect(b,'#d6ccb8')
    for i,b in enumerate(d['vagas']):
        rect(b,'#dedaca','#a9afa0',.015)
        x,y,X,Y=b;rect((x+.35,.32,X-.35,4.45),'#bbbfb7','#7e8b7f',.025,.25)
        rect((x+.49,1.05,X-.49,2.05),'#809693','#657d78',.025,.12)
        rect((x+.49,2.9,X-.49,3.65),'#809693','#657d78',.02,.1)
        text((x+X)/2,4.75,f'V{i+1} · 2,50 × 5,00',.16)
    # Tracejado do térreo na planta superior dá contexto à água e jardim.
    if level=='superior':
        for r in d['ambientes']:
            if r['nivel']=='terreo':
                x,y,X,Y=r['limites'];out.append(f'<rect x="{x}" y="{y}" width="{X-x}" height="{Y-y}" fill="none" stroke="#b9c4b0" stroke-width=".025" stroke-dasharray=".1 .1"/>')
    px,py,pX,pY=d['piscina'];rect((px,py,pX,pY),'url(#water)','#46858c',.035)
    text((px+pX)/2,(py+pY)/2,'PISCINA',.23);text((px+pX)/2,(py+pY)/2+.32,'2,50 × 4,00 · 10 m²',.18)
    rooms=[r for r in d['ambientes'] if r['nivel']==level]
    for r in rooms:
        if r['tipo']=='escada':continue
        x,y,X,Y=r['limites'];bed=r['id'].startswith('q') or r['id'] in ('master','closet')
        rect((x,y,X,Y),'#d9bf9b' if bed else 'url(#tile)')
        if bed:rect((x,y,X,Y),'url(#wood)')
    for w in wall_parts(d,level):
        if w['z']<1.4 and w['z']+w['altura']>1.4:rect(w['limites'],'#314c3c')
    for o in d['aberturas']:
        if o['nivel']!=level:continue
        a=o['centro']-o['largura']/2;b=o['centro']+o['largura']/2;f=o['fixo']
        if o['tipo']=='janela':
            shift=math.sin(math.radians(o['angulo']))*o['altura']*(-1 if o['lado'] in ('left','top') else 1)
            if o['eixo']=='h':line(a,f,b,f,'#2e9aa1',.045);line(a,f+shift,b,f+shift,'#2e9aa1',.025);line(a,f,a,f+shift,'#2e9aa1',.02);line(b,f,b,f+shift,'#2e9aa1',.02)
            else:line(f,a,f,b,'#2e9aa1',.045);line(f+shift,a,f+shift,b,'#2e9aa1',.025);line(f,a,f+shift,a,'#2e9aa1',.02);line(f,b,f+shift,b,'#2e9aa1',.02)
        elif o['tipo']=='giro':
            p=door_shape(o,True);pts=list(p.exterior.coords);out.append('<path d="'+ 'M'+' L'.join(f'{x},{y}' for x,y in pts)+'" fill="#fff9e9" fill-opacity=".3" stroke="#a87e53" stroke-width=".015" stroke-dasharray=".05 .03"/>')
            p=door_shape(o);x,y,X,Y=p.bounds;rect((x,y,X,Y),'#a87e53')
        elif o['tipo'].startswith('correr'):
            if o['eixo']=='h':line(a,f,b,f,'#9a784f',.035);line(a,f-.04,(a+b)/2,f-.04,'#9a784f',.025)
            else:line(f,a,f,b,'#9a784f',.035);line(f-.04,a,f-.04,(a+b)/2,'#9a784f',.025)
    for m in d['moveis']:
        if m['nivel']!=level:continue
        x,y,X,Y=m['limites'];name=m['nome'];color='#b99876' if 'Armário' in name or 'bancada' in name.lower() or 'Mesa' in name else '#fcfaf1' if 'Cama' in name or 'Lavatório' in name or 'Bacia' in name else '#aabbb0' if 'Sofá' in name or 'Cadeira' in name or 'Poltrona' in name else '#c5d6d0' if 'Box' in name else '#7d8a7b'
        rect((x,y,X,Y),color,'#7e8876',.018,.04)
        if 'Cama' in name:
            py,pY=(Y-.45,Y-.12) if m['rotacao']==180 else (y+.12,y+.45)
            rect((x+.10,py,(x+X)/2-.035,pY),'#eee9d9','#d6cbb9',.012,.05);rect(((x+X)/2+.035,py,X-.10,pY),'#eee9d9','#d6cbb9',.012,.05)
            ly=Y-.70 if m['rotacao']==180 else y+.70
            line(x+.02,ly,X-.02,ly,'#d6cbb9',.025)
        if 'Bacia' in name:out.append(f'<ellipse cx="{(x+X)/2}" cy="{(y+Y)/2}" rx="{(X-x)*.37}" ry="{(Y-y)*.35}" fill="#fffdf8" stroke="#9aa99e" stroke-width=".018"/>')
        if 'Box' in name:line(x,y,X,Y,'#89a8a8',.015);line(X,y,x,Y,'#89a8a8',.015)
    ss,land=stair(d)
    for st in ss:
        if level=='superior' and 'inferior' in st['nome']:continue
        rect(st['limites'],'#e0caa5','#9f947b',.016)
    rect(land,'#e0caa5','#9f947b',.018)
    s=d['escada'];sx=s['x'];sy=s['y'];line(sx+.65,sy+.15,sx+.65,sy+1.9,'#a36f49',.05)
    out.append(f'<path d="M{sx+.48},{sy+1.72} L{sx+.65},{sy+1.95} L{sx+.82},{sy+1.72}" stroke="#a36f49" fill="none" stroke-width=".04"/>')
    text(sx+1.4,sy+3.12,'18 × 17,5 / 28 cm',.16)
    if level=='superior':
        line(1.65,5.15,10.35,5.15,'#495d4a',.07)
        for xx in (1.65,10.35):line(xx,5.15,xx,7.35,'#495d4a',.07)
        line(sx+.075,sy,sx+1.525,sy,'#495d4a',.07)
    for p in d['pilares']:
        if level=='superior' and p['z']<6:continue
        w=p['largura'];rect((p['x']-w/2,p['y']-w/2,p['x']+w/2,p['y']+w/2),'#5d6b56')
    # IDs dentro da planta; nomes, áreas e dimensões úteis na margem.
    for i,r in enumerate(rooms,1):
        x,y,X,Y=r['limites'];cy=Y-.85 if r['id'].startswith('q') or r['id']=='master' else (y+Y)/2
        rect(((x+X)/2-.22,cy-.23,(x+X)/2+.22,cy+.16),'#fffdf7','#698169',.018,.08)
        text((x+X)/2,cy+.04,f'{i:02}',.23,weight='bold')
        # Cotas úteis internas junto ao limite, em dimensão não ocupada pela etiqueta.
        if X-x>1.9 and Y-y>1.9:text((x+X)/2,Y-.22,num(X-x-.15)+' × '+num(Y-y-.15),.17)
    dim(0,-1.0,12,-1.0,'12,00 m');dim(-1.35,0,-1.35,35,'35,00 m')
    dim(0,5.0,1.5,5.0,'1,50');dim(10.5,5.0,12,5.0,'1,50')
    dim(12.55,0,12.55,5.0,'5,00');dim(12.55,33.5,12.55,35,'1,50')
    for i in range(5):rect((i*.5,35.55,(i+1)*.5,35.65),'#314c3c' if i%2==0 else '#fffdf7','#314c3c',.015)
    text(0,36.0,'0',.19);text(2.5,36.0,'2,5 m · ESCALA 1:100 (A3, sem ajustar)',.19,anchor='start')
    # Norte: esquerda e um pouco para baixo; norte não é eixo superior da folha.
    line(-2.3,1.3,-3.2,1.72,'#314c3c',.05);text(-3.25,2.03,'N',.28,weight='bold')
    out.append('<path d="M-3.2 1.72 l.18 -.20 l.10 .21Z" fill="#314c3c"/>')
    line(13.5,2.0,12.95,3.55,'#5f9b94',.045)
    out.append('<path d="M12.95 3.55 l-.02 -.28 l.19 .07Z" fill="#5f9b94"/>')
    text(13.0,1.70,'VENTO SE',.16);text(13.0,1.93,'135°',.16)
    out.append('</g>')
    text(19.0,4.3,'AMBIENTES E MEDIDAS ÚTEIS',.26,anchor='start',weight='bold')
    text(19.0,4.8,'Dimensões descontam 7,5 cm em cada face.',.19,anchor='start')
    for i,r in enumerate(rooms,1):
        x,y,X,Y=r['limites'];w=X-x-.15;h=Y-y-.15;yy=5.4+(i-1)*1.02
        text(19.0,yy,f'{i:02}  {r["nome"]}',.23,anchor='start',weight='bold')
        text(19.0,yy+.35,f'{num(w)} × {num(h)} m   ·   {num(w*h)} m²',.21,anchor='start')
    yy=5.6+len(rooms)*1.02
    for t in ['Janelas maxim-ar ABREM PARA FORA.','Portas: giro em tracejado / correr em linha dupla.','Área de janela: conferir folha e ventilação efetiva.','Guarda-corpos 1,10 m; corrimãos nos dois lances.','Cotas são estudo, não dimensões de execução.']:
        text(19,yy,t,.19,anchor='start');yy+=.4
    q=measures(d)
    for t in [f'SOLO NATURAL: {num(q["solo_natural"])} m² ({num(q["solo_natural_percentual"])}%)',f'CONSTRUÍDA ESTIMADA: {num(q["construida"])} m²','Recuos 5 / 1,5 / 1,5 m: hipótese do briefing.','Zona cadastral / condomínio: PENDENTES.']:
        text(19,yy+.3,t,.21,anchor='start');yy+=.45
    line(1.5,40.5,28.2,40.5,'#d3d3bd',.018)
    text(1.5,41.0,'ESTUDO PRELIMINAR · Não utilizar para obra. Rever legislação, estrutura, instalações e acessibilidade.',.22,anchor='start')
    text(28.2,41.0,f'{d["numero"]}.0{1 if level=="terreo" else 2} / R2',.25,anchor='end')
    out.append('</g></svg>');return ''.join(out)

if __name__=='__main__':
    for n in (5,6):
        folder=ROOT/f'CASA-{n:02}';d=json.loads((folder/'CONCEPCAO.json').read_text(encoding='utf8'))
        for l in ('terreo','superior'):(folder/(l+'.svg')).write_text(make(d,l),encoding='utf8')
        (folder/'AREAS.json').write_text(json.dumps(measures(d),ensure_ascii=False,indent=2),encoding='utf8')
        print(n,measures(d))
